/**
 * Pharmacy Validation Module
 * Comprehensive validation schemas and functions for pharmacy operations
 * Using Zod for runtime type validation and data integrity
 */

import { z } from 'zod';

// Base schemas for common pharmacy data types
export const medicationIdSchema = z.string().min(1, 'Medication ID is required');
export const patientIdSchema = z.string().min(1, 'Patient ID is required');
export const prescriptionIdSchema = z.string().min(1, 'Prescription ID is required');
export const barcodeSchema = z.string().min(1, 'Barcode is required');
export const quantitySchema = z.number().min(0, 'Quantity must be non-negative');
export const dosageSchema = z.string().min(1, 'Dosage is required');

// Prescription validation schema
export const prescriptionRequestSchema = z.object({
  patientId: patientIdSchema,
  medicationId: medicationIdSchema,
  dosage: dosageSchema,
  frequency: z.string().min(1, 'Frequency is required'),
  duration: z.string().min(1, 'Duration is required'),
  instructions: z.string().optional(),
  prescriberId: z.string().min(1, 'Prescriber ID is required'),
  priority: z.enum(['routine', 'urgent', 'stat']).default('routine')
});

// Administration validation schema
export const administrationRequestSchema = z.object({
  prescriptionId: prescriptionIdSchema,
  patientId: patientIdSchema,
  medicationId: medicationIdSchema,
  administeredBy: z.string().min(1, 'Administrator ID is required'),
  administeredAt: z.date().default(() => new Date()),
  dosageGiven: dosageSchema,
  route: z.string().min(1, 'Administration route is required'),
  site: z.string().optional(),
  notes: z.string().optional()
});

// Dispensing validation schema
export const dispensingRequestSchema = z.object({
  prescriptionId: prescriptionIdSchema,
  medicationId: medicationIdSchema,
  quantityDispensed: quantitySchema,
  dispensedBy: z.string().min(1, 'Dispenser ID is required'),
  dispensedAt: z.date().default(() => new Date()),
  lotNumber: z.string().optional(),
  expirationDate: z.date().optional(),
  verifiedBy: z.string().optional()
});

// Barcode verification schema
export const barcodeVerificationRequestSchema = z.object({
  barcode: barcodeSchema,
  expectedMedicationId: medicationIdSchema.optional(),
  verificationContext: z.enum(['dispensing', 'administration', 'inventory']),
  scannedBy: z.string().min(1, 'Scanner ID is required'),
  scannedAt: z.date().default(() => new Date())
});

// Inventory management schemas
export const inventoryRequestSchema = z.object({
  medicationId: medicationIdSchema,
  currentStock: quantitySchema,
  minimumStock: quantitySchema,
  maximumStock: quantitySchema,
  location: z.string().min(1, 'Location is required'),
  updatedBy: z.string().min(1, 'Updated by is required')
});

export const inventoryAdjustmentRequestSchema = z.object({
  medicationId: medicationIdSchema,
  adjustmentType: z.enum(['increase', 'decrease', 'correction']),
  adjustmentQuantity: quantitySchema,
  reason: z.string().min(1, 'Adjustment reason is required'),
  adjustedBy: z.string().min(1, 'Adjuster ID is required'),
  referenceNumber: z.string().optional()
});

export const inventoryTransferRequestSchema = z.object({
  medicationId: medicationIdSchema,
  fromLocation: z.string().min(1, 'From location is required'),
  toLocation: z.string().min(1, 'To location is required'),
  quantity: quantitySchema,
  transferredBy: z.string().min(1, 'Transfer initiator ID is required'),
  approvedBy: z.string().optional(),
  reason: z.string().optional()
});

export const reorderRequestSchema = z.object({
  medicationId: medicationIdSchema,
  currentStock: quantitySchema,
  reorderQuantity: quantitySchema,
  supplier: z.string().min(1, 'Supplier is required'),
  urgency: z.enum(['low', 'medium', 'high', 'critical']).default('medium'),
  requestedBy: z.string().min(1, 'Requester ID is required')
});

// Drug interaction validation schemas
export const drugDrugInteractionRequestSchema = z.object({
  medication1Id: medicationIdSchema,
  medication2Id: medicationIdSchema,
  patientId: patientIdSchema.optional(),
  checkSeverity: z.boolean().default(true)
});

export const drugAllergyInteractionRequestSchema = z.object({
  medicationId: medicationIdSchema,
  patientId: patientIdSchema,
  allergyType: z.string().min(1, 'Allergy type is required'),
  severity: z.enum(['mild', 'moderate', 'severe', 'life-threatening'])
});

export const drugConditionInteractionRequestSchema = z.object({
  medicationId: medicationIdSchema,
  patientId: patientIdSchema,
  condition: z.string().min(1, 'Medical condition is required'),
  conditionSeverity: z.enum(['mild', 'moderate', 'severe']).optional()
});

export const drugLabInteractionRequestSchema = z.object({
  medicationId: medicationIdSchema,
  patientId: patientIdSchema,
  labTestType: z.string().min(1, 'Lab test type is required'),
  labValues: z.record(z.string(), z.number()).optional()
});

export const interactionCheckRequestSchema = z.object({
  medications: z.array(medicationIdSchema).min(1, 'At least one medication is required'),
  patientId: patientIdSchema,
  checkTypes: z.array(z.enum(['drug-drug', 'drug-allergy', 'drug-condition', 'drug-lab'])).default(['drug-drug'])
});

export const batchInteractionCheckRequestSchema = z.object({
  patientId: patientIdSchema,
  newMedicationId: medicationIdSchema,
  existingMedications: z.array(medicationIdSchema).default([]),
  checkAllInteractions: z.boolean().default(true)
});

export const interactionOverrideRequestSchema = z.object({
  interactionId: z.string().min(1, 'Interaction ID is required'),
  overrideReason: z.string().min(1, 'Override reason is required'),
  overriddenBy: z.string().min(1, 'Override authority ID is required'),
  acknowledgedRisks: z.boolean().refine(val => val === true, 'Risk acknowledgment is required')
});

// Verification schemas
export const dispensingVerificationRequestSchema = z.object({
  dispensingId: z.string().min(1, 'Dispensing ID is required'),
  verifiedBy: z.string().min(1, 'Verifier ID is required'),
  verificationChecks: z.object({
    medicationVerified: z.boolean(),
    dosageVerified: z.boolean(),
    quantityVerified: z.boolean(),
    patientVerified: z.boolean(),
    labelVerified: z.boolean()
  }),
  verificationNotes: z.string().optional()
});

export const partialDispensingRequestSchema = z.object({
  prescriptionId: prescriptionIdSchema,
  medicationId: medicationIdSchema,
  partialQuantity: quantitySchema,
  remainingQuantity: quantitySchema,
  partialReason: z.string().min(1, 'Partial dispensing reason is required'),
  dispensedBy: z.string().min(1, 'Dispenser ID is required'),
  nextDispenseDate: z.date().optional()
});

// Patient education and adherence schemas
export const educationRequestSchema = z.object({
  patientId: patientIdSchema,
  medicationId: medicationIdSchema,
  educationType: z.enum(['initial', 'reinforcement', 'side-effects', 'adherence']),
  educatedBy: z.string().min(1, 'Educator ID is required'),
  educationContent: z.string().min(1, 'Education content is required'),
  patientUnderstood: z.boolean(),
  followUpRequired: z.boolean().default(false)
});

export const missedDoseRequestSchema = z.object({
  patientId: patientIdSchema,
  medicationId: medicationIdSchema,
  prescriptionId: prescriptionIdSchema,
  missedDoseTime: z.date(),
  reportedBy: z.string().min(1, 'Reporter ID is required'),
  missedReason: z.string().min(1, 'Reason for missed dose is required'),
  actionTaken: z.string().optional()
});

// Adverse reaction schemas
export const reactionRequestSchema = z.object({
  patientId: patientIdSchema,
  medicationId: medicationIdSchema,
  reactionType: z.string().min(1, 'Reaction type is required'),
  severity: z.enum(['mild', 'moderate', 'severe', 'life-threatening']),
  symptoms: z.array(z.string()).min(1, 'At least one symptom is required'),
  onsetTime: z.date(),
  reportedBy: z.string().min(1, 'Reporter ID is required'),
  treatmentGiven: z.string().optional(),
  outcome: z.enum(['recovered', 'recovering', 'ongoing', 'fatal']).optional()
});

// Validation functions
export const validatePrescriptionRequest = (data: unknown) => {
  return prescriptionRequestSchema.parse(data);
};

export const validateAdministrationRequest = (data: unknown) => {
  return administrationRequestSchema.parse(data);
};

export const validateDispensingRequest = (data: unknown) => {
  return dispensingRequestSchema.parse(data);
};

export const validateBarcodeVerificationRequest = (data: unknown) => {
  return barcodeVerificationRequestSchema.parse(data);
};

export const validateInventoryRequest = (data: unknown) => {
  return inventoryRequestSchema.parse(data);
};

export const validateInventoryAdjustmentRequest = (data: unknown) => {
  return inventoryAdjustmentRequestSchema.parse(data);
};

export const validateInventoryTransferRequest = (data: unknown) => {
  return inventoryTransferRequestSchema.parse(data);
};

export const validateReorderRequest = (data: unknown) => {
  return reorderRequestSchema.parse(data);
};

export const validateDrugDrugInteractionRequest = (data: unknown) => {
  return drugDrugInteractionRequestSchema.parse(data);
};

export const validateDrugAllergyInteractionRequest = (data: unknown) => {
  return drugAllergyInteractionRequestSchema.parse(data);
};

export const validateDrugConditionInteractionRequest = (data: unknown) => {
  return drugConditionInteractionRequestSchema.parse(data);
};

export const validateDrugLabInteractionRequest = (data: unknown) => {
  return drugLabInteractionRequestSchema.parse(data);
};

export const validateInteractionCheckRequest = (data: unknown) => {
  return interactionCheckRequestSchema.parse(data);
};

export const validateBatchInteractionCheckRequest = (data: unknown) => {
  return batchInteractionCheckRequestSchema.parse(data);
};

export const validateInteractionOverrideRequest = (data: unknown) => {
  return interactionOverrideRequestSchema.parse(data);
};

export const validateDispensingVerificationRequest = (data: unknown) => {
  return dispensingVerificationRequestSchema.parse(data);
};

export const validatePartialDispensingRequest = (data: unknown) => {
  return partialDispensingRequestSchema.parse(data);
};

export const validateEducationRequest = (data: unknown) => {
  return educationRequestSchema.parse(data);
};

export const validateMissedDoseRequest = (data: unknown) => {
  return missedDoseRequestSchema.parse(data);
};

export const validateReactionRequest = (data: unknown) => {
  return reactionRequestSchema.parse(data);
};

// All schemas are exported individually above to avoid duplication
