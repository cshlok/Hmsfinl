/**
 * FHIR (Fast Healthcare Interoperability Resources) integration utilities
 * Provides standardized healthcare data exchange functionality
 */

// FHIR resource types
export type FhirResourceType = 
  | 'Patient' 
  | 'Observation' 
  | 'DiagnosticReport' 
  | 'Procedure' 
  | 'Medication' 
  | 'MedicationRequest'
  | 'Condition'
  | 'Encounter'
  | 'Organization'
  | 'Practitioner'
  | 'Appointment'

// Basic FHIR resource structure
export interface FhirResource {
  resourceType: FhirResourceType
  id?: string
  meta?: {
    versionId?: string
    lastUpdated?: string
    profile?: string[]
  }
  identifier?: Array<{
    use?: string
    type?: {
      coding?: Array<{
        system?: string
        code?: string
        display?: string
      }>
    }
    system?: string
    value?: string
  }>
}

// FHIR Patient resource
export interface FhirPatient extends FhirResource {
  resourceType: 'Patient'
  name?: Array<{
    use?: string
    family?: string
    given?: string[]
    prefix?: string[]
    suffix?: string[]
  }>
  telecom?: Array<{
    system?: 'phone' | 'email' | 'fax' | 'pager' | 'url' | 'sms' | 'other'
    value?: string
    use?: 'home' | 'work' | 'temp' | 'old' | 'mobile'
  }>
  gender?: 'male' | 'female' | 'other' | 'unknown'
  birthDate?: string
  address?: Array<{
    use?: string
    type?: string
    text?: string
    line?: string[]
    city?: string
    district?: string
    state?: string
    postalCode?: string
    country?: string
  }>
  maritalStatus?: {
    coding?: Array<{
      system?: string
      code?: string
      display?: string
    }>
  }
  contact?: Array<{
    relationship?: Array<{
      coding?: Array<{
        system?: string
        code?: string
        display?: string
      }>
    }>
    name?: {
      family?: string
      given?: string[]
    }
    telecom?: Array<{
      system?: string
      value?: string
      use?: string
    }>
  }>
}

// FHIR DiagnosticReport resource
export interface FhirDiagnosticReport extends FhirResource {
  resourceType: 'DiagnosticReport'
  status: 'registered' | 'partial' | 'preliminary' | 'final' | 'amended' | 'corrected' | 'appended' | 'cancelled' | 'entered-in-error' | 'unknown'
  category?: Array<{
    coding?: Array<{
      system?: string
      code?: string
      display?: string
    }>
  }>
  code: {
    coding?: Array<{
      system?: string
      code?: string
      display?: string
    }>
    text?: string
  }
  subject?: {
    reference?: string
    display?: string
  }
  encounter?: {
    reference?: string
  }
  effectiveDateTime?: string
  issued?: string
  performer?: Array<{
    reference?: string
    display?: string
  }>
  result?: Array<{
    reference?: string
    display?: string
  }>
  conclusion?: string
  conclusionCode?: Array<{
    coding?: Array<{
      system?: string
      code?: string
      display?: string
    }>
  }>
}

// FHIR Observation resource
export interface FhirObservation extends FhirResource {
  resourceType: 'Observation'
  status: 'registered' | 'preliminary' | 'final' | 'amended' | 'corrected' | 'cancelled' | 'entered-in-error' | 'unknown'
  category?: Array<{
    coding?: Array<{
      system?: string
      code?: string
      display?: string
    }>
  }>
  code: {
    coding?: Array<{
      system?: string
      code?: string
      display?: string
    }>
    text?: string
  }
  subject?: {
    reference?: string
    display?: string
  }
  encounter?: {
    reference?: string
  }
  effectiveDateTime?: string
  valueQuantity?: {
    value?: number
    unit?: string
    system?: string
    code?: string
  }
  valueCodeableConcept?: {
    coding?: Array<{
      system?: string
      code?: string
      display?: string
    }>
    text?: string
  }
  valueString?: string
  valueBoolean?: boolean
  valueInteger?: number
  valueRange?: {
    low?: {
      value?: number
      unit?: string
    }
    high?: {
      value?: number
      unit?: string
    }
  }
  component?: Array<{
    code: {
      coding?: Array<{
        system?: string
        code?: string
        display?: string
      }>
    }
    valueQuantity?: {
      value?: number
      unit?: string
    }
    valueString?: string
  }>
  referenceRange?: Array<{
    low?: {
      value?: number
      unit?: string
    }
    high?: {
      value?: number
      unit?: string
    }
    text?: string
  }>
}

/**
 * Convert internal patient data to FHIR Patient resource
 */
export const toFhirPatient = (patient: any): FhirPatient => {
  return {
    resourceType: 'Patient',
    id: patient.id,
    identifier: [
      {
        use: 'usual',
        type: {
          coding: [
            {
              system: 'http://terminology.hl7.org/CodeSystem/v2-0203',
              code: 'MR',
              display: 'Medical Record Number'
            }
          ]
        },
        system: 'urn:oid:1.2.36.146.595.217.0.1',
        value: patient.mrn
      }
    ],
    name: [
      {
        use: 'official',
        family: patient.lastName,
        given: [patient.firstName]
      }
    ],
    telecom: [
      ...(patient.phone ? [{
        system: 'phone' as const,
        value: patient.phone,
        use: 'home' as const
      }] : []),
      ...(patient.email ? [{
        system: 'email' as const,
        value: patient.email,
        use: 'home' as const
      }] : [])
    ],
    gender: patient.gender?.toLowerCase() as 'male' | 'female' | 'other' | 'unknown',
    birthDate: patient.dateOfBirth ? new Date(patient.dateOfBirth).toISOString().split('T')[0] : undefined,
    address: patient.address ? [
      {
        use: 'home',
        type: 'physical',
        text: patient.address
      }
    ] : []
  }
}

/**
 * Convert FHIR Patient resource to internal patient data
 */
export const fromFhirPatient = (fhirPatient: FhirPatient): any => {
  const name = fhirPatient.name?.[0]
  const phone = fhirPatient.telecom?.find(t => t.system === 'phone')?.value
  const email = fhirPatient.telecom?.find(t => t.system === 'email')?.value
  const address = fhirPatient.address?.[0]?.text
  const mrn = fhirPatient.identifier?.find(i => i.type?.coding?.[0]?.code === 'MR')?.value

  return {
    id: fhirPatient.id,
    mrn,
    firstName: name?.given?.[0] || '',
    lastName: name?.family || '',
    gender: fhirPatient.gender,
    dateOfBirth: fhirPatient.birthDate ? new Date(fhirPatient.birthDate) : null,
    phone,
    email,
    address
  }
}

/**
 * Create FHIR DiagnosticReport from lab results
 */
export const createFhirDiagnosticReport = (labResult: any): FhirDiagnosticReport => {
  return {
    resourceType: 'DiagnosticReport',
    id: labResult.id,
    status: labResult.status || 'final',
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/v2-0074',
            code: 'LAB',
            display: 'Laboratory'
          }
        ]
      }
    ],
    code: {
      coding: [
        {
          system: 'http://loinc.org',
          code: labResult.testCode || 'unknown',
          display: labResult.testName || 'Laboratory Test'
        }
      ],
      text: labResult.testName
    },
    subject: {
      reference: `Patient/${labResult.patientId}`,
      display: labResult.patientName
    },
    effectiveDateTime: labResult.collectedAt ? new Date(labResult.collectedAt).toISOString() : undefined,
    issued: labResult.reportedAt ? new Date(labResult.reportedAt).toISOString() : undefined,
    performer: labResult.performedBy ? [
      {
        reference: `Practitioner/${labResult.performedBy}`,
        display: labResult.performerName
      }
    ] : [],
    conclusion: labResult.interpretation,
    result: labResult.observations?.map((obs: any) => ({
      reference: `Observation/${obs.id}`,
      display: obs.name
    })) || []
  }
}

/**
 * Create FHIR Observation from lab test result
 */
export const createFhirObservation = (testResult: any): FhirObservation => {
  return {
    resourceType: 'Observation',
    id: testResult.id,
    status: testResult.status || 'final',
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/observation-category',
            code: 'laboratory',
            display: 'Laboratory'
          }
        ]
      }
    ],
    code: {
      coding: [
        {
          system: 'http://loinc.org',
          code: testResult.code || 'unknown',
          display: testResult.name
        }
      ],
      text: testResult.name
    },
    subject: {
      reference: `Patient/${testResult.patientId}`,
      display: testResult.patientName
    },
    effectiveDateTime: testResult.collectedAt ? new Date(testResult.collectedAt).toISOString() : undefined,
    valueQuantity: testResult.numericValue ? {
      value: testResult.numericValue,
      unit: testResult.unit,
      system: 'http://unitsofmeasure.org',
      code: testResult.ucumCode
    } : undefined,
    valueString: testResult.textValue,
    referenceRange: testResult.referenceRange ? [
      {
        low: testResult.referenceRange.low ? {
          value: testResult.referenceRange.low,
          unit: testResult.unit
        } : undefined,
        high: testResult.referenceRange.high ? {
          value: testResult.referenceRange.high,
          unit: testResult.unit
        } : undefined,
        text: testResult.referenceRange.text
      }
    ] : []
  }
}

/**
 * Validate FHIR resource
 */
export const validateFhirResource = (resource: FhirResource): { valid: boolean; errors: string[] } => {
  const errors: string[] = []

  if (!resource.resourceType) {
    errors.push('resourceType is required')
  }

  // Add more validation rules as needed
  switch (resource.resourceType) {
    case 'Patient':
      const patient = resource as FhirPatient
      if (!patient.name || patient.name.length === 0) {
        errors.push('Patient name is required')
      }
      break
    
    case 'DiagnosticReport':
      const report = resource as FhirDiagnosticReport
      if (!report.status) {
        errors.push('DiagnosticReport status is required')
      }
      if (!report.code) {
        errors.push('DiagnosticReport code is required')
      }
      break
    
    case 'Observation':
      const obs = resource as FhirObservation
      if (!obs.status) {
        errors.push('Observation status is required')
      }
      if (!obs.code) {
        errors.push('Observation code is required')
      }
      break
  }

  return {
    valid: errors.length === 0,
    errors
  }
}

/**
 * FHIR Bundle for multiple resources
 */
export interface FhirBundle {
  resourceType: 'Bundle'
  id?: string
  type: 'document' | 'message' | 'transaction' | 'transaction-response' | 'batch' | 'batch-response' | 'history' | 'searchset' | 'collection'
  total?: number
  entry?: Array<{
    resource?: FhirResource
    fullUrl?: string
    search?: {
      mode?: string
      score?: number
    }
  }>
}

/**
 * Create FHIR Bundle from multiple resources
 */
export const createFhirBundle = (resources: FhirResource[], type: FhirBundle['type'] = 'collection'): FhirBundle => {
  return {
    resourceType: 'Bundle',
    type,
    total: resources.length,
    entry: resources.map(resource => ({
      resource,
      fullUrl: `${resource.resourceType}/${resource.id}`
    }))
  }
}

// Export all FHIR utilities
export const FhirUtils = {
  toFhirPatient,
  fromFhirPatient,
  createFhirDiagnosticReport,
  createFhirObservation,
  validateFhirResource,
  createFhirBundle
}
