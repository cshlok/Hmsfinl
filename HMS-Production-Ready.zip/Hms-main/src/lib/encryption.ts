/**
 * Encryption utilities for Hospital Management System
 * Provides secure encryption/decryption for sensitive medical data
 * Compliant with HIPAA security requirements
 */

import { createCipheriv, createDecipheriv, randomBytes, pbkdf2Sync } from 'crypto'

// Encryption configuration
const ALGORITHM = 'aes-256-gcm'
const KEY_LENGTH = 32 // 256 bits
const IV_LENGTH = 16 // 128 bits
const SALT_LENGTH = 64 // 512 bits
const TAG_LENGTH = 16 // 128 bits
const ITERATIONS = 100000 // PBKDF2 iterations

// Get encryption key from environment
const getEncryptionKey = (): string => {
  const key = process.env.ENCRYPTION_KEY
  if (!key) {
    throw new Error('ENCRYPTION_KEY environment variable is required')
  }
  if (key.length < 32) {
    throw new Error('ENCRYPTION_KEY must be at least 32 characters long')
  }
  return key
}

// Derive key from password using PBKDF2
const deriveKey = (password: string, salt: Buffer): Buffer => {
  return pbkdf2Sync(password, salt, ITERATIONS, KEY_LENGTH, 'sha512')
}

/**
 * Encrypt sensitive data
 */
export const encrypt = (plaintext: string): string => {
  try {
    const password = getEncryptionKey()
    const salt = randomBytes(SALT_LENGTH)
    const iv = randomBytes(IV_LENGTH)
    const key = deriveKey(password, salt)
    
    const cipher = createCipheriv(ALGORITHM, key, iv)
    
    let encrypted = cipher.update(plaintext, 'utf8', 'hex')
    encrypted += cipher.final('hex')
    
    const tag = cipher.getAuthTag()
    
    // Combine salt + iv + tag + encrypted data
    const combined = Buffer.concat([
      salt,
      iv,
      tag,
      Buffer.from(encrypted, 'hex')
    ])
    
    return combined.toString('base64')
  } catch (error) {
    console.error('Encryption error:', error)
    throw new Error('Failed to encrypt data')
  }
}

/**
 * Decrypt sensitive data
 */
export const decrypt = (encryptedData: string): string => {
  try {
    const password = getEncryptionKey()
    const combined = Buffer.from(encryptedData, 'base64')
    
    // Extract components
    const salt = combined.subarray(0, SALT_LENGTH)
    const iv = combined.subarray(SALT_LENGTH, SALT_LENGTH + IV_LENGTH)
    const tag = combined.subarray(SALT_LENGTH + IV_LENGTH, SALT_LENGTH + IV_LENGTH + TAG_LENGTH)
    const encrypted = combined.subarray(SALT_LENGTH + IV_LENGTH + TAG_LENGTH)
    
    const key = deriveKey(password, salt)
    
    const decipher = createDecipheriv(ALGORITHM, key, iv)
    decipher.setAuthTag(tag)
    
    let decrypted = decipher.update(encrypted, undefined, 'utf8')
    decrypted += decipher.final('utf8')
    
    return decrypted
  } catch (error) {
    console.error('Decryption error:', error)
    throw new Error('Failed to decrypt data')
  }
}

/**
 * Hash sensitive data (one-way)
 */
export const hash = (data: string): string => {
  try {
    const salt = randomBytes(SALT_LENGTH)
    const password = getEncryptionKey()
    const key = deriveKey(data + password, salt)
    
    // Combine salt + hash
    const combined = Buffer.concat([salt, key])
    return combined.toString('base64')
  } catch (error) {
    console.error('Hashing error:', error)
    throw new Error('Failed to hash data')
  }
}

/**
 * Verify hashed data
 */
export const verifyHash = (data: string, hashedData: string): boolean => {
  try {
    const combined = Buffer.from(hashedData, 'base64')
    const salt = combined.subarray(0, SALT_LENGTH)
    const storedHash = combined.subarray(SALT_LENGTH)
    
    const password = getEncryptionKey()
    const key = deriveKey(data + password, salt)
    
    return key.equals(storedHash)
  } catch (error) {
    console.error('Hash verification error:', error)
    return false
  }
}

/**
 * Generate secure random token
 */
export const generateToken = (length = 32): string => {
  return randomBytes(length).toString('hex')
}

/**
 * Encrypt object (converts to JSON first)
 */
export const encryptObject = (obj: any): string => {
  const jsonString = JSON.stringify(obj)
  return encrypt(jsonString)
}

/**
 * Decrypt object (parses JSON after decryption)
 */
export const decryptObject = <T = any>(encryptedData: string): T => {
  const jsonString = decrypt(encryptedData)
  return JSON.parse(jsonString) as T
}

/**
 * Encrypt PII (Personally Identifiable Information)
 * Special handling for medical records
 */
export const encryptPII = (piiData: {
  ssn?: string
  dob?: string
  address?: string
  phone?: string
  email?: string
  medicalRecordNumber?: string
  [key: string]: any
}): Record<string, string> => {
  const encrypted: Record<string, string> = {}
  
  for (const [key, value] of Object.entries(piiData)) {
    if (value && typeof value === 'string') {
      encrypted[key] = encrypt(value)
    }
  }
  
  return encrypted
}

/**
 * Decrypt PII
 */
export const decryptPII = (encryptedPII: Record<string, string>): Record<string, string> => {
  const decrypted: Record<string, string> = {}
  
  for (const [key, value] of Object.entries(encryptedPII)) {
    if (value) {
      try {
        decrypted[key] = decrypt(value)
      } catch (error) {
        console.error(`Failed to decrypt PII field ${key}:`, error)
        decrypted[key] = '[ENCRYPTED]'
      }
    }
  }
  
  return decrypted
}

/**
 * Mask sensitive data for logging
 */
export const maskSensitiveData = (data: string, visibleChars = 4): string => {
  if (data.length <= visibleChars) {
    return '*'.repeat(data.length)
  }
  
  const masked = '*'.repeat(data.length - visibleChars)
  return masked + data.slice(-visibleChars)
}

/**
 * Validate encryption key strength
 */
export const validateEncryptionKey = (key: string): { valid: boolean; errors: string[] } => {
  const errors: string[] = []
  
  if (key.length < 32) {
    errors.push('Key must be at least 32 characters long')
  }
  
  if (!/[A-Z]/.test(key)) {
    errors.push('Key must contain uppercase letters')
  }
  
  if (!/[a-z]/.test(key)) {
    errors.push('Key must contain lowercase letters')
  }
  
  if (!/[0-9]/.test(key)) {
    errors.push('Key must contain numbers')
  }
  
  if (!/[^A-Za-z0-9]/.test(key)) {
    errors.push('Key must contain special characters')
  }
  
  return {
    valid: errors.length === 0,
    errors
  }
}

// Export encryption utilities
export const EncryptionUtils = {
  encrypt,
  decrypt,
  hash,
  verifyHash,
  generateToken,
  encryptObject,
  decryptObject,
  encryptPII,
  decryptPII,
  maskSensitiveData,
  validateEncryptionKey
}
