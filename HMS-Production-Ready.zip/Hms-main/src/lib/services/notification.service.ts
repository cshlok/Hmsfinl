/**
 * Notification Service Module
 * Comprehensive service for managing notifications across the Hospital Management System
 * Supports multiple notification types and delivery channels
 */

import { prisma } from '@/lib/prisma';
import { auditLog } from '@/lib/audit';
import { logger } from '@/lib/logger';

// Types for notification operations
export interface NotificationDetails {
  id: string;
  recipientId: string;
  recipientType: 'patient' | 'staff' | 'doctor' | 'nurse' | 'admin';
  type: 'appointment' | 'medication' | 'lab_result' | 'critical_alert' | 'discharge' | 'billing' | 'system';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  channel: 'in_app' | 'email' | 'sms' | 'push' | 'phone';
  status: 'pending' | 'sent' | 'delivered' | 'read' | 'failed';
  metadata?: Record<string, any>;
  scheduledAt?: Date;
  sentAt?: Date;
  deliveredAt?: Date;
  readAt?: Date;
  expiresAt?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface NotificationTemplate {
  id: string;
  name: string;
  type: string;
  channel: string;
  subject: string;
  template: string;
  variables: string[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface NotificationPreferences {
  id: string;
  userId: string;
  userType: 'patient' | 'staff';
  preferences: {
    [notificationType: string]: {
      enabled: boolean;
      channels: string[];
    };
  };
  updatedAt: Date;
}

/**
 * Send a notification to a recipient
 */
export async function sendNotification(notificationData: {
  recipientId: string;
  recipientType: 'patient' | 'staff' | 'doctor' | 'nurse' | 'admin';
  type: 'appointment' | 'medication' | 'lab_result' | 'critical_alert' | 'discharge' | 'billing' | 'system';
  title: string;
  message: string;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  channel?: 'in_app' | 'email' | 'sms' | 'push' | 'phone';
  metadata?: Record<string, any>;
  scheduledAt?: Date;
  expiresAt?: Date;
}, userId?: string): Promise<NotificationDetails> {
  try {
    logger.info(`Sending notification`, { notificationData, userId });

    const notification = await prisma.notification.create({
      data: {
        recipientId: notificationData.recipientId,
        recipientType: notificationData.recipientType,
        type: notificationData.type,
        title: notificationData.title,
        message: notificationData.message,
        priority: notificationData.priority || 'medium',
        channel: notificationData.channel || 'in_app',
        status: notificationData.scheduledAt ? 'pending' : 'sent',
        metadata: notificationData.metadata || {},
        scheduledAt: notificationData.scheduledAt,
        sentAt: notificationData.scheduledAt ? undefined : new Date(),
        expiresAt: notificationData.expiresAt,
        isActive: true
      }
    });

    // If not scheduled for later, attempt immediate delivery
    if (!notificationData.scheduledAt) {
      await deliverNotification(notification.id, userId);
    }

    // Audit log for notification creation
    await auditLog({
      userId: userId || 'system',
      action: 'SEND_NOTIFICATION',
      resourceType: 'Notification',
      resourceId: notification.id,
      details: { 
        recipientId: notificationData.recipientId,
        type: notificationData.type,
        priority: notificationData.priority,
        channel: notificationData.channel
      }
    });

    return mapToNotificationDetails(notification);

  } catch (error) {
    logger.error('Error sending notification:', error, { notificationData, userId });
    throw new Error('Failed to send notification');
  }
}

/**
 * Send bulk notifications to multiple recipients
 */
export async function sendBulkNotifications(notifications: Array<{
  recipientId: string;
  recipientType: 'patient' | 'staff' | 'doctor' | 'nurse' | 'admin';
  type: 'appointment' | 'medication' | 'lab_result' | 'critical_alert' | 'discharge' | 'billing' | 'system';
  title: string;
  message: string;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  channel?: 'in_app' | 'email' | 'sms' | 'push' | 'phone';
  metadata?: Record<string, any>;
}>, userId?: string): Promise<NotificationDetails[]> {
  try {
    logger.info(`Sending bulk notifications`, { count: notifications.length, userId });

    const createdNotifications = await prisma.notification.createMany({
      data: notifications.map(notification => ({
        recipientId: notification.recipientId,
        recipientType: notification.recipientType,
        type: notification.type,
        title: notification.title,
        message: notification.message,
        priority: notification.priority || 'medium',
        channel: notification.channel || 'in_app',
        status: 'sent',
        metadata: notification.metadata || {},
        sentAt: new Date(),
        isActive: true
      }))
    });

    // Get the created notifications
    const createdNotificationRecords = await prisma.notification.findMany({
      where: {
        createdAt: {
          gte: new Date(Date.now() - 5000) // Last 5 seconds
        }
      },
      orderBy: { createdAt: 'desc' },
      take: notifications.length
    });

    // Audit log for bulk notification
    await auditLog({
      userId: userId || 'system',
      action: 'SEND_BULK_NOTIFICATIONS',
      resourceType: 'Notification',
      resourceId: 'bulk',
      details: { 
        notificationCount: notifications.length,
        types: [...new Set(notifications.map(n => n.type))]
      }
    });

    return createdNotificationRecords.map(mapToNotificationDetails);

  } catch (error) {
    logger.error('Error sending bulk notifications:', error, { count: notifications.length, userId });
    throw new Error('Failed to send bulk notifications');
  }
}

/**
 * Get notifications for a user
 */
export async function getUserNotifications(
  recipientId: string, 
  userId?: string,
  options?: {
    limit?: number;
    offset?: number;
    status?: 'pending' | 'sent' | 'delivered' | 'read' | 'failed';
    type?: string;
    unreadOnly?: boolean;
  }
): Promise<NotificationDetails[]> {
  try {
    logger.info(`Fetching user notifications`, { recipientId, userId, options });

    const whereClause: any = {
      recipientId,
      isActive: true
    };

    if (options?.status) {
      whereClause.status = options.status;
    }

    if (options?.type) {
      whereClause.type = options.type;
    }

    if (options?.unreadOnly) {
      whereClause.readAt = null;
    }

    const notifications = await prisma.notification.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      take: options?.limit || 50,
      skip: options?.offset || 0
    });

    // Audit log for notification access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_USER_NOTIFICATIONS',
      resourceType: 'Notification',
      resourceId: recipientId,
      details: { 
        recipientId,
        notificationCount: notifications.length,
        filters: options
      }
    });

    return notifications.map(mapToNotificationDetails);

  } catch (error) {
    logger.error('Error fetching user notifications:', error, { recipientId, userId });
    throw new Error('Failed to fetch user notifications');
  }
}

/**
 * Mark notification as read
 */
export async function markNotificationAsRead(notificationId: string, userId?: string): Promise<NotificationDetails> {
  try {
    logger.info(`Marking notification as read`, { notificationId, userId });

    const notification = await prisma.notification.update({
      where: { id: notificationId },
      data: {
        status: 'read',
        readAt: new Date(),
        updatedAt: new Date()
      }
    });

    // Audit log for notification read
    await auditLog({
      userId: userId || 'system',
      action: 'READ_NOTIFICATION',
      resourceType: 'Notification',
      resourceId: notificationId,
      details: { notificationId }
    });

    return mapToNotificationDetails(notification);

  } catch (error) {
    logger.error('Error marking notification as read:', error, { notificationId, userId });
    throw new Error('Failed to mark notification as read');
  }
}

/**
 * Mark multiple notifications as read
 */
export async function markNotificationsAsRead(notificationIds: string[], userId?: string): Promise<number> {
  try {
    logger.info(`Marking multiple notifications as read`, { count: notificationIds.length, userId });

    const result = await prisma.notification.updateMany({
      where: {
        id: { in: notificationIds }
      },
      data: {
        status: 'read',
        readAt: new Date(),
        updatedAt: new Date()
      }
    });

    // Audit log for bulk notification read
    await auditLog({
      userId: userId || 'system',
      action: 'READ_NOTIFICATIONS_BULK',
      resourceType: 'Notification',
      resourceId: 'bulk',
      details: { 
        notificationIds,
        updatedCount: result.count
      }
    });

    return result.count;

  } catch (error) {
    logger.error('Error marking notifications as read:', error, { notificationIds, userId });
    throw new Error('Failed to mark notifications as read');
  }
}

/**
 * Send critical alert notification
 */
export async function sendCriticalAlert(alertData: {
  recipientId: string;
  recipientType: 'patient' | 'staff' | 'doctor' | 'nurse' | 'admin';
  title: string;
  message: string;
  alertType: string;
  patientId?: string;
  metadata?: Record<string, any>;
}, userId?: string): Promise<NotificationDetails> {
  try {
    logger.info(`Sending critical alert`, { alertData, userId });

    // Send critical alert via multiple channels
    const notification = await sendNotification({
      recipientId: alertData.recipientId,
      recipientType: alertData.recipientType,
      type: 'critical_alert',
      title: alertData.title,
      message: alertData.message,
      priority: 'critical',
      channel: 'in_app', // Primary channel
      metadata: {
        ...alertData.metadata,
        alertType: alertData.alertType,
        patientId: alertData.patientId
      }
    }, userId);

    // Also send via email and SMS if configured
    const emailNotification = await sendNotification({
      recipientId: alertData.recipientId,
      recipientType: alertData.recipientType,
      type: 'critical_alert',
      title: alertData.title,
      message: alertData.message,
      priority: 'critical',
      channel: 'email',
      metadata: {
        ...alertData.metadata,
        alertType: alertData.alertType,
        patientId: alertData.patientId
      }
    }, userId);

    logger.warn(`Critical alert sent`, { 
      notificationId: notification.id,
      emailNotificationId: emailNotification.id,
      alertType: alertData.alertType,
      patientId: alertData.patientId
    });

    return notification;

  } catch (error) {
    logger.error('Error sending critical alert:', error, { alertData, userId });
    throw new Error('Failed to send critical alert');
  }
}

/**
 * Get unread notification count for a user
 */
export async function getUnreadNotificationCount(recipientId: string, userId?: string): Promise<number> {
  try {
    logger.info(`Getting unread notification count`, { recipientId, userId });

    const count = await prisma.notification.count({
      where: {
        recipientId,
        readAt: null,
        isActive: true
      }
    });

    return count;

  } catch (error) {
    logger.error('Error getting unread notification count:', error, { recipientId, userId });
    throw new Error('Failed to get unread notification count');
  }
}

/**
 * Schedule a notification for future delivery
 */
export async function scheduleNotification(notificationData: {
  recipientId: string;
  recipientType: 'patient' | 'staff' | 'doctor' | 'nurse' | 'admin';
  type: 'appointment' | 'medication' | 'lab_result' | 'critical_alert' | 'discharge' | 'billing' | 'system';
  title: string;
  message: string;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  channel?: 'in_app' | 'email' | 'sms' | 'push' | 'phone';
  scheduledAt: Date;
  metadata?: Record<string, any>;
}, userId?: string): Promise<NotificationDetails> {
  try {
    logger.info(`Scheduling notification`, { notificationData, userId });

    return await sendNotification({
      ...notificationData,
      scheduledAt: notificationData.scheduledAt
    }, userId);

  } catch (error) {
    logger.error('Error scheduling notification:', error, { notificationData, userId });
    throw new Error('Failed to schedule notification');
  }
}

/**
 * Internal function to deliver a notification
 */
async function deliverNotification(notificationId: string, userId?: string): Promise<void> {
  try {
    const notification = await prisma.notification.findUnique({
      where: { id: notificationId }
    });

    if (!notification) {
      throw new Error('Notification not found');
    }

    // Simulate delivery based on channel
    let deliverySuccess = true;
    
    switch (notification.channel) {
      case 'in_app':
        // In-app notifications are delivered immediately
        break;
      case 'email':
        // Simulate email delivery
        logger.info(`Simulating email delivery for notification ${notificationId}`);
        break;
      case 'sms':
        // Simulate SMS delivery
        logger.info(`Simulating SMS delivery for notification ${notificationId}`);
        break;
      case 'push':
        // Simulate push notification delivery
        logger.info(`Simulating push notification delivery for notification ${notificationId}`);
        break;
      default:
        logger.warn(`Unknown notification channel: ${notification.channel}`);
        deliverySuccess = false;
    }

    // Update notification status
    await prisma.notification.update({
      where: { id: notificationId },
      data: {
        status: deliverySuccess ? 'delivered' : 'failed',
        deliveredAt: deliverySuccess ? new Date() : undefined,
        updatedAt: new Date()
      }
    });

  } catch (error) {
    logger.error('Error delivering notification:', error, { notificationId, userId });
    
    // Mark as failed
    await prisma.notification.update({
      where: { id: notificationId },
      data: {
        status: 'failed',
        updatedAt: new Date()
      }
    });
  }
}

/**
 * Helper function to map database record to NotificationDetails
 */
function mapToNotificationDetails(notification: any): NotificationDetails {
  return {
    id: notification.id,
    recipientId: notification.recipientId,
    recipientType: notification.recipientType,
    type: notification.type,
    title: notification.title,
    message: notification.message,
    priority: notification.priority,
    channel: notification.channel,
    status: notification.status,
    metadata: notification.metadata || {},
    scheduledAt: notification.scheduledAt,
    sentAt: notification.sentAt,
    deliveredAt: notification.deliveredAt,
    readAt: notification.readAt,
    expiresAt: notification.expiresAt,
    isActive: notification.isActive,
    createdAt: notification.createdAt,
    updatedAt: notification.updatedAt
  };
}

// Export additional utility functions
export {
  type NotificationDetails,
  type NotificationTemplate,
  type NotificationPreferences
};

// Export the NotificationService class for compatibility
export class NotificationService {
  static async send(notificationData: Parameters<typeof sendNotification>[0], userId?: string) {
    return sendNotification(notificationData, userId);
  }

  static async sendBulk(notifications: Parameters<typeof sendBulkNotifications>[0], userId?: string) {
    return sendBulkNotifications(notifications, userId);
  }

  static async getUserNotifications(recipientId: string, userId?: string, options?: Parameters<typeof getUserNotifications>[2]) {
    return getUserNotifications(recipientId, userId, options);
  }

  static async markAsRead(notificationId: string, userId?: string) {
    return markNotificationAsRead(notificationId, userId);
  }

  static async getUnreadCount(recipientId: string, userId?: string) {
    return getUnreadNotificationCount(recipientId, userId);
  }

  static async sendCriticalAlert(alertData: Parameters<typeof sendCriticalAlert>[0], userId?: string) {
    return sendCriticalAlert(alertData, userId);
  }
}
