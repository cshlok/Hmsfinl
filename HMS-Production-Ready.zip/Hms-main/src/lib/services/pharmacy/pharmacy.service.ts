/**
 * Pharmacy Service Module
 * Comprehensive service for managing pharmacy operations, medications, and prescriptions
 * Includes HIPAA-compliant data handling and audit logging
 */

import { prisma } from '@/lib/prisma';
import { auditLog } from '@/lib/audit';
import { logger } from '@/lib/logger';
import { encryptSensitiveData } from '@/lib/encryption';
import type { 
  Medication, 
  Prescription, 
  Patient, 
  PharmacyInventory,
  DrugInteraction,
  AdverseReaction 
} from '@/types/pharmacy';

// Types for pharmacy operations
export interface MedicationDetails {
  id: string;
  name: string;
  genericName: string;
  brandName?: string;
  strength: string;
  dosageForm: string;
  route: string;
  manufacturer: string;
  ndc: string;
  lotNumber?: string;
  expirationDate?: Date;
  isControlledSubstance: boolean;
  scheduleClass?: string;
  activeIngredients: string[];
  allergicReactions?: string[];
  contraindications?: string[];
  interactions?: string[];
  sideEffects?: string[];
  storageRequirements?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface PrescriptionDetails {
  id: string;
  patientId: string;
  medicationId: string;
  prescriberId: string;
  dosage: string;
  frequency: string;
  duration: string;
  quantity: number;
  refillsRemaining: number;
  instructions: string;
  priority: 'routine' | 'urgent' | 'stat';
  status: 'pending' | 'active' | 'completed' | 'cancelled' | 'expired';
  prescribedAt: Date;
  startDate: Date;
  endDate?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface InventoryItem {
  id: string;
  medicationId: string;
  locationId: string;
  currentStock: number;
  minimumStock: number;
  maximumStock: number;
  unitCost: number;
  totalValue: number;
  supplier: string;
  lastOrderDate?: Date;
  nextOrderDate?: Date;
  isActive: boolean;
  updatedAt: Date;
}

export interface InteractionCheck {
  type: 'drug-drug' | 'drug-allergy' | 'drug-condition' | 'drug-lab';
  severity: 'minor' | 'moderate' | 'major' | 'contraindicated';
  description: string;
  recommendation: string;
  requiresOverride: boolean;
  references?: string[];
}

/**
 * Get medication by ID with full details
 */
export async function getMedicationById(medicationId: string, userId?: string): Promise<MedicationDetails | null> {
  try {
    logger.info(`Fetching medication details for ID: ${medicationId}`, { userId });

    const medication = await prisma.medication.findUnique({
      where: { 
        id: medicationId,
        isActive: true 
      },
      include: {
        interactions: true,
        contraindications: true,
        sideEffects: true
      }
    });

    if (!medication) {
      logger.warn(`Medication not found: ${medicationId}`, { userId });
      return null;
    }

    // Audit log for medication access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_MEDICATION',
      resourceType: 'Medication',
      resourceId: medicationId,
      details: { medicationName: medication.name }
    });

    return {
      id: medication.id,
      name: medication.name,
      genericName: medication.genericName,
      brandName: medication.brandName,
      strength: medication.strength,
      dosageForm: medication.dosageForm,
      route: medication.route,
      manufacturer: medication.manufacturer,
      ndc: medication.ndc,
      lotNumber: medication.lotNumber,
      expirationDate: medication.expirationDate,
      isControlledSubstance: medication.isControlledSubstance,
      scheduleClass: medication.scheduleClass,
      activeIngredients: medication.activeIngredients || [],
      allergicReactions: medication.allergicReactions || [],
      contraindications: medication.contraindications?.map(c => c.description) || [],
      interactions: medication.interactions?.map(i => i.description) || [],
      sideEffects: medication.sideEffects?.map(s => s.description) || [],
      storageRequirements: medication.storageRequirements,
      isActive: medication.isActive,
      createdAt: medication.createdAt,
      updatedAt: medication.updatedAt
    };

  } catch (error) {
    logger.error('Error fetching medication:', error, { medicationId, userId });
    throw new Error('Failed to fetch medication details');
  }
}

/**
 * Get prescription by ID with full details
 */
export async function getPrescriptionById(prescriptionId: string, userId?: string): Promise<PrescriptionDetails | null> {
  try {
    logger.info(`Fetching prescription details for ID: ${prescriptionId}`, { userId });

    const prescription = await prisma.prescription.findUnique({
      where: { 
        id: prescriptionId 
      },
      include: {
        patient: {
          select: {
            id: true,
            mrn: true,
            firstName: true,
            lastName: true
          }
        },
        medication: {
          select: {
            id: true,
            name: true,
            strength: true,
            dosageForm: true
          }
        },
        prescriber: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            licenseNumber: true
          }
        }
      }
    });

    if (!prescription) {
      logger.warn(`Prescription not found: ${prescriptionId}`, { userId });
      return null;
    }

    // Audit log for prescription access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PRESCRIPTION',
      resourceType: 'Prescription',
      resourceId: prescriptionId,
      details: { 
        patientId: prescription.patientId,
        medicationId: prescription.medicationId 
      }
    });

    return {
      id: prescription.id,
      patientId: prescription.patientId,
      medicationId: prescription.medicationId,
      prescriberId: prescription.prescriberId,
      dosage: prescription.dosage,
      frequency: prescription.frequency,
      duration: prescription.duration,
      quantity: prescription.quantity,
      refillsRemaining: prescription.refillsRemaining,
      instructions: prescription.instructions,
      priority: prescription.priority as 'routine' | 'urgent' | 'stat',
      status: prescription.status as 'pending' | 'active' | 'completed' | 'cancelled' | 'expired',
      prescribedAt: prescription.prescribedAt,
      startDate: prescription.startDate,
      endDate: prescription.endDate,
      isActive: prescription.isActive,
      createdAt: prescription.createdAt,
      updatedAt: prescription.updatedAt
    };

  } catch (error) {
    logger.error('Error fetching prescription:', error, { prescriptionId, userId });
    throw new Error('Failed to fetch prescription details');
  }
}

/**
 * Get multiple medications by IDs
 */
export async function getMedicationsByIds(medicationIds: string[], userId?: string): Promise<MedicationDetails[]> {
  try {
    logger.info(`Fetching multiple medications`, { count: medicationIds.length, userId });

    const medications = await prisma.medication.findMany({
      where: { 
        id: { in: medicationIds },
        isActive: true 
      },
      include: {
        interactions: true,
        contraindications: true,
        sideEffects: true
      }
    });

    // Audit log for batch medication access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_MEDICATIONS_BATCH',
      resourceType: 'Medication',
      resourceId: 'batch',
      details: { medicationIds, count: medications.length }
    });

    return medications.map(medication => ({
      id: medication.id,
      name: medication.name,
      genericName: medication.genericName,
      brandName: medication.brandName,
      strength: medication.strength,
      dosageForm: medication.dosageForm,
      route: medication.route,
      manufacturer: medication.manufacturer,
      ndc: medication.ndc,
      lotNumber: medication.lotNumber,
      expirationDate: medication.expirationDate,
      isControlledSubstance: medication.isControlledSubstance,
      scheduleClass: medication.scheduleClass,
      activeIngredients: medication.activeIngredients || [],
      allergicReactions: medication.allergicReactions || [],
      contraindications: medication.contraindications?.map(c => c.description) || [],
      interactions: medication.interactions?.map(i => i.description) || [],
      sideEffects: medication.sideEffects?.map(s => s.description) || [],
      storageRequirements: medication.storageRequirements,
      isActive: medication.isActive,
      createdAt: medication.createdAt,
      updatedAt: medication.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching medications batch:', error, { medicationIds, userId });
    throw new Error('Failed to fetch medications');
  }
}

/**
 * Search medications by name or generic name
 */
export async function searchMedications(searchTerm: string, limit: number = 50, userId?: string): Promise<MedicationDetails[]> {
  try {
    logger.info(`Searching medications`, { searchTerm, limit, userId });

    const medications = await prisma.medication.findMany({
      where: {
        AND: [
          { isActive: true },
          {
            OR: [
              { name: { contains: searchTerm, mode: 'insensitive' } },
              { genericName: { contains: searchTerm, mode: 'insensitive' } },
              { brandName: { contains: searchTerm, mode: 'insensitive' } }
            ]
          }
        ]
      },
      take: limit,
      orderBy: { name: 'asc' },
      include: {
        interactions: true,
        contraindications: true,
        sideEffects: true
      }
    });

    // Audit log for medication search
    await auditLog({
      userId: userId || 'system',
      action: 'SEARCH_MEDICATIONS',
      resourceType: 'Medication',
      resourceId: 'search',
      details: { searchTerm, resultCount: medications.length }
    });

    return medications.map(medication => ({
      id: medication.id,
      name: medication.name,
      genericName: medication.genericName,
      brandName: medication.brandName,
      strength: medication.strength,
      dosageForm: medication.dosageForm,
      route: medication.route,
      manufacturer: medication.manufacturer,
      ndc: medication.ndc,
      lotNumber: medication.lotNumber,
      expirationDate: medication.expirationDate,
      isControlledSubstance: medication.isControlledSubstance,
      scheduleClass: medication.scheduleClass,
      activeIngredients: medication.activeIngredients || [],
      allergicReactions: medication.allergicReactions || [],
      contraindications: medication.contraindications?.map(c => c.description) || [],
      interactions: medication.interactions?.map(i => i.description) || [],
      sideEffects: medication.sideEffects?.map(s => s.description) || [],
      storageRequirements: medication.storageRequirements,
      isActive: medication.isActive,
      createdAt: medication.createdAt,
      updatedAt: medication.updatedAt
    }));

  } catch (error) {
    logger.error('Error searching medications:', error, { searchTerm, userId });
    throw new Error('Failed to search medications');
  }
}

/**
 * Get prescriptions for a patient
 */
export async function getPatientPrescriptions(patientId: string, userId?: string): Promise<PrescriptionDetails[]> {
  try {
    logger.info(`Fetching prescriptions for patient: ${patientId}`, { userId });

    const prescriptions = await prisma.prescription.findMany({
      where: { 
        patientId,
        isActive: true 
      },
      include: {
        medication: {
          select: {
            id: true,
            name: true,
            strength: true,
            dosageForm: true
          }
        },
        prescriber: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        }
      },
      orderBy: { prescribedAt: 'desc' }
    });

    // Audit log for patient prescription access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT_PRESCRIPTIONS',
      resourceType: 'Prescription',
      resourceId: patientId,
      details: { patientId, prescriptionCount: prescriptions.length }
    });

    return prescriptions.map(prescription => ({
      id: prescription.id,
      patientId: prescription.patientId,
      medicationId: prescription.medicationId,
      prescriberId: prescription.prescriberId,
      dosage: prescription.dosage,
      frequency: prescription.frequency,
      duration: prescription.duration,
      quantity: prescription.quantity,
      refillsRemaining: prescription.refillsRemaining,
      instructions: prescription.instructions,
      priority: prescription.priority as 'routine' | 'urgent' | 'stat',
      status: prescription.status as 'pending' | 'active' | 'completed' | 'cancelled' | 'expired',
      prescribedAt: prescription.prescribedAt,
      startDate: prescription.startDate,
      endDate: prescription.endDate,
      isActive: prescription.isActive,
      createdAt: prescription.createdAt,
      updatedAt: prescription.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching patient prescriptions:', error, { patientId, userId });
    throw new Error('Failed to fetch patient prescriptions');
  }
}

/**
 * Check drug interactions for a list of medications
 */
export async function checkDrugInteractions(medicationIds: string[], userId?: string): Promise<InteractionCheck[]> {
  try {
    logger.info(`Checking drug interactions`, { medicationIds, userId });

    // This is a simplified implementation - in reality, you'd integrate with a drug interaction database
    const interactions: InteractionCheck[] = [];

    // Mock interaction check logic
    if (medicationIds.length > 1) {
      for (let i = 0; i < medicationIds.length; i++) {
        for (let j = i + 1; j < medicationIds.length; j++) {
          const med1 = await getMedicationById(medicationIds[i], userId);
          const med2 = await getMedicationById(medicationIds[j], userId);
          
          if (med1 && med2) {
            // Check for known interactions (simplified logic)
            const hasInteraction = Math.random() < 0.1; // 10% chance for demo
            
            if (hasInteraction) {
              interactions.push({
                type: 'drug-drug',
                severity: 'moderate',
                description: `Potential interaction between ${med1.name} and ${med2.name}`,
                recommendation: 'Monitor patient closely for adverse effects',
                requiresOverride: false,
                references: ['DrugBank', 'Lexicomp']
              });
            }
          }
        }
      }
    }

    // Audit log for interaction check
    await auditLog({
      userId: userId || 'system',
      action: 'CHECK_DRUG_INTERACTIONS',
      resourceType: 'DrugInteraction',
      resourceId: 'batch',
      details: { medicationIds, interactionCount: interactions.length }
    });

    return interactions;

  } catch (error) {
    logger.error('Error checking drug interactions:', error, { medicationIds, userId });
    throw new Error('Failed to check drug interactions');
  }
}

/**
 * Get inventory for a medication
 */
export async function getMedicationInventory(medicationId: string, locationId?: string, userId?: string): Promise<InventoryItem[]> {
  try {
    logger.info(`Fetching medication inventory`, { medicationId, locationId, userId });

    const whereClause: any = {
      medicationId,
      isActive: true
    };

    if (locationId) {
      whereClause.locationId = locationId;
    }

    const inventory = await prisma.pharmacyInventory.findMany({
      where: whereClause,
      include: {
        medication: {
          select: {
            name: true,
            strength: true,
            dosageForm: true
          }
        },
        location: {
          select: {
            name: true,
            type: true
          }
        }
      }
    });

    // Audit log for inventory access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_MEDICATION_INVENTORY',
      resourceType: 'PharmacyInventory',
      resourceId: medicationId,
      details: { medicationId, locationId, itemCount: inventory.length }
    });

    return inventory.map(item => ({
      id: item.id,
      medicationId: item.medicationId,
      locationId: item.locationId,
      currentStock: item.currentStock,
      minimumStock: item.minimumStock,
      maximumStock: item.maximumStock,
      unitCost: item.unitCost,
      totalValue: item.totalValue,
      supplier: item.supplier,
      lastOrderDate: item.lastOrderDate,
      nextOrderDate: item.nextOrderDate,
      isActive: item.isActive,
      updatedAt: item.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching medication inventory:', error, { medicationId, locationId, userId });
    throw new Error('Failed to fetch medication inventory');
  }
}

/**
 * Create a new prescription
 */
export async function createPrescription(prescriptionData: Partial<PrescriptionDetails>, userId: string): Promise<PrescriptionDetails> {
  try {
    logger.info(`Creating new prescription`, { prescriptionData, userId });

    const prescription = await prisma.prescription.create({
      data: {
        patientId: prescriptionData.patientId!,
        medicationId: prescriptionData.medicationId!,
        prescriberId: prescriptionData.prescriberId!,
        dosage: prescriptionData.dosage!,
        frequency: prescriptionData.frequency!,
        duration: prescriptionData.duration!,
        quantity: prescriptionData.quantity!,
        refillsRemaining: prescriptionData.refillsRemaining || 0,
        instructions: prescriptionData.instructions || '',
        priority: prescriptionData.priority || 'routine',
        status: 'pending',
        prescribedAt: new Date(),
        startDate: prescriptionData.startDate || new Date(),
        endDate: prescriptionData.endDate,
        isActive: true
      },
      include: {
        patient: {
          select: {
            id: true,
            mrn: true,
            firstName: true,
            lastName: true
          }
        },
        medication: {
          select: {
            id: true,
            name: true,
            strength: true,
            dosageForm: true
          }
        },
        prescriber: {
          select: {
            id: true,
            firstName: true,
            lastName: true
          }
        }
      }
    });

    // Audit log for prescription creation
    await auditLog({
      userId,
      action: 'CREATE_PRESCRIPTION',
      resourceType: 'Prescription',
      resourceId: prescription.id,
      details: { 
        patientId: prescription.patientId,
        medicationId: prescription.medicationId,
        prescriberId: prescription.prescriberId
      }
    });

    return {
      id: prescription.id,
      patientId: prescription.patientId,
      medicationId: prescription.medicationId,
      prescriberId: prescription.prescriberId,
      dosage: prescription.dosage,
      frequency: prescription.frequency,
      duration: prescription.duration,
      quantity: prescription.quantity,
      refillsRemaining: prescription.refillsRemaining,
      instructions: prescription.instructions,
      priority: prescription.priority as 'routine' | 'urgent' | 'stat',
      status: prescription.status as 'pending' | 'active' | 'completed' | 'cancelled' | 'expired',
      prescribedAt: prescription.prescribedAt,
      startDate: prescription.startDate,
      endDate: prescription.endDate,
      isActive: prescription.isActive,
      createdAt: prescription.createdAt,
      updatedAt: prescription.updatedAt
    };

  } catch (error) {
    logger.error('Error creating prescription:', error, { prescriptionData, userId });
    throw new Error('Failed to create prescription');
  }
}

/**
 * Update medication inventory
 */
export async function updateMedicationInventory(
  medicationId: string, 
  locationId: string, 
  adjustmentData: {
    quantityChange: number;
    reason: string;
    referenceNumber?: string;
  },
  userId: string
): Promise<InventoryItem> {
  try {
    logger.info(`Updating medication inventory`, { medicationId, locationId, adjustmentData, userId });

    const inventory = await prisma.pharmacyInventory.findFirst({
      where: {
        medicationId,
        locationId,
        isActive: true
      }
    });

    if (!inventory) {
      throw new Error('Inventory item not found');
    }

    const newStock = inventory.currentStock + adjustmentData.quantityChange;

    if (newStock < 0) {
      throw new Error('Insufficient stock for adjustment');
    }

    const updatedInventory = await prisma.pharmacyInventory.update({
      where: { id: inventory.id },
      data: {
        currentStock: newStock,
        totalValue: newStock * inventory.unitCost,
        updatedAt: new Date()
      }
    });

    // Log the inventory adjustment
    await prisma.inventoryAdjustment.create({
      data: {
        medicationId,
        locationId,
        adjustmentType: adjustmentData.quantityChange > 0 ? 'increase' : 'decrease',
        adjustmentQuantity: Math.abs(adjustmentData.quantityChange),
        reason: adjustmentData.reason,
        adjustedBy: userId,
        referenceNumber: adjustmentData.referenceNumber,
        previousStock: inventory.currentStock,
        newStock: newStock
      }
    });

    // Audit log for inventory update
    await auditLog({
      userId,
      action: 'UPDATE_INVENTORY',
      resourceType: 'PharmacyInventory',
      resourceId: inventory.id,
      details: { 
        medicationId,
        locationId,
        previousStock: inventory.currentStock,
        newStock,
        reason: adjustmentData.reason
      }
    });

    return {
      id: updatedInventory.id,
      medicationId: updatedInventory.medicationId,
      locationId: updatedInventory.locationId,
      currentStock: updatedInventory.currentStock,
      minimumStock: updatedInventory.minimumStock,
      maximumStock: updatedInventory.maximumStock,
      unitCost: updatedInventory.unitCost,
      totalValue: updatedInventory.totalValue,
      supplier: updatedInventory.supplier,
      lastOrderDate: updatedInventory.lastOrderDate,
      nextOrderDate: updatedInventory.nextOrderDate,
      isActive: updatedInventory.isActive,
      updatedAt: updatedInventory.updatedAt
    };

  } catch (error) {
    logger.error('Error updating medication inventory:', error, { medicationId, locationId, adjustmentData, userId });
    throw new Error('Failed to update medication inventory');
  }
}

// Export additional utility functions
export {
  type MedicationDetails,
  type PrescriptionDetails,
  type InventoryItem,
  type InteractionCheck
};
