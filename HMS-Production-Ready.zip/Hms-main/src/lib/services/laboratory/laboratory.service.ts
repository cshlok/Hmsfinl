/**
 * Laboratory Service Module
 * Comprehensive service for managing laboratory operations, tests, and results
 * Includes HIPAA-compliant data handling and audit logging
 */

import { prisma } from '@/lib/prisma';
import { auditLog } from '@/lib/audit';
import { logger } from '@/lib/logger';
import { encryptSensitiveData } from '@/lib/encryption';

// Types for laboratory operations
export interface LabTestDetails {
  id: string;
  name: string;
  code: string;
  category: string;
  department: string;
  specimen: string;
  method?: string;
  normalRange?: string;
  unit?: string;
  turnaroundTime?: number; // in hours
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface LabOrderDetails {
  id: string;
  patientId: string;
  orderedBy: string;
  testIds: string[];
  priority: 'routine' | 'urgent' | 'stat';
  status: 'pending' | 'collected' | 'processing' | 'completed' | 'cancelled';
  orderedAt: Date;
  scheduledAt?: Date;
  collectedAt?: Date;
  completedAt?: Date;
  instructions?: string;
  clinicalInfo?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface LabResultDetails {
  id: string;
  orderId: string;
  patientId: string;
  testId: string;
  testName: string;
  testCode?: string;
  category: string;
  value: string;
  unit?: string;
  referenceRange?: string;
  status: 'normal' | 'abnormal' | 'critical' | 'pending';
  flags?: string[];
  orderedBy?: string;
  performedBy?: string;
  verifiedBy?: string;
  orderedAt: Date;
  collectedAt?: Date;
  resultedAt?: Date;
  verifiedAt?: Date;
  notes?: string;
  criticalValue?: boolean;
  deltaCheck?: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface SpecimenDetails {
  id: string;
  orderId: string;
  patientId: string;
  type: string;
  containerType: string;
  collectionMethod: string;
  collectedBy: string;
  collectedAt: Date;
  volume?: string;
  quality: 'adequate' | 'inadequate' | 'clotted' | 'hemolyzed';
  storageConditions?: string;
  transportConditions?: string;
  barcode?: string;
  location?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Get patient lab results with filtering and pagination
 */
export async function getPatientLabResults(
  patientId: string, 
  userId?: string,
  options?: {
    limit?: number;
    offset?: number;
    startDate?: Date;
    endDate?: Date;
    category?: string;
    status?: string;
  }
): Promise<LabResultDetails[]> {
  try {
    logger.info(`Fetching lab results for patient: ${patientId}`, { userId, options });

    const whereClause: any = {
      patientId,
      isActive: true
    };

    if (options?.startDate || options?.endDate) {
      whereClause.resultedAt = {};
      if (options.startDate) {
        whereClause.resultedAt.gte = options.startDate;
      }
      if (options.endDate) {
        whereClause.resultedAt.lte = options.endDate;
      }
    }

    if (options?.category) {
      whereClause.category = options.category;
    }

    if (options?.status) {
      whereClause.status = options.status;
    }

    const labResults = await prisma.labResult.findMany({
      where: whereClause,
      orderBy: { resultedAt: 'desc' },
      take: options?.limit || 100,
      skip: options?.offset || 0,
      include: {
        order: {
          select: {
            id: true,
            priority: true,
            orderedBy: true
          }
        },
        test: {
          select: {
            name: true,
            code: true,
            category: true,
            normalRange: true,
            unit: true
          }
        }
      }
    });

    // Audit log for lab results access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT_LAB_RESULTS',
      resourceType: 'LabResult',
      resourceId: patientId,
      details: { 
        patientId, 
        resultCount: labResults.length,
        filters: options
      }
    });

    return labResults.map(result => ({
      id: result.id,
      orderId: result.orderId,
      patientId: result.patientId,
      testId: result.testId,
      testName: result.test?.name || result.testName,
      testCode: result.test?.code || result.testCode,
      category: result.test?.category || result.category,
      value: result.value,
      unit: result.test?.unit || result.unit,
      referenceRange: result.test?.normalRange || result.referenceRange,
      status: result.status as 'normal' | 'abnormal' | 'critical' | 'pending',
      flags: result.flags || [],
      orderedBy: result.order?.orderedBy || result.orderedBy,
      performedBy: result.performedBy,
      verifiedBy: result.verifiedBy,
      orderedAt: result.orderedAt,
      collectedAt: result.collectedAt,
      resultedAt: result.resultedAt,
      verifiedAt: result.verifiedAt,
      notes: result.notes,
      criticalValue: result.criticalValue,
      deltaCheck: result.deltaCheck,
      isActive: result.isActive,
      createdAt: result.createdAt,
      updatedAt: result.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching patient lab results:', error, { patientId, userId });
    throw new Error('Failed to fetch patient lab results');
  }
}

/**
 * Get lab test by ID
 */
export async function getLabTestById(testId: string, userId?: string): Promise<LabTestDetails | null> {
  try {
    logger.info(`Fetching lab test details for ID: ${testId}`, { userId });

    const labTest = await prisma.labTest.findUnique({
      where: { 
        id: testId,
        isActive: true 
      }
    });

    if (!labTest) {
      logger.warn(`Lab test not found: ${testId}`, { userId });
      return null;
    }

    // Audit log for lab test access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_LAB_TEST',
      resourceType: 'LabTest',
      resourceId: testId,
      details: { testName: labTest.name, testCode: labTest.code }
    });

    return {
      id: labTest.id,
      name: labTest.name,
      code: labTest.code,
      category: labTest.category,
      department: labTest.department,
      specimen: labTest.specimen,
      method: labTest.method,
      normalRange: labTest.normalRange,
      unit: labTest.unit,
      turnaroundTime: labTest.turnaroundTime,
      isActive: labTest.isActive,
      createdAt: labTest.createdAt,
      updatedAt: labTest.updatedAt
    };

  } catch (error) {
    logger.error('Error fetching lab test:', error, { testId, userId });
    throw new Error('Failed to fetch lab test details');
  }
}

/**
 * Search lab tests by name or code
 */
export async function searchLabTests(searchTerm: string, category?: string, limit: number = 50, userId?: string): Promise<LabTestDetails[]> {
  try {
    logger.info(`Searching lab tests`, { searchTerm, category, limit, userId });

    const whereClause: any = {
      isActive: true,
      OR: [
        { name: { contains: searchTerm, mode: 'insensitive' } },
        { code: { contains: searchTerm, mode: 'insensitive' } }
      ]
    };

    if (category) {
      whereClause.category = category;
    }

    const labTests = await prisma.labTest.findMany({
      where: whereClause,
      take: limit,
      orderBy: { name: 'asc' }
    });

    // Audit log for lab test search
    await auditLog({
      userId: userId || 'system',
      action: 'SEARCH_LAB_TESTS',
      resourceType: 'LabTest',
      resourceId: 'search',
      details: { searchTerm, category, resultCount: labTests.length }
    });

    return labTests.map(test => ({
      id: test.id,
      name: test.name,
      code: test.code,
      category: test.category,
      department: test.department,
      specimen: test.specimen,
      method: test.method,
      normalRange: test.normalRange,
      unit: test.unit,
      turnaroundTime: test.turnaroundTime,
      isActive: test.isActive,
      createdAt: test.createdAt,
      updatedAt: test.updatedAt
    }));

  } catch (error) {
    logger.error('Error searching lab tests:', error, { searchTerm, category, userId });
    throw new Error('Failed to search lab tests');
  }
}

/**
 * Create a new lab order
 */
export async function createLabOrder(orderData: {
  patientId: string;
  orderedBy: string;
  testIds: string[];
  priority?: 'routine' | 'urgent' | 'stat';
  scheduledAt?: Date;
  instructions?: string;
  clinicalInfo?: string;
}, userId: string): Promise<LabOrderDetails> {
  try {
    logger.info(`Creating lab order`, { orderData, userId });

    const labOrder = await prisma.labOrder.create({
      data: {
        patientId: orderData.patientId,
        orderedBy: orderData.orderedBy,
        testIds: orderData.testIds,
        priority: orderData.priority || 'routine',
        status: 'pending',
        orderedAt: new Date(),
        scheduledAt: orderData.scheduledAt,
        instructions: orderData.instructions,
        clinicalInfo: orderData.clinicalInfo,
        isActive: true
      }
    });

    // Create individual lab results for each test
    for (const testId of orderData.testIds) {
      await prisma.labResult.create({
        data: {
          orderId: labOrder.id,
          patientId: orderData.patientId,
          testId: testId,
          status: 'pending',
          orderedBy: orderData.orderedBy,
          orderedAt: labOrder.orderedAt,
          isActive: true
        }
      });
    }

    // Audit log for lab order creation
    await auditLog({
      userId,
      action: 'CREATE_LAB_ORDER',
      resourceType: 'LabOrder',
      resourceId: labOrder.id,
      details: { 
        patientId: orderData.patientId,
        testCount: orderData.testIds.length,
        priority: orderData.priority
      }
    });

    return {
      id: labOrder.id,
      patientId: labOrder.patientId,
      orderedBy: labOrder.orderedBy,
      testIds: labOrder.testIds,
      priority: labOrder.priority as 'routine' | 'urgent' | 'stat',
      status: labOrder.status as 'pending' | 'collected' | 'processing' | 'completed' | 'cancelled',
      orderedAt: labOrder.orderedAt,
      scheduledAt: labOrder.scheduledAt,
      collectedAt: labOrder.collectedAt,
      completedAt: labOrder.completedAt,
      instructions: labOrder.instructions,
      clinicalInfo: labOrder.clinicalInfo,
      isActive: labOrder.isActive,
      createdAt: labOrder.createdAt,
      updatedAt: labOrder.updatedAt
    };

  } catch (error) {
    logger.error('Error creating lab order:', error, { orderData, userId });
    throw new Error('Failed to create lab order');
  }
}

/**
 * Update lab result with values
 */
export async function updateLabResult(
  resultId: string,
  resultData: {
    value: string;
    status?: 'normal' | 'abnormal' | 'critical' | 'pending';
    flags?: string[];
    performedBy?: string;
    notes?: string;
    criticalValue?: boolean;
  },
  userId: string
): Promise<LabResultDetails> {
  try {
    logger.info(`Updating lab result`, { resultId, resultData, userId });

    const updatedResult = await prisma.labResult.update({
      where: { id: resultId },
      data: {
        value: resultData.value,
        status: resultData.status || 'normal',
        flags: resultData.flags,
        performedBy: resultData.performedBy || userId,
        notes: resultData.notes,
        criticalValue: resultData.criticalValue,
        resultedAt: new Date(),
        updatedAt: new Date()
      },
      include: {
        test: {
          select: {
            name: true,
            code: true,
            category: true,
            normalRange: true,
            unit: true
          }
        }
      }
    });

    // If critical value, send notification
    if (resultData.criticalValue) {
      logger.warn(`Critical lab value reported`, { 
        resultId, 
        patientId: updatedResult.patientId,
        testName: updatedResult.test?.name,
        value: resultData.value
      });

      // TODO: Implement critical value notification system
    }

    // Audit log for lab result update
    await auditLog({
      userId,
      action: 'UPDATE_LAB_RESULT',
      resourceType: 'LabResult',
      resourceId: resultId,
      details: { 
        patientId: updatedResult.patientId,
        testName: updatedResult.test?.name,
        value: resultData.value,
        status: resultData.status,
        criticalValue: resultData.criticalValue
      }
    });

    return {
      id: updatedResult.id,
      orderId: updatedResult.orderId,
      patientId: updatedResult.patientId,
      testId: updatedResult.testId,
      testName: updatedResult.test?.name || '',
      testCode: updatedResult.test?.code,
      category: updatedResult.test?.category || '',
      value: updatedResult.value,
      unit: updatedResult.test?.unit || updatedResult.unit,
      referenceRange: updatedResult.test?.normalRange || updatedResult.referenceRange,
      status: updatedResult.status as 'normal' | 'abnormal' | 'critical' | 'pending',
      flags: updatedResult.flags || [],
      orderedBy: updatedResult.orderedBy,
      performedBy: updatedResult.performedBy,
      verifiedBy: updatedResult.verifiedBy,
      orderedAt: updatedResult.orderedAt,
      collectedAt: updatedResult.collectedAt,
      resultedAt: updatedResult.resultedAt,
      verifiedAt: updatedResult.verifiedAt,
      notes: updatedResult.notes,
      criticalValue: updatedResult.criticalValue,
      deltaCheck: updatedResult.deltaCheck,
      isActive: updatedResult.isActive,
      createdAt: updatedResult.createdAt,
      updatedAt: updatedResult.updatedAt
    };

  } catch (error) {
    logger.error('Error updating lab result:', error, { resultId, resultData, userId });
    throw new Error('Failed to update lab result');
  }
}

/**
 * Get lab orders for a patient
 */
export async function getPatientLabOrders(patientId: string, userId?: string, limit: number = 50): Promise<LabOrderDetails[]> {
  try {
    logger.info(`Fetching lab orders for patient: ${patientId}`, { userId, limit });

    const labOrders = await prisma.labOrder.findMany({
      where: { 
        patientId,
        isActive: true 
      },
      orderBy: { orderedAt: 'desc' },
      take: limit
    });

    // Audit log for lab orders access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT_LAB_ORDERS',
      resourceType: 'LabOrder',
      resourceId: patientId,
      details: { patientId, orderCount: labOrders.length }
    });

    return labOrders.map(order => ({
      id: order.id,
      patientId: order.patientId,
      orderedBy: order.orderedBy,
      testIds: order.testIds,
      priority: order.priority as 'routine' | 'urgent' | 'stat',
      status: order.status as 'pending' | 'collected' | 'processing' | 'completed' | 'cancelled',
      orderedAt: order.orderedAt,
      scheduledAt: order.scheduledAt,
      collectedAt: order.collectedAt,
      completedAt: order.completedAt,
      instructions: order.instructions,
      clinicalInfo: order.clinicalInfo,
      isActive: order.isActive,
      createdAt: order.createdAt,
      updatedAt: order.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching patient lab orders:', error, { patientId, userId });
    throw new Error('Failed to fetch patient lab orders');
  }
}

/**
 * Get critical lab values requiring immediate attention
 */
export async function getCriticalLabValues(userId?: string, limit: number = 100): Promise<LabResultDetails[]> {
  try {
    logger.info(`Fetching critical lab values`, { userId, limit });

    const criticalResults = await prisma.labResult.findMany({
      where: { 
        criticalValue: true,
        isActive: true,
        resultedAt: {
          gte: new Date(Date.now() - 24 * 60 * 60 * 1000) // Last 24 hours
        }
      },
      orderBy: { resultedAt: 'desc' },
      take: limit,
      include: {
        test: {
          select: {
            name: true,
            code: true,
            category: true,
            normalRange: true,
            unit: true
          }
        },
        patient: {
          select: {
            mrn: true,
            firstName: true,
            lastName: true
          }
        }
      }
    });

    // Audit log for critical values access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_CRITICAL_LAB_VALUES',
      resourceType: 'LabResult',
      resourceId: 'critical',
      details: { criticalCount: criticalResults.length }
    });

    return criticalResults.map(result => ({
      id: result.id,
      orderId: result.orderId,
      patientId: result.patientId,
      testId: result.testId,
      testName: result.test?.name || '',
      testCode: result.test?.code,
      category: result.test?.category || '',
      value: result.value,
      unit: result.test?.unit || result.unit,
      referenceRange: result.test?.normalRange || result.referenceRange,
      status: result.status as 'normal' | 'abnormal' | 'critical' | 'pending',
      flags: result.flags || [],
      orderedBy: result.orderedBy,
      performedBy: result.performedBy,
      verifiedBy: result.verifiedBy,
      orderedAt: result.orderedAt,
      collectedAt: result.collectedAt,
      resultedAt: result.resultedAt,
      verifiedAt: result.verifiedAt,
      notes: result.notes,
      criticalValue: result.criticalValue,
      deltaCheck: result.deltaCheck,
      isActive: result.isActive,
      createdAt: result.createdAt,
      updatedAt: result.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching critical lab values:', error, { userId });
    throw new Error('Failed to fetch critical lab values');
  }
}

// Export additional utility functions
export {
  type LabTestDetails,
  type LabOrderDetails,
  type LabResultDetails,
  type SpecimenDetails
};
