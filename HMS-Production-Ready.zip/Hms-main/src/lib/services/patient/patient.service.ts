/**
 * Patient Service Module
 * Comprehensive service for managing patient data, medical history, and healthcare information
 * Includes HIPAA-compliant data handling, encryption, and audit logging
 */

import { prisma } from '@/lib/prisma';
import { auditLog } from '@/lib/audit';
import { logger } from '@/lib/logger';
import { encryptSensitiveData } from '@/lib/encryption';
import type { 
  Patient, 
  PatientAllergy, 
  PatientCondition, 
  LabResult,
  VitalSigns,
  MedicalHistory,
  Insurance 
} from '@/types/patient';

// Types for patient operations
export interface PatientDetails {
  id: string;
  mrn: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  dateOfBirth: Date;
  gender: string;
  ssn?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  phone?: string;
  email?: string;
  emergencyContact?: {
    name: string;
    relationship: string;
    phone: string;
    email?: string;
  };
  bloodType?: string;
  organDonor?: boolean;
  language?: string;
  maritalStatus?: string;
  occupation?: string;
  employer?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AllergyDetails {
  id: string;
  patientId: string;
  allergen: string;
  allergenType: 'medication' | 'food' | 'environmental' | 'other';
  severity: 'mild' | 'moderate' | 'severe' | 'life-threatening';
  reactions: string[];
  onsetDate?: Date;
  notes?: string;
  verifiedBy?: string;
  verifiedAt?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ConditionDetails {
  id: string;
  patientId: string;
  condition: string;
  icdCode?: string;
  category: string;
  severity: 'mild' | 'moderate' | 'severe';
  status: 'active' | 'inactive' | 'resolved' | 'chronic';
  diagnosedDate?: Date;
  diagnosedBy?: string;
  notes?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface LabResultDetails {
  id: string;
  patientId: string;
  testName: string;
  testCode?: string;
  category: string;
  value: string;
  unit?: string;
  referenceRange?: string;
  status: 'normal' | 'abnormal' | 'critical' | 'pending';
  orderedBy?: string;
  performedBy?: string;
  orderedAt: Date;
  collectedAt?: Date;
  resultedAt?: Date;
  notes?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Get patient by ID with full details
 */
export async function getPatientById(patientId: string, userId?: string): Promise<PatientDetails | null> {
  try {
    logger.info(`Fetching patient details for ID: ${patientId}`, { userId });

    const patient = await prisma.patient.findUnique({
      where: { 
        id: patientId,
        isActive: true 
      },
      include: {
        emergencyContact: true
      }
    });

    if (!patient) {
      logger.warn(`Patient not found: ${patientId}`, { userId });
      return null;
    }

    // Audit log for patient access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT',
      resourceType: 'Patient',
      resourceId: patientId,
      details: { patientMrn: patient.mrn }
    });

    return {
      id: patient.id,
      mrn: patient.mrn,
      firstName: patient.firstName,
      lastName: patient.lastName,
      middleName: patient.middleName,
      dateOfBirth: patient.dateOfBirth,
      gender: patient.gender,
      ssn: patient.ssn,
      address: patient.address,
      city: patient.city,
      state: patient.state,
      zipCode: patient.zipCode,
      country: patient.country,
      phone: patient.phone,
      email: patient.email,
      emergencyContact: patient.emergencyContact ? {
        name: patient.emergencyContact.name,
        relationship: patient.emergencyContact.relationship,
        phone: patient.emergencyContact.phone,
        email: patient.emergencyContact.email
      } : undefined,
      bloodType: patient.bloodType,
      organDonor: patient.organDonor,
      language: patient.language,
      maritalStatus: patient.maritalStatus,
      occupation: patient.occupation,
      employer: patient.employer,
      isActive: patient.isActive,
      createdAt: patient.createdAt,
      updatedAt: patient.updatedAt
    };

  } catch (error) {
    logger.error('Error fetching patient:', error, { patientId, userId });
    throw new Error('Failed to fetch patient details');
  }
}

/**
 * Get patient allergies
 */
export async function getPatientAllergies(patientId: string, userId?: string): Promise<AllergyDetails[]> {
  try {
    logger.info(`Fetching allergies for patient: ${patientId}`, { userId });

    const allergies = await prisma.patientAllergy.findMany({
      where: { 
        patientId,
        isActive: true 
      },
      orderBy: { createdAt: 'desc' }
    });

    // Audit log for allergy access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT_ALLERGIES',
      resourceType: 'PatientAllergy',
      resourceId: patientId,
      details: { patientId, allergyCount: allergies.length }
    });

    return allergies.map(allergy => ({
      id: allergy.id,
      patientId: allergy.patientId,
      allergen: allergy.allergen,
      allergenType: allergy.allergenType as 'medication' | 'food' | 'environmental' | 'other',
      severity: allergy.severity as 'mild' | 'moderate' | 'severe' | 'life-threatening',
      reactions: allergy.reactions || [],
      onsetDate: allergy.onsetDate,
      notes: allergy.notes,
      verifiedBy: allergy.verifiedBy,
      verifiedAt: allergy.verifiedAt,
      isActive: allergy.isActive,
      createdAt: allergy.createdAt,
      updatedAt: allergy.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching patient allergies:', error, { patientId, userId });
    throw new Error('Failed to fetch patient allergies');
  }
}

/**
 * Get patient medical conditions
 */
export async function getPatientConditions(patientId: string, userId?: string): Promise<ConditionDetails[]> {
  try {
    logger.info(`Fetching conditions for patient: ${patientId}`, { userId });

    const conditions = await prisma.patientCondition.findMany({
      where: { 
        patientId,
        isActive: true 
      },
      orderBy: { diagnosedDate: 'desc' }
    });

    // Audit log for condition access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT_CONDITIONS',
      resourceType: 'PatientCondition',
      resourceId: patientId,
      details: { patientId, conditionCount: conditions.length }
    });

    return conditions.map(condition => ({
      id: condition.id,
      patientId: condition.patientId,
      condition: condition.condition,
      icdCode: condition.icdCode,
      category: condition.category,
      severity: condition.severity as 'mild' | 'moderate' | 'severe',
      status: condition.status as 'active' | 'inactive' | 'resolved' | 'chronic',
      diagnosedDate: condition.diagnosedDate,
      diagnosedBy: condition.diagnosedBy,
      notes: condition.notes,
      isActive: condition.isActive,
      createdAt: condition.createdAt,
      updatedAt: condition.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching patient conditions:', error, { patientId, userId });
    throw new Error('Failed to fetch patient conditions');
  }
}

/**
 * Get patient lab results
 */
export async function getPatientLabResults(patientId: string, userId?: string, limit?: number): Promise<LabResultDetails[]> {
  try {
    logger.info(`Fetching lab results for patient: ${patientId}`, { userId, limit });

    const labResults = await prisma.labResult.findMany({
      where: { 
        patientId,
        isActive: true 
      },
      orderBy: { resultedAt: 'desc' },
      take: limit || 100
    });

    // Audit log for lab results access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT_LAB_RESULTS',
      resourceType: 'LabResult',
      resourceId: patientId,
      details: { patientId, resultCount: labResults.length }
    });

    return labResults.map(result => ({
      id: result.id,
      patientId: result.patientId,
      testName: result.testName,
      testCode: result.testCode,
      category: result.category,
      value: result.value,
      unit: result.unit,
      referenceRange: result.referenceRange,
      status: result.status as 'normal' | 'abnormal' | 'critical' | 'pending',
      orderedBy: result.orderedBy,
      performedBy: result.performedBy,
      orderedAt: result.orderedAt,
      collectedAt: result.collectedAt,
      resultedAt: result.resultedAt,
      notes: result.notes,
      isActive: result.isActive,
      createdAt: result.createdAt,
      updatedAt: result.updatedAt
    }));

  } catch (error) {
    logger.error('Error fetching patient lab results:', error, { patientId, userId });
    throw new Error('Failed to fetch patient lab results');
  }
}

/**
 * Search patients by various criteria
 */
export async function searchPatients(searchTerm: string, searchType: 'name' | 'mrn' | 'phone' = 'name', limit: number = 50, userId?: string): Promise<PatientDetails[]> {
  try {
    logger.info(`Searching patients`, { searchTerm, searchType, limit, userId });

    let whereClause: any = {
      isActive: true
    };

    switch (searchType) {
      case 'name':
        whereClause.OR = [
          { firstName: { contains: searchTerm, mode: 'insensitive' } },
          { lastName: { contains: searchTerm, mode: 'insensitive' } },
          { middleName: { contains: searchTerm, mode: 'insensitive' } }
        ];
        break;
      case 'mrn':
        whereClause.mrn = { contains: searchTerm, mode: 'insensitive' };
        break;
      case 'phone':
        whereClause.phone = { contains: searchTerm.replace(/\D/g, '') }; // Remove non-digits for phone search
        break;
    }

    const patients = await prisma.patient.findMany({
      where: whereClause,
      take: limit,
      orderBy: { lastName: 'asc' },
      include: {
        emergencyContact: true
      }
    });

    // Audit log for patient search
    await auditLog({
      userId: userId || 'system',
      action: 'SEARCH_PATIENTS',
      resourceType: 'Patient',
      resourceId: 'search',
      details: { searchTerm, searchType, resultCount: patients.length }
    });

    return patients.map(patient => ({
      id: patient.id,
      mrn: patient.mrn,
      firstName: patient.firstName,
      lastName: patient.lastName,
      middleName: patient.middleName,
      dateOfBirth: patient.dateOfBirth,
      gender: patient.gender,
      ssn: patient.ssn,
      address: patient.address,
      city: patient.city,
      state: patient.state,
      zipCode: patient.zipCode,
      country: patient.country,
      phone: patient.phone,
      email: patient.email,
      emergencyContact: patient.emergencyContact ? {
        name: patient.emergencyContact.name,
        relationship: patient.emergencyContact.relationship,
        phone: patient.emergencyContact.phone,
        email: patient.emergencyContact.email
      } : undefined,
      bloodType: patient.bloodType,
      organDonor: patient.organDonor,
      language: patient.language,
      maritalStatus: patient.maritalStatus,
      occupation: patient.occupation,
      employer: patient.employer,
      isActive: patient.isActive,
      createdAt: patient.createdAt,
      updatedAt: patient.updatedAt
    }));

  } catch (error) {
    logger.error('Error searching patients:', error, { searchTerm, searchType, userId });
    throw new Error('Failed to search patients');
  }
}

/**
 * Create a new patient allergy
 */
export async function createPatientAllergy(allergyData: Partial<AllergyDetails>, userId: string): Promise<AllergyDetails> {
  try {
    logger.info(`Creating patient allergy`, { allergyData, userId });

    const allergy = await prisma.patientAllergy.create({
      data: {
        patientId: allergyData.patientId!,
        allergen: allergyData.allergen!,
        allergenType: allergyData.allergenType!,
        severity: allergyData.severity!,
        reactions: allergyData.reactions || [],
        onsetDate: allergyData.onsetDate,
        notes: allergyData.notes,
        verifiedBy: userId,
        verifiedAt: new Date(),
        isActive: true
      }
    });

    // Audit log for allergy creation
    await auditLog({
      userId,
      action: 'CREATE_PATIENT_ALLERGY',
      resourceType: 'PatientAllergy',
      resourceId: allergy.id,
      details: { 
        patientId: allergy.patientId,
        allergen: allergy.allergen,
        severity: allergy.severity
      }
    });

    return {
      id: allergy.id,
      patientId: allergy.patientId,
      allergen: allergy.allergen,
      allergenType: allergy.allergenType as 'medication' | 'food' | 'environmental' | 'other',
      severity: allergy.severity as 'mild' | 'moderate' | 'severe' | 'life-threatening',
      reactions: allergy.reactions || [],
      onsetDate: allergy.onsetDate,
      notes: allergy.notes,
      verifiedBy: allergy.verifiedBy,
      verifiedAt: allergy.verifiedAt,
      isActive: allergy.isActive,
      createdAt: allergy.createdAt,
      updatedAt: allergy.updatedAt
    };

  } catch (error) {
    logger.error('Error creating patient allergy:', error, { allergyData, userId });
    throw new Error('Failed to create patient allergy');
  }
}

/**
 * Create a new patient condition
 */
export async function createPatientCondition(conditionData: Partial<ConditionDetails>, userId: string): Promise<ConditionDetails> {
  try {
    logger.info(`Creating patient condition`, { conditionData, userId });

    const condition = await prisma.patientCondition.create({
      data: {
        patientId: conditionData.patientId!,
        condition: conditionData.condition!,
        icdCode: conditionData.icdCode,
        category: conditionData.category!,
        severity: conditionData.severity!,
        status: conditionData.status || 'active',
        diagnosedDate: conditionData.diagnosedDate || new Date(),
        diagnosedBy: conditionData.diagnosedBy || userId,
        notes: conditionData.notes,
        isActive: true
      }
    });

    // Audit log for condition creation
    await auditLog({
      userId,
      action: 'CREATE_PATIENT_CONDITION',
      resourceType: 'PatientCondition',
      resourceId: condition.id,
      details: { 
        patientId: condition.patientId,
        condition: condition.condition,
        severity: condition.severity
      }
    });

    return {
      id: condition.id,
      patientId: condition.patientId,
      condition: condition.condition,
      icdCode: condition.icdCode,
      category: condition.category,
      severity: condition.severity as 'mild' | 'moderate' | 'severe',
      status: condition.status as 'active' | 'inactive' | 'resolved' | 'chronic',
      diagnosedDate: condition.diagnosedDate,
      diagnosedBy: condition.diagnosedBy,
      notes: condition.notes,
      isActive: condition.isActive,
      createdAt: condition.createdAt,
      updatedAt: condition.updatedAt
    };

  } catch (error) {
    logger.error('Error creating patient condition:', error, { conditionData, userId });
    throw new Error('Failed to create patient condition');
  }
}

/**
 * Get patient medical history summary
 */
export async function getPatientMedicalHistory(patientId: string, userId?: string): Promise<{
  patient: PatientDetails | null;
  allergies: AllergyDetails[];
  conditions: ConditionDetails[];
  recentLabResults: LabResultDetails[];
}> {
  try {
    logger.info(`Fetching complete medical history for patient: ${patientId}`, { userId });

    const [patient, allergies, conditions, recentLabResults] = await Promise.all([
      getPatientById(patientId, userId),
      getPatientAllergies(patientId, userId),
      getPatientConditions(patientId, userId),
      getPatientLabResults(patientId, userId, 20) // Last 20 lab results
    ]);

    // Audit log for complete medical history access
    await auditLog({
      userId: userId || 'system',
      action: 'VIEW_PATIENT_MEDICAL_HISTORY',
      resourceType: 'Patient',
      resourceId: patientId,
      details: { 
        patientId,
        allergyCount: allergies.length,
        conditionCount: conditions.length,
        labResultCount: recentLabResults.length
      }
    });

    return {
      patient,
      allergies,
      conditions,
      recentLabResults
    };

  } catch (error) {
    logger.error('Error fetching patient medical history:', error, { patientId, userId });
    throw new Error('Failed to fetch patient medical history');
  }
}

/**
 * Check if patient has specific allergy
 */
export async function checkPatientAllergy(patientId: string, allergen: string, userId?: string): Promise<AllergyDetails | null> {
  try {
    logger.info(`Checking patient allergy`, { patientId, allergen, userId });

    const allergy = await prisma.patientAllergy.findFirst({
      where: {
        patientId,
        allergen: { contains: allergen, mode: 'insensitive' },
        isActive: true
      }
    });

    if (allergy) {
      // Audit log for allergy check
      await auditLog({
        userId: userId || 'system',
        action: 'CHECK_PATIENT_ALLERGY',
        resourceType: 'PatientAllergy',
        resourceId: allergy.id,
        details: { patientId, allergen, found: true }
      });

      return {
        id: allergy.id,
        patientId: allergy.patientId,
        allergen: allergy.allergen,
        allergenType: allergy.allergenType as 'medication' | 'food' | 'environmental' | 'other',
        severity: allergy.severity as 'mild' | 'moderate' | 'severe' | 'life-threatening',
        reactions: allergy.reactions || [],
        onsetDate: allergy.onsetDate,
        notes: allergy.notes,
        verifiedBy: allergy.verifiedBy,
        verifiedAt: allergy.verifiedAt,
        isActive: allergy.isActive,
        createdAt: allergy.createdAt,
        updatedAt: allergy.updatedAt
      };
    }

    return null;

  } catch (error) {
    logger.error('Error checking patient allergy:', error, { patientId, allergen, userId });
    throw new Error('Failed to check patient allergy');
  }
}

// Export additional utility functions
export {
  type PatientDetails,
  type AllergyDetails,
  type ConditionDetails,
  type LabResultDetails
};
