/**
 * Ambulance Routing Service Module
 * Provides routing and navigation services for ambulance operations
 * Includes route calculation, ETA estimation, and GPS tracking
 */

import { logger } from '@/lib/logger';
import { auditLog } from '@/lib/audit';

// Types for routing operations
export interface RouteDetails {
  id: string;
  origin: {
    latitude: number;
    longitude: number;
    address?: string;
  };
  destination: {
    latitude: number;
    longitude: number;
    address?: string;
  };
  waypoints?: Array<{
    latitude: number;
    longitude: number;
    address?: string;
  }>;
  distance: number; // in meters
  duration: number; // in seconds
  routeGeometry?: string; // encoded polyline
  instructions?: Array<{
    instruction: string;
    distance: number;
    duration: number;
    direction?: string;
  }>;
  trafficConditions?: 'light' | 'moderate' | 'heavy' | 'severe';
  emergencyRoute?: boolean;
  calculatedAt: Date;
}

export interface EstimatedArrival {
  estimatedArrivalTime: Date;
  estimatedDuration: number; // in seconds
  confidence: 'low' | 'medium' | 'high';
  trafficFactor: number;
  emergencyFactor: number;
  calculatedAt: Date;
}

export interface GPSCoordinate {
  latitude: number;
  longitude: number;
  altitude?: number;
  accuracy?: number;
  timestamp: Date;
}

/**
 * Calculate route between two points
 */
export async function calculateRoute(
  origin: { latitude: number; longitude: number },
  destination: { latitude: number; longitude: number },
  options?: {
    waypoints?: Array<{ latitude: number; longitude: number }>;
    emergencyRoute?: boolean;
    avoidTolls?: boolean;
    avoidHighways?: boolean;
  },
  userId?: string
): Promise<RouteDetails> {
  try {
    logger.info(`Calculating route`, { origin, destination, options, userId });

    // Simulate route calculation - in production, integrate with Google Maps, Mapbox, or similar
    const distance = calculateHaversineDistance(origin, destination);
    const baseDuration = distance / 50 * 3600; // Assume 50 km/h average speed
    
    // Apply emergency route factor (faster routing for emergencies)
    const emergencyFactor = options?.emergencyRoute ? 0.7 : 1.0;
    const duration = baseDuration * emergencyFactor;

    // Simulate traffic conditions
    const trafficConditions = getSimulatedTrafficConditions();
    const trafficFactor = getTrafficFactor(trafficConditions);
    const adjustedDuration = duration * trafficFactor;

    const route: RouteDetails = {
      id: `route_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      origin: {
        latitude: origin.latitude,
        longitude: origin.longitude
      },
      destination: {
        latitude: destination.latitude,
        longitude: destination.longitude
      },
      waypoints: options?.waypoints?.map(wp => ({
        latitude: wp.latitude,
        longitude: wp.longitude
      })),
      distance: Math.round(distance),
      duration: Math.round(adjustedDuration),
      trafficConditions,
      emergencyRoute: options?.emergencyRoute || false,
      instructions: generateRouteInstructions(origin, destination, distance),
      calculatedAt: new Date()
    };

    // Audit log for route calculation
    await auditLog({
      userId: userId || 'system',
      action: 'CALCULATE_AMBULANCE_ROUTE',
      resourceType: 'AmbulanceRoute',
      resourceId: route.id,
      details: { 
        origin,
        destination,
        distance: route.distance,
        duration: route.duration,
        emergencyRoute: route.emergencyRoute
      }
    });

    return route;

  } catch (error) {
    logger.error('Error calculating route:', error, { origin, destination, options, userId });
    throw new Error('Failed to calculate route');
  }
}

/**
 * Estimate arrival time for ambulance
 */
export async function estimateArrivalTime(
  currentLocation: { latitude: number; longitude: number },
  destination: { latitude: number; longitude: number },
  ambulanceId?: string,
  userId?: string
): Promise<EstimatedArrival> {
  try {
    logger.info(`Estimating arrival time`, { currentLocation, destination, ambulanceId, userId });

    const route = await calculateRoute(currentLocation, destination, { emergencyRoute: true }, userId);
    
    // Apply additional factors for more accurate ETA
    const emergencyFactor = 0.8; // Emergency vehicles can travel faster
    const confidenceFactor = getConfidenceFactor(route.trafficConditions);
    
    const estimatedDuration = route.duration * emergencyFactor;
    const estimatedArrivalTime = new Date(Date.now() + estimatedDuration * 1000);

    const estimation: EstimatedArrival = {
      estimatedArrivalTime,
      estimatedDuration: Math.round(estimatedDuration),
      confidence: confidenceFactor,
      trafficFactor: getTrafficFactor(route.trafficConditions || 'moderate'),
      emergencyFactor,
      calculatedAt: new Date()
    };

    // Audit log for arrival time estimation
    await auditLog({
      userId: userId || 'system',
      action: 'ESTIMATE_AMBULANCE_ARRIVAL',
      resourceType: 'AmbulanceETA',
      resourceId: ambulanceId || 'unknown',
      details: { 
        currentLocation,
        destination,
        estimatedDuration: estimation.estimatedDuration,
        confidence: estimation.confidence
      }
    });

    return estimation;

  } catch (error) {
    logger.error('Error estimating arrival time:', error, { currentLocation, destination, ambulanceId, userId });
    throw new Error('Failed to estimate arrival time');
  }
}

/**
 * Get optimal route with multiple stops
 */
export async function calculateOptimalRoute(
  origin: { latitude: number; longitude: number },
  destinations: Array<{ latitude: number; longitude: number; priority?: number }>,
  options?: {
    emergencyRoute?: boolean;
    maxStops?: number;
  },
  userId?: string
): Promise<{
  route: RouteDetails;
  optimizedOrder: number[];
  totalDistance: number;
  totalDuration: number;
}> {
  try {
    logger.info(`Calculating optimal route with multiple stops`, { 
      origin, 
      destinationCount: destinations.length, 
      options, 
      userId 
    });

    // Simple optimization - sort by priority then by distance from origin
    const sortedDestinations = destinations
      .map((dest, index) => ({
        ...dest,
        originalIndex: index,
        distanceFromOrigin: calculateHaversineDistance(origin, dest)
      }))
      .sort((a, b) => {
        // Priority first (higher priority = lower number = comes first)
        if (a.priority && b.priority && a.priority !== b.priority) {
          return a.priority - b.priority;
        }
        // Then by distance
        return a.distanceFromOrigin - b.distanceFromOrigin;
      });

    // Limit stops if specified
    const maxStops = options?.maxStops || destinations.length;
    const selectedDestinations = sortedDestinations.slice(0, maxStops);

    // Calculate route through all selected destinations
    const waypoints = selectedDestinations.map(dest => ({
      latitude: dest.latitude,
      longitude: dest.longitude
    }));

    const finalDestination = selectedDestinations[selectedDestinations.length - 1];
    
    const route = await calculateRoute(
      origin,
      finalDestination,
      {
        waypoints: waypoints.slice(0, -1), // All except the last one (which is destination)
        emergencyRoute: options?.emergencyRoute
      },
      userId
    );

    // Calculate total metrics
    let totalDistance = route.distance;
    let totalDuration = route.duration;

    const optimizedOrder = selectedDestinations.map(dest => dest.originalIndex);

    return {
      route,
      optimizedOrder,
      totalDistance,
      totalDuration
    };

  } catch (error) {
    logger.error('Error calculating optimal route:', error, { origin, destinations, options, userId });
    throw new Error('Failed to calculate optimal route');
  }
}

/**
 * Track ambulance location and update ETA
 */
export async function updateLocationAndETA(
  ambulanceId: string,
  currentLocation: { latitude: number; longitude: number },
  destination: { latitude: number; longitude: number },
  userId?: string
): Promise<{
  location: GPSCoordinate;
  updatedETA: EstimatedArrival;
}> {
  try {
    logger.info(`Updating ambulance location and ETA`, { ambulanceId, currentLocation, destination, userId });

    const location: GPSCoordinate = {
      latitude: currentLocation.latitude,
      longitude: currentLocation.longitude,
      timestamp: new Date()
    };

    const updatedETA = await estimateArrivalTime(currentLocation, destination, ambulanceId, userId);

    // In a real implementation, you would store this in the database
    // await prisma.ambulanceLocation.create({
    //   data: {
    //     ambulanceId,
    //     latitude: currentLocation.latitude,
    //     longitude: currentLocation.longitude,
    //     timestamp: new Date()
    //   }
    // });

    return {
      location,
      updatedETA
    };

  } catch (error) {
    logger.error('Error updating ambulance location and ETA:', error, { ambulanceId, currentLocation, destination, userId });
    throw new Error('Failed to update ambulance location and ETA');
  }
}

/**
 * Get current traffic conditions for a route
 */
export async function getTrafficConditions(
  origin: { latitude: number; longitude: number },
  destination: { latitude: number; longitude: number },
  userId?: string
): Promise<{
  conditions: 'light' | 'moderate' | 'heavy' | 'severe';
  delayFactor: number;
  incidents?: Array<{
    type: string;
    location: { latitude: number; longitude: number };
    severity: string;
    description: string;
  }>;
}> {
  try {
    logger.info(`Getting traffic conditions`, { origin, destination, userId });

    // Simulate traffic conditions - in production, integrate with traffic APIs
    const conditions = getSimulatedTrafficConditions();
    const delayFactor = getTrafficFactor(conditions);
    
    // Simulate traffic incidents
    const incidents = Math.random() > 0.7 ? [{
      type: 'accident',
      location: {
        latitude: (origin.latitude + destination.latitude) / 2,
        longitude: (origin.longitude + destination.longitude) / 2
      },
      severity: 'moderate',
      description: 'Minor traffic accident, expect delays'
    }] : [];

    return {
      conditions,
      delayFactor,
      incidents
    };

  } catch (error) {
    logger.error('Error getting traffic conditions:', error, { origin, destination, userId });
    throw new Error('Failed to get traffic conditions');
  }
}

// Utility functions

/**
 * Calculate distance between two points using Haversine formula
 */
function calculateHaversineDistance(
  point1: { latitude: number; longitude: number },
  point2: { latitude: number; longitude: number }
): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = point1.latitude * Math.PI / 180;
  const φ2 = point2.latitude * Math.PI / 180;
  const Δφ = (point2.latitude - point1.latitude) * Math.PI / 180;
  const Δλ = (point2.longitude - point1.longitude) * Math.PI / 180;

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c; // Distance in meters
}

/**
 * Get simulated traffic conditions
 */
function getSimulatedTrafficConditions(): 'light' | 'moderate' | 'heavy' | 'severe' {
  const hour = new Date().getHours();
  const random = Math.random();
  
  // Rush hours have heavier traffic
  if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
    if (random < 0.4) return 'heavy';
    if (random < 0.7) return 'moderate';
    if (random < 0.9) return 'light';
    return 'severe';
  }
  
  // Off-peak hours
  if (random < 0.6) return 'light';
  if (random < 0.8) return 'moderate';
  if (random < 0.95) return 'heavy';
  return 'severe';
}

/**
 * Get traffic delay factor
 */
function getTrafficFactor(conditions: 'light' | 'moderate' | 'heavy' | 'severe'): number {
  switch (conditions) {
    case 'light': return 0.9;
    case 'moderate': return 1.2;
    case 'heavy': return 1.5;
    case 'severe': return 2.0;
    default: return 1.0;
  }
}

/**
 * Get confidence factor for ETA
 */
function getConfidenceFactor(conditions?: 'light' | 'moderate' | 'heavy' | 'severe'): 'low' | 'medium' | 'high' {
  switch (conditions) {
    case 'light': return 'high';
    case 'moderate': return 'medium';
    case 'heavy': return 'medium';
    case 'severe': return 'low';
    default: return 'medium';
  }
}

/**
 * Generate route instructions
 */
function generateRouteInstructions(
  origin: { latitude: number; longitude: number },
  destination: { latitude: number; longitude: number },
  distance: number
): Array<{
  instruction: string;
  distance: number;
  duration: number;
  direction?: string;
}> {
  // Simplified route instructions - in production, get from routing service
  return [
    {
      instruction: 'Head towards destination',
      distance: distance * 0.8,
      duration: distance * 0.8 / 50 * 3600, // Assume 50 km/h
      direction: 'straight'
    },
    {
      instruction: 'Arrive at destination',
      distance: distance * 0.2,
      duration: distance * 0.2 / 30 * 3600, // Slower for final approach
      direction: 'arrive'
    }
  ];
}

// Export types and functions
export {
  type RouteDetails,
  type EstimatedArrival,
  type GPSCoordinate
};
