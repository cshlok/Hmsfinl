/**
 * Logging utility for Hospital Management System
 * Provides structured logging with security and compliance features
 */

// Log levels
export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'fatal'

// Log entry structure
export interface LogEntry {
  level: LogLevel
  message: string
  timestamp: string
  userId?: string
  patientId?: string
  action?: string
  resource?: string
  metadata?: Record<string, any>
  error?: {
    name: string
    message: string
    stack?: string
  }
  request?: {
    method: string
    url: string
    userAgent?: string
    ip?: string
  }
  hipaa?: {
    phi?: boolean
    purpose?: string
    disclosure?: boolean
  }
}

// Logger configuration
interface LoggerConfig {
  level: LogLevel
  enableConsole: boolean
  enableFile: boolean
  enableAudit: boolean
  maskSensitiveData: boolean
  includeStack: boolean
}

// Default configuration
const defaultConfig: LoggerConfig = {
  level: (process.env.LOG_LEVEL as LogLevel) || 'info',
  enableConsole: process.env.NODE_ENV !== 'production',
  enableFile: true,
  enableAudit: true,
  maskSensitiveData: true,
  includeStack: process.env.NODE_ENV === 'development'
}

// Log level priorities
const logLevels: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
  fatal: 4
}

// Sensitive data patterns to mask
const sensitivePatterns = [
  /ssn['":\s]*['"]*(\d{3}-?\d{2}-?\d{4})['"]*/, // SSN
  /password['":\s]*['"]*([^'"]+)['"]*/, // Passwords
  /token['":\s]*['"]*([^'"]+)['"]*/, // Tokens
  /authorization['":\s]*['"]*([^'"]+)['"]*/, // Auth headers
  /credit['":\s]*['"]*(\d{4}[*\s-]*\d{4}[*\s-]*\d{4}[*\s-]*\d{4})['"]*/ // Credit cards
]

/**
 * Mask sensitive data in log messages
 */
const maskSensitiveData = (data: string): string => {
  let masked = data
  
  sensitivePatterns.forEach(pattern => {
    masked = masked.replace(pattern, (match, captured) => {
      const maskedValue = '*'.repeat(Math.max(captured.length - 4, 4)) + captured.slice(-4)
      return match.replace(captured, maskedValue)
    })
  })
  
  return masked
}

/**
 * Format log entry for output
 */
const formatLogEntry = (entry: LogEntry, config: LoggerConfig): string => {
  const timestamp = entry.timestamp
  const level = entry.level.toUpperCase().padEnd(5)
  let message = entry.message
  
  // Mask sensitive data if enabled
  if (config.maskSensitiveData) {
    message = maskSensitiveData(message)
  }
  
  // Build log line
  let logLine = `[${timestamp}] ${level} ${message}`
  
  // Add context if available
  if (entry.userId) {
    logLine += ` | userId: ${entry.userId}`
  }
  
  if (entry.patientId) {
    logLine += ` | patientId: ${entry.patientId}`
  }
  
  if (entry.action) {
    logLine += ` | action: ${entry.action}`
  }
  
  if (entry.resource) {
    logLine += ` | resource: ${entry.resource}`
  }
  
  // Add metadata
  if (entry.metadata && Object.keys(entry.metadata).length > 0) {
    const metadataStr = JSON.stringify(entry.metadata)
    logLine += ` | metadata: ${config.maskSensitiveData ? maskSensitiveData(metadataStr) : metadataStr}`
  }
  
  // Add error details
  if (entry.error) {
    logLine += ` | error: ${entry.error.name}: ${entry.error.message}`
    if (config.includeStack && entry.error.stack) {
      logLine += `\nStack: ${entry.error.stack}`
    }
  }
  
  // Add request details
  if (entry.request) {
    logLine += ` | request: ${entry.request.method} ${entry.request.url}`
    if (entry.request.ip) {
      logLine += ` | ip: ${entry.request.ip}`
    }
  }
  
  // Add HIPAA compliance info
  if (entry.hipaa) {
    logLine += ` | hipaa: ${JSON.stringify(entry.hipaa)}`
  }
  
  return logLine
}

/**
 * Write log entry to console
 */
const writeToConsole = (entry: LogEntry, config: LoggerConfig): void => {
  if (!config.enableConsole) return
  
  const formattedEntry = formatLogEntry(entry, config)
  
  switch (entry.level) {
    case 'debug':
      console.debug(formattedEntry)
      break
    case 'info':
      console.info(formattedEntry)
      break
    case 'warn':
      console.warn(formattedEntry)
      break
    case 'error':
    case 'fatal':
      console.error(formattedEntry)
      break
  }
}

/**
 * Write log entry to file (mock implementation)
 * In production, this would write to actual log files
 */
const writeToFile = (entry: LogEntry, config: LoggerConfig): void => {
  if (!config.enableFile) return
  
  // In a real implementation, this would write to log files
  // For now, we'll just track that it would be logged
  const formattedEntry = formatLogEntry(entry, config)
  
  // Mock file logging
  if (process.env.NODE_ENV === 'development') {
    console.log(`[FILE LOG] ${formattedEntry}`)
  }
}

/**
 * Write audit log for HIPAA compliance
 */
const writeAuditLog = (entry: LogEntry, config: LoggerConfig): void => {
  if (!config.enableAudit) return
  
  // Audit logs require special handling for HIPAA compliance
  const auditEntry = {
    ...entry,
    auditType: 'access',
    hipaaCompliant: true,
    timestamp: entry.timestamp
  }
  
  // In production, this would write to a secure audit log system
  if (process.env.NODE_ENV === 'development') {
    console.log(`[AUDIT LOG] ${JSON.stringify(auditEntry)}`)
  }
}

/**
 * Main logger class
 */
class Logger {
  private config: LoggerConfig
  
  constructor(config: Partial<LoggerConfig> = {}) {
    this.config = { ...defaultConfig, ...config }
  }
  
  /**
   * Check if a log level should be logged
   */
  private shouldLog(level: LogLevel): boolean {
    return logLevels[level] >= logLevels[this.config.level]
  }
  
  /**
   * Create and write log entry
   */
  private log(level: LogLevel, message: string, context: Partial<LogEntry> = {}): void {
    if (!this.shouldLog(level)) return
    
    const entry: LogEntry = {
      level,
      message,
      timestamp: new Date().toISOString(),
      ...context
    }
    
    // Write to different outputs
    writeToConsole(entry, this.config)
    writeToFile(entry, this.config)
    
    // Write audit log for sensitive operations
    if (context.hipaa?.phi || context.patientId || context.action) {
      writeAuditLog(entry, this.config)
    }
  }
  
  /**
   * Debug level logging
   */
  debug(message: string, context?: Partial<LogEntry>): void {
    this.log('debug', message, context)
  }
  
  /**
   * Info level logging
   */
  info(message: string, context?: Partial<LogEntry>): void {
    this.log('info', message, context)
  }
  
  /**
   * Warning level logging
   */
  warn(message: string, context?: Partial<LogEntry>): void {
    this.log('warn', message, context)
  }
  
  /**
   * Error level logging
   */
  error(message: string, error?: Error, context?: Partial<LogEntry>): void {
    this.log('error', message, {
      ...context,
      error: error ? {
        name: error.name,
        message: error.message,
        stack: error.stack
      } : undefined
    })
  }
  
  /**
   * Fatal level logging
   */
  fatal(message: string, error?: Error, context?: Partial<LogEntry>): void {
    this.log('fatal', message, {
      ...context,
      error: error ? {
        name: error.name,
        message: error.message,
        stack: error.stack
      } : undefined
    })
  }
  
  /**
   * Log user action for audit trail
   */
  auditAction(userId: string, action: string, resource: string, metadata?: Record<string, any>): void {
    this.info(`User action: ${action} on ${resource}`, {
      userId,
      action,
      resource,
      metadata,
      hipaa: {
        phi: true,
        purpose: 'user_action_audit'
      }
    })
  }
  
  /**
   * Log patient data access for HIPAA compliance
   */
  auditPatientAccess(userId: string, patientId: string, purpose: string, metadata?: Record<string, any>): void {
    this.info(`Patient data accessed: ${patientId}`, {
      userId,
      patientId,
      action: 'data_access',
      resource: 'patient_data',
      metadata: {
        ...metadata,
        purpose
      },
      hipaa: {
        phi: true,
        purpose,
        disclosure: false
      }
    })
  }
  
  /**
   * Log authentication events
   */
  auditAuth(userId: string, event: 'login' | 'logout' | 'failed_login', ip?: string, userAgent?: string): void {
    this.info(`Authentication event: ${event}`, {
      userId,
      action: event,
      resource: 'authentication',
      request: {
        method: 'POST',
        url: '/auth',
        ip,
        userAgent
      }
    })
  }
  
  /**
   * Log API requests
   */
  logRequest(method: string, url: string, userId?: string, ip?: string, userAgent?: string): void {
    this.info(`API request: ${method} ${url}`, {
      userId,
      action: 'api_request',
      resource: url,
      request: {
        method,
        url,
        ip,
        userAgent
      }
    })
  }
}

// Create default logger instance
const logger = new Logger()

// Export logger and utilities
export { Logger, logger }
export default logger
export { LogEntry, LogLevel, LoggerConfig }
