/**
 * Error Definitions and Utilities
 * Centralized error classes and utilities for the Hospital Management System
 */

// Base error class for HMS-specific errors
export class HMSError extends Error {
  public readonly code: string;
  public readonly statusCode: number;
  public readonly isOperational: boolean;
  public readonly context?: Record<string, any>;

  constructor(
    message: string,
    code: string,
    statusCode: number = 500,
    isOperational: boolean = true,
    context?: Record<string, any>
  ) {
    super(message);
    
    this.name = this.constructor.name;
    this.code = code;
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    this.context = context;

    // Ensure the stack trace points to the actual error location
    Error.captureStackTrace(this, this.constructor);
  }
}

// Validation errors
export class ValidationError extends HMSError {
  constructor(message: string, context?: Record<string, any>) {
    super(message, 'VALIDATION_ERROR', 400, true, context);
  }
}

// Authentication errors
export class AuthenticationError extends HMSError {
  constructor(message: string = 'Authentication required', context?: Record<string, any>) {
    super(message, 'AUTHENTICATION_ERROR', 401, true, context);
  }
}

// Authorization errors
export class AuthorizationError extends HMSError {
  constructor(message: string = 'Insufficient permissions', context?: Record<string, any>) {
    super(message, 'AUTHORIZATION_ERROR', 403, true, context);
  }
}

// Not found errors
export class NotFoundError extends HMSError {
  constructor(resource: string = 'Resource', resourceId?: string, context?: Record<string, any>) {
    const message = resourceId 
      ? `${resource} with ID '${resourceId}' not found`
      : `${resource} not found`;
    super(message, 'NOT_FOUND_ERROR', 404, true, context);
  }
}

// Conflict errors
export class ConflictError extends HMSError {
  constructor(message: string, context?: Record<string, any>) {
    super(message, 'CONFLICT_ERROR', 409, true, context);
  }
}

// Rate limiting errors
export class RateLimitError extends HMSError {
  constructor(message: string = 'Rate limit exceeded', context?: Record<string, any>) {
    super(message, 'RATE_LIMIT_ERROR', 429, true, context);
  }
}

// Database errors
export class DatabaseError extends HMSError {
  constructor(message: string, originalError?: Error, context?: Record<string, any>) {
    super(message, 'DATABASE_ERROR', 500, true, {
      ...context,
      originalError: originalError?.message
    });
  }
}

// External service errors
export class ExternalServiceError extends HMSError {
  constructor(
    service: string, 
    message?: string, 
    statusCode: number = 502,
    context?: Record<string, any>
  ) {
    const errorMessage = message || `External service ${service} is unavailable`;
    super(errorMessage, 'EXTERNAL_SERVICE_ERROR', statusCode, true, {
      ...context,
      service
    });
  }
}

// Business logic errors
export class BusinessLogicError extends HMSError {
  constructor(message: string, context?: Record<string, any>) {
    super(message, 'BUSINESS_LOGIC_ERROR', 422, true, context);
  }
}

// Medical safety errors
export class MedicalSafetyError extends HMSError {
  constructor(message: string, severity: 'low' | 'medium' | 'high' | 'critical' = 'high', context?: Record<string, any>) {
    super(message, 'MEDICAL_SAFETY_ERROR', 422, true, {
      ...context,
      severity
    });
  }
}

// Configuration errors
export class ConfigurationError extends HMSError {
  constructor(message: string, context?: Record<string, any>) {
    super(message, 'CONFIGURATION_ERROR', 500, false, context);
  }
}

// Error factory functions
export const createValidationError = (message: string, details?: Record<string, any>): ValidationError => {
  return new ValidationError(message, details);
};

export const createAuthenticationError = (message?: string): AuthenticationError => {
  return new AuthenticationError(message);
};

export const createAuthorizationError = (message?: string): AuthorizationError => {
  return new AuthorizationError(message);
};

export const createNotFoundError = (resource: string, resourceId?: string): NotFoundError => {
  return new NotFoundError(resource, resourceId);
};

export const createConflictError = (message: string): ConflictError => {
  return new ConflictError(message);
};

export const createDatabaseError = (message: string, originalError?: Error): DatabaseError => {
  return new DatabaseError(message, originalError);
};

export const createExternalServiceError = (service: string, message?: string): ExternalServiceError => {
  return new ExternalServiceError(service, message);
};

export const createBusinessLogicError = (message: string): BusinessLogicError => {
  return new BusinessLogicError(message);
};

export const createMedicalSafetyError = (
  message: string, 
  severity: 'low' | 'medium' | 'high' | 'critical' = 'high'
): MedicalSafetyError => {
  return new MedicalSafetyError(message, severity);
};

// Error type checking utilities
export const isHMSError = (error: any): error is HMSError => {
  return error instanceof HMSError;
};

export const isOperationalError = (error: any): boolean => {
  return isHMSError(error) && error.isOperational;
};

export const isMedicalSafetyError = (error: any): error is MedicalSafetyError => {
  return error instanceof MedicalSafetyError;
};

// Error response formatting
export interface ErrorResponse {
  error: {
    message: string;
    code: string;
    statusCode: number;
    timestamp: string;
    requestId?: string;
    context?: Record<string, any>;
  };
}

export const formatErrorResponse = (
  error: HMSError | Error, 
  requestId?: string
): ErrorResponse => {
  if (isHMSError(error)) {
    return {
      error: {
        message: error.message,
        code: error.code,
        statusCode: error.statusCode,
        timestamp: new Date().toISOString(),
        requestId,
        context: error.context
      }
    };
  }

  // Handle generic errors
  return {
    error: {
      message: error.message || 'An unexpected error occurred',
      code: 'INTERNAL_ERROR',
      statusCode: 500,
      timestamp: new Date().toISOString(),
      requestId
    }
  };
};

// Error aggregation for multiple validation errors
export class ValidationErrorCollection extends ValidationError {
  public readonly errors: ValidationError[];

  constructor(errors: ValidationError[]) {
    const message = `Validation failed with ${errors.length} error(s)`;
    const context = {
      errors: errors.map(e => ({
        message: e.message,
        context: e.context
      }))
    };
    
    super(message, context);
    this.errors = errors;
  }
}

// Async error handling wrapper
export const catchAsync = <T extends any[], R>(
  fn: (...args: T) => Promise<R>
) => {
  return (...args: T): Promise<R> => {
    return fn(...args).catch((error) => {
      // Re-throw HMS errors as-is
      if (isHMSError(error)) {
        throw error;
      }
      
      // Wrap other errors in a generic HMS error
      throw new HMSError(
        error.message || 'An unexpected error occurred',
        'INTERNAL_ERROR',
        500,
        false,
        { originalError: error.name }
      );
    });
  };
};

// Error logging helper
export const logError = (error: Error, context?: Record<string, any>): void => {
  const logData = {
    name: error.name,
    message: error.message,
    stack: error.stack,
    timestamp: new Date().toISOString(),
    ...context
  };

  if (isHMSError(error)) {
    logData.code = error.code;
    logData.statusCode = error.statusCode;
    logData.isOperational = error.isOperational;
    logData.context = error.context;
  }

  // In development, log to console
  if (process.env.NODE_ENV === 'development') {
    console.error('Error logged:', logData);
  }

  // In production, use proper logging service
  // logger.error('Application error', logData);
};

// Export alias for base error
export { HMSError as BaseError };
