// Real authentication utility functions for Hospital Management System
// Implements secure authentication and authorization with proper security measures

import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";

// JWT Secret - In production, this should be in environment variables
const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "your-super-secret-jwt-key-change-this-in-production"
);

// Session configuration
const SESSION_DURATION = 60 * 60 * 24 * 7; // 7 days in seconds

// Define user type for type safety
export interface User {
  id: string;
  name: string;
  email: string;
  roles: string[];
  permissions: string[];
  createdAt?: Date;
  lastLogin?: Date;
}

// JWT Payload interface
interface JWTPayload {
  userId: string;
  email: string;
  roles: string[];
  iat: number;
  exp: number;
}

// Placeholder for PERMISSIONS constants
export const PERMISSIONS = {
  // Define permissions based on requirements
  VIEW_PATIENT: "patient:view",
  CREATE_PATIENT: "patient:create",
  EDIT_PATIENT: "patient:edit",
  VIEW_APPOINTMENT: "appointment:view",
  CREATE_APPOINTMENT: "appointment:create",
  EDIT_APPOINTMENT: "appointment:edit",
  BILLING_CREATE_INVOICE: "billing:invoice:create",
  BILLING_VIEW_INVOICE: "billing:invoice:view",
  // ... add all other permissions
};

/**
 * Check if the current user has any of the allowed roles
 */
export const checkUserRole = async (
  request: NextRequest,
  allowedRoles: string[]
): Promise<boolean> => {
  try {
    const user = await getCurrentUser(request);
    if (!user) return false;
    
    return user.roles.some(role => allowedRoles.includes(role));
  } catch (error) {
    console.error("Error checking user role:", error);
    return false;
  }
};

/**
 * Get current authenticated user from JWT token
 */
export const getCurrentUser = async (
  request?: NextRequest
): Promise<User | null> => {
  try {
    let token: string | undefined;
    
    if (request) {
      // Get token from request cookies
      token = request.cookies.get("auth_token")?.value;
    } else {
      // Get token from server-side cookies
      token = (await cookies()).get("auth_token")?.value;
    }
    
    if (!token) return null;
    
    // Verify and decode JWT token
    const { payload } = await jwtVerify(token, JWT_SECRET) as { payload: JWTPayload };
    
    // In a real application, you would fetch user data from database
    // For now, we'll construct user from JWT payload and fetch from a mock database
    const user = await getUserFromDatabase(payload.userId);
    
    return user;
  } catch (error) {
    console.error("Error getting current user:", error);
    return null;
  }
};

/**
 * Check if current user has required permissions
 */
export const hasPermission = async (
  request: NextRequest,
  requiredPermissions: string | string[]
): Promise<boolean> => {
  try {
    const user = await getCurrentUser(request);
    if (!user) return false;

    const permissionsToCheck = Array.isArray(requiredPermissions)
      ? requiredPermissions
      : [requiredPermissions];
    
    return permissionsToCheck.every((permission) => 
      user.permissions.includes(permission)
    );
  } catch (error) {
    console.error("Error checking permissions:", error);
    return false;
  }
};

/**
 * Clear authentication cookie
 */
export const clearAuthCookie = (res: NextResponse): void => {
  res.cookies.set("auth_token", "", {
    expires: new Date(0),
    path: "/",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
  });
};

/**
 * Set authentication cookie with secure options
 */
export const setAuthCookie = (res: NextResponse, token: string): void => {
  res.cookies.set("auth_token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: SESSION_DURATION,
  });
};

/**
 * Verify password against hash using bcrypt
 */
export const verifyPassword = async (
  password: string,
  hash: string
): Promise<boolean> => {
  try {
    return await bcrypt.compare(password, hash);
  } catch (error) {
    console.error("Error verifying password:", error);
    return false;
  }
};

/**
 * Sign JWT token with user data
 */
export const signToken = async (payload: {
  userId: string;
  email: string;
  roles: string[];
}): Promise<string> => {
  try {
    const token = await new SignJWT({
      userId: payload.userId,
      email: payload.email,
      roles: payload.roles,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime(`${SESSION_DURATION}s`)
      .sign(JWT_SECRET);
    
    return token;
  } catch (error) {
    console.error("Error signing token:", error);
    throw new Error("Failed to create authentication token");
  }
};

/**
 * Authentication middleware for protecting routes
 */
export async function authMiddleware(request: NextRequest): Promise<NextResponse> {
  const { pathname } = request.nextUrl;

  // Public routes that don't require authentication
  const publicRoutes = ["/login", "/api/auth/login", "/api/auth/register"];
  
  if (publicRoutes.some(route => pathname.startsWith(route))) {
    return NextResponse.next();
  }

  // Check for valid authentication
  const user = await getCurrentUser(request);
  
  if (!user) {
    // Redirect to login if not authenticated
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Add user info to headers for API routes
  const response = NextResponse.next();
  response.headers.set("x-user-id", user.id);
  response.headers.set("x-user-roles", JSON.stringify(user.roles));
  
  return response;
}

/**
 * Helper function to get user from database (mock implementation)
 * In production, this should connect to your actual database
 */
async function getUserFromDatabase(userId: string): Promise<User | null> {
  // TODO: Replace with actual database query
  // This is a mock implementation for development
  const mockUsers: Record<string, User> = {
    "user_123": {
      id: "user_123",
      name: "Dr. John Smith",
      email: "john.smith@hospital.com",
      roles: ["doctor", "admin"],
      permissions: Object.values(PERMISSIONS),
      createdAt: new Date(),
      lastLogin: new Date(),
    },
    "user_456": {
      id: "user_456",
      name: "Nurse Jane Doe",
      email: "jane.doe@hospital.com",
      roles: ["nurse"],
      permissions: [
        PERMISSIONS.VIEW_PATIENT,
        PERMISSIONS.VIEW_APPOINTMENT,
        PERMISSIONS.BILLING_VIEW_INVOICE,
      ],
      createdAt: new Date(),
      lastLogin: new Date(),
    },
  };

  return mockUsers[userId] || null;
}

/**
 * Generate secure random string for tokens
 */
export const generateSecureToken = (length: number = 32): string => {
  return randomBytes(length).toString("hex");
};

/**
 * Hash password using bcrypt
 */
export const hashPassword = async (password: string): Promise<string> => {
  try {
    const saltRounds = 12; // High security salt rounds for medical data
    return await bcrypt.hash(password, saltRounds);
  } catch (error) {
    console.error("Error hashing password:", error);
    throw new Error("Failed to hash password");
  }
};
