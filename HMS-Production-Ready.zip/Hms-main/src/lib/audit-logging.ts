/**
 * Audit Logging Service
 * Comprehensive audit trail system for the Hospital Management System
 */

import { config } from '@/config';

// Audit event types
export enum AuditEventType {
  // Authentication events
  LOGIN = 'LOGIN',
  LOGOUT = 'LOGOUT',
  LOGIN_FAILED = 'LOGIN_FAILED',
  PASSWORD_CHANGED = 'PASSWORD_CHANGED',

  // Patient data events
  PATIENT_CREATED = 'PATIENT_CREATED',
  PATIENT_UPDATED = 'PATIENT_UPDATED',
  PATIENT_VIEWED = 'PATIENT_VIEWED',
  PATIENT_DELETED = 'PATIENT_DELETED',

  // Medical record events
  MEDICAL_RECORD_CREATED = 'MEDICAL_RECORD_CREATED',
  MEDICAL_RECORD_UPDATED = 'MEDICAL_RECORD_UPDATED',
  MEDICAL_RECORD_VIEWED = 'MEDICAL_RECORD_VIEWED',
  MEDICAL_RECORD_DELETED = 'MEDICAL_RECORD_DELETED',

  // Prescription events
  PRESCRIPTION_CREATED = 'PRESCRIPTION_CREATED',
  PRESCRIPTION_UPDATED = 'PRESCRIPTION_UPDATED',
  PRESCRIPTION_DISPENSED = 'PRESCRIPTION_DISPENSED',
  PRESCRIPTION_CANCELLED = 'PRESCRIPTION_CANCELLED',

  // Laboratory events
  LAB_ORDER_CREATED = 'LAB_ORDER_CREATED',
  LAB_RESULT_UPDATED = 'LAB_RESULT_UPDATED',
  LAB_RESULT_VIEWED = 'LAB_RESULT_VIEWED',

  // Billing events
  INVOICE_CREATED = 'INVOICE_CREATED',
  PAYMENT_PROCESSED = 'PAYMENT_PROCESSED',
  REFUND_PROCESSED = 'REFUND_PROCESSED',

  // System events
  SYSTEM_BACKUP = 'SYSTEM_BACKUP',
  SYSTEM_RESTORE = 'SYSTEM_RESTORE',
  SYSTEM_MAINTENANCE = 'SYSTEM_MAINTENANCE',

  // Security events
  UNAUTHORIZED_ACCESS = 'UNAUTHORIZED_ACCESS',
  PERMISSION_DENIED = 'PERMISSION_DENIED',
  DATA_BREACH_ATTEMPT = 'DATA_BREACH_ATTEMPT',

  // Administrative events
  USER_CREATED = 'USER_CREATED',
  USER_UPDATED = 'USER_UPDATED',
  USER_DEACTIVATED = 'USER_DEACTIVATED',
  ROLE_ASSIGNED = 'ROLE_ASSIGNED',
  PERMISSION_GRANTED = 'PERMISSION_GRANTED',
}

// Audit severity levels
export enum AuditSeverity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

// Audit log entry structure
export interface AuditLogEntry {
  id?: string;
  timestamp: Date;
  eventType: AuditEventType;
  severity: AuditSeverity;
  userId?: string;
  userEmail?: string;
  userRole?: string;
  patientId?: string;
  resourceType: string;
  resourceId?: string;
  action: string;
  description: string;
  ipAddress?: string;
  userAgent?: string;
  sessionId?: string;
  additionalData?: Record<string, any>;
  beforeState?: Record<string, any>;
  afterState?: Record<string, any>;
  success: boolean;
  errorMessage?: string;
}

// Audit context for tracking user and session information
export interface AuditContext {
  userId?: string;
  userEmail?: string;
  userRole?: string;
  sessionId?: string;
  ipAddress?: string;
  userAgent?: string;
}

class AuditLogger {
  private context: AuditContext = {};

  constructor() {
    // Initialize with default context
  }

  // Set audit context (usually from middleware)
  setContext(context: Partial<AuditContext>): void {
    this.context = { ...this.context, ...context };
  }

  // Get current context
  getContext(): AuditContext {
    return { ...this.context };
  }

  // Clear context (useful for cleanup)
  clearContext(): void {
    this.context = {};
  }

  // Log an audit event
  async log(entry: Omit<AuditLogEntry, 'timestamp' | 'id'>): Promise<void> {
    const auditEntry: AuditLogEntry = {
      id: this.generateId(),
      timestamp: new Date(),
      userId: this.context.userId,
      userEmail: this.context.userEmail,
      userRole: this.context.userRole,
      sessionId: this.context.sessionId,
      ipAddress: this.context.ipAddress,
      userAgent: this.context.userAgent,
      ...entry
    };

    try {
      // Store audit log entry
      await this.storeAuditEntry(auditEntry);

      // Send real-time alerts for critical events
      if (entry.severity === AuditSeverity.CRITICAL) {
        await this.sendCriticalAlert(auditEntry);
      }

      // Log to console in development
      if (process.env.NODE_ENV === 'development') {
        console.log('Audit Log:', auditEntry);
      }
    } catch (error) {
      console.error('Failed to log audit entry:', error);
      // In production, this should be handled more gracefully
      // and possibly stored in a fallback location
    }
  }

  // Helper methods for common audit scenarios
  async logLogin(userId: string, userEmail: string, success: boolean, errorMessage?: string): Promise<void> {
    await this.log({
      eventType: success ? AuditEventType.LOGIN : AuditEventType.LOGIN_FAILED,
      severity: success ? AuditSeverity.LOW : AuditSeverity.MEDIUM,
      resourceType: 'authentication',
      action: 'login',
      description: success ? 
        `User ${userEmail} logged in successfully` : 
        `Failed login attempt for user ${userEmail}`,
      success,
      errorMessage,
      additionalData: { userId, userEmail }
    });
  }

  async logLogout(userId: string, userEmail: string): Promise<void> {
    await this.log({
      eventType: AuditEventType.LOGOUT,
      severity: AuditSeverity.LOW,
      resourceType: 'authentication',
      action: 'logout',
      description: `User ${userEmail} logged out`,
      success: true,
      additionalData: { userId, userEmail }
    });
  }

  async logPatientAccess(patientId: string, action: 'create' | 'view' | 'update' | 'delete'): Promise<void> {
    const eventTypeMap = {
      create: AuditEventType.PATIENT_CREATED,
      view: AuditEventType.PATIENT_VIEWED,
      update: AuditEventType.PATIENT_UPDATED,
      delete: AuditEventType.PATIENT_DELETED
    };

    await this.log({
      eventType: eventTypeMap[action],
      severity: action === 'delete' ? AuditSeverity.HIGH : AuditSeverity.MEDIUM,
      patientId,
      resourceType: 'patient',
      resourceId: patientId,
      action,
      description: `Patient record ${action}d`,
      success: true
    });
  }

  async logMedicalRecordAccess(
    patientId: string, 
    recordId: string, 
    action: 'create' | 'view' | 'update' | 'delete',
    beforeState?: Record<string, any>,
    afterState?: Record<string, any>
  ): Promise<void> {
    const eventTypeMap = {
      create: AuditEventType.MEDICAL_RECORD_CREATED,
      view: AuditEventType.MEDICAL_RECORD_VIEWED,
      update: AuditEventType.MEDICAL_RECORD_UPDATED,
      delete: AuditEventType.MEDICAL_RECORD_DELETED
    };

    await this.log({
      eventType: eventTypeMap[action],
      severity: AuditSeverity.HIGH,
      patientId,
      resourceType: 'medical_record',
      resourceId: recordId,
      action,
      description: `Medical record ${action}d for patient ${patientId}`,
      success: true,
      beforeState,
      afterState
    });
  }

  async logPrescriptionEvent(
    patientId: string,
    prescriptionId: string,
    action: 'create' | 'update' | 'dispense' | 'cancel',
    additionalData?: Record<string, any>
  ): Promise<void> {
    const eventTypeMap = {
      create: AuditEventType.PRESCRIPTION_CREATED,
      update: AuditEventType.PRESCRIPTION_UPDATED,
      dispense: AuditEventType.PRESCRIPTION_DISPENSED,
      cancel: AuditEventType.PRESCRIPTION_CANCELLED
    };

    await this.log({
      eventType: eventTypeMap[action],
      severity: AuditSeverity.HIGH,
      patientId,
      resourceType: 'prescription',
      resourceId: prescriptionId,
      action,
      description: `Prescription ${action}d for patient ${patientId}`,
      success: true,
      additionalData
    });
  }

  async logSecurityEvent(
    eventType: AuditEventType,
    description: string,
    additionalData?: Record<string, any>
  ): Promise<void> {
    await this.log({
      eventType,
      severity: AuditSeverity.CRITICAL,
      resourceType: 'security',
      action: 'security_event',
      description,
      success: false,
      additionalData
    });
  }

  async logSystemEvent(
    eventType: AuditEventType,
    description: string,
    success: boolean = true,
    additionalData?: Record<string, any>
  ): Promise<void> {
    await this.log({
      eventType,
      severity: AuditSeverity.MEDIUM,
      resourceType: 'system',
      action: 'system_event',
      description,
      success,
      additionalData
    });
  }

  // Private helper methods
  private generateId(): string {
    return `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private async storeAuditEntry(entry: AuditLogEntry): Promise<void> {
    // In a real implementation, this would:
    // 1. Store in database (preferably a dedicated audit database)
    // 2. Store in immutable storage (like AWS S3 with object lock)
    // 3. Send to external logging service (like ELK stack)
    
    // Placeholder implementation - in production, use proper audit storage
    if (config.logging.enableAuditLog) {
      // Store in database using Prisma
      // await prisma.auditLog.create({ data: entry });
      
      // For now, just log to console in development
      if (process.env.NODE_ENV === 'development') {
        console.log('Audit Entry Stored:', JSON.stringify(entry, null, 2));
      }
    }
  }

  private async sendCriticalAlert(entry: AuditLogEntry): Promise<void> {
    // In production, this would send alerts via:
    // 1. Email to security team
    // 2. SMS to on-call personnel
    // 3. Integration with incident management systems
    // 4. Real-time dashboard notifications
    
    console.warn('CRITICAL AUDIT EVENT:', entry);
    
    // Placeholder for real alert implementation
    if (config.features.enableNotifications) {
      // await notificationService.sendCriticalAlert(entry);
    }
  }
}

// Create singleton instance
export const auditLogger = new AuditLogger();

// Middleware helper for setting audit context
export const setAuditContext = (context: Partial<AuditContext>) => {
  auditLogger.setContext(context);
};

// Express middleware for automatic audit context setup
export const auditMiddleware = (req: any, res: any, next: any) => {
  const context: AuditContext = {
    ipAddress: req.ip || req.connection.remoteAddress,
    userAgent: req.headers['user-agent'],
    sessionId: req.sessionID,
    // Add user info if available from session/JWT
    userId: req.user?.id,
    userEmail: req.user?.email,
    userRole: req.user?.role
  };

  auditLogger.setContext(context);
  next();
};

// Decorator for automatic audit logging of functions
export const auditLog = (
  eventType: AuditEventType,
  resourceType: string,
  action: string
) => {
  return function (target: any, propertyName: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      const startTime = Date.now();
      let success = true;
      let errorMessage: string | undefined;
      let result: any;

      try {
        result = await method.apply(this, args);
        return result;
      } catch (error) {
        success = false;
        errorMessage = error instanceof Error ? error.message : 'Unknown error';
        throw error;
      } finally {
        const duration = Date.now() - startTime;
        
        await auditLogger.log({
          eventType,
          severity: success ? AuditSeverity.LOW : AuditSeverity.HIGH,
          resourceType,
          action,
          description: `${action} operation on ${resourceType}`,
          success,
          errorMessage,
          additionalData: {
            duration,
            method: propertyName,
            arguments: args.length
          }
        });
      }
    };

    return descriptor;
  };
};

// Query helpers for audit log analysis
export interface AuditQueryOptions {
  userId?: string;
  patientId?: string;
  eventType?: AuditEventType;
  severity?: AuditSeverity;
  resourceType?: string;
  dateFrom?: Date;
  dateTo?: Date;
  limit?: number;
  offset?: number;
}

export const queryAuditLogs = async (options: AuditQueryOptions): Promise<AuditLogEntry[]> => {
  // In production, this would query the audit database
  // with proper indexing and filtering
  
  // Placeholder implementation
  console.log('Querying audit logs with options:', options);
  return [];
};

// Export types and constants - already exported above
export type {
  AuditLogEntry,
  AuditContext,
  AuditQueryOptions
};

// Default export
export default auditLogger;