/**
 * Formatting utilities for Hospital Management System
 * Includes currency, date, number, and medical data formatters
 */

// Currency formatter
export const formatCurrency = (amount: number, currency = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount)
}

// Number formatter with localization
export const formatNumber = (value: number, options?: Intl.NumberFormatOptions): string => {
  return new Intl.NumberFormat('en-US', options).format(value)
}

// Date formatters
export const formatDate = (date: Date | string, format: 'short' | 'medium' | 'long' | 'full' = 'medium'): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date
  
  const formats = {
    short: { dateStyle: 'short' as const },
    medium: { dateStyle: 'medium' as const },
    long: { dateStyle: 'long' as const },
    full: { dateStyle: 'full' as const },
  }
  
  return new Intl.DateTimeFormat('en-US', formats[format]).format(dateObj)
}

export const formatDateTime = (date: Date | string): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(dateObj)
}

export const formatTime = (date: Date | string): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date
  return new Intl.DateTimeFormat('en-US', {
    timeStyle: 'short',
  }).format(dateObj)
}

// Medical record number formatter
export const formatMRN = (mrn: string): string => {
  // Format MRN as XXX-XXX-XXXX
  const cleaned = mrn.replace(/\D/g, '')
  const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/)
  if (match) {
    return `${match[1]}-${match[2]}-${match[3]}`
  }
  return mrn
}

// Phone number formatter
export const formatPhoneNumber = (phoneNumber: string): string => {
  const cleaned = phoneNumber.replace(/\D/g, '')
  const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/)
  if (match) {
    return `(${match[1]}) ${match[2]}-${match[3]}`
  }
  return phoneNumber
}

// Percentage formatter
export const formatPercentage = (value: number, decimals = 1): string => {
  return `${(value * 100).toFixed(decimals)}%`
}

// File size formatter
export const formatFileSize = (bytes: number): string => {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
  if (bytes === 0) return '0 Bytes'
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return `${Math.round(bytes / Math.pow(1024, i) * 100) / 100} ${sizes[i]}`
}

// Name formatter (capitalize first letters)
export const formatName = (name: string): string => {
  return name
    .toLowerCase()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ')
}

// Insurance policy number formatter
export const formatInsuranceNumber = (policyNumber: string): string => {
  // Format as XXX-XX-XXXXXX
  const cleaned = policyNumber.replace(/\D/g, '')
  const match = cleaned.match(/^(\d{3})(\d{2})(\d{6})$/)
  if (match) {
    return `${match[1]}-${match[2]}-${match[3]}`
  }
  return policyNumber
}

// Status formatter with proper casing
export const formatStatus = (status: string): string => {
  return status
    .replace(/([A-Z])/g, ' $1') // Add space before capital letters
    .replace(/^./, str => str.toUpperCase()) // Capitalize first letter
    .trim()
}

// Duration formatter (for appointments, procedures)
export const formatDuration = (minutes: number): string => {
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  
  if (hours === 0) {
    return `${mins}m`
  } else if (mins === 0) {
    return `${hours}h`
  } else {
    return `${hours}h ${mins}m`
  }
}

// Age formatter from birth date
export const formatAge = (birthDate: Date | string): string => {
  const birth = typeof birthDate === 'string' ? new Date(birthDate) : birthDate
  const today = new Date()
  let age = today.getFullYear() - birth.getFullYear()
  const monthDiff = today.getMonth() - birth.getMonth()
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--
  }
  
  return `${age} years`
}

// Bill status formatter with color coding
export const formatBillStatus = (status: string): { text: string; color: string } => {
  const statusMap: Record<string, { text: string; color: string }> = {
    draft: { text: 'Draft', color: 'gray' },
    pending: { text: 'Pending', color: 'yellow' },
    verified: { text: 'Verified', color: 'blue' },
    approved: { text: 'Approved', color: 'green' },
    sent: { text: 'Sent', color: 'purple' },
    partial: { text: 'Partially Paid', color: 'orange' },
    paid: { text: 'Paid', color: 'green' },
    overdue: { text: 'Overdue', color: 'red' },
    cancelled: { text: 'Cancelled', color: 'gray' },
    refunded: { text: 'Refunded', color: 'indigo' },
  }
  
  return statusMap[status.toLowerCase()] || { text: formatStatus(status), color: 'gray' }
}

// Compact number formatter (1K, 1M, etc.)
export const formatCompactNumber = (value: number): string => {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value)
}

// Blood type formatter
export const formatBloodType = (bloodType: string): string => {
  return bloodType.toUpperCase().replace(/([ABO])([+-])/, '$1$2')
}

// Emergency contact formatter
export const formatEmergencyContact = (contact: { name: string; relationship: string; phone: string }): string => {
  return `${formatName(contact.name)} (${contact.relationship}) - ${formatPhoneNumber(contact.phone)}`
}
