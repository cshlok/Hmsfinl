/**
 * Permissions Module
 * Defines and manages user permissions across the Hospital Management System
 * Provides centralized permission constants and validation functions
 */

import { logger } from '@/lib/logger';
import { prisma } from '@/lib/prisma';

// Permission constants
export const PERMISSIONS = {
  // Patient permissions
  PATIENT_VIEW: 'patient:view',
  PATIENT_CREATE: 'patient:create',
  PATIENT_EDIT: 'patient:edit',
  PATIENT_DELETE: 'patient:delete',
  PATIENT_SEARCH: 'patient:search',

  // Medical records permissions
  MEDICAL_RECORD_VIEW: 'medical_record:view',
  MEDICAL_RECORD_CREATE: 'medical_record:create',
  MEDICAL_RECORD_EDIT: 'medical_record:edit',
  MEDICAL_RECORD_DELETE: 'medical_record:delete',

  // Prescription permissions
  PRESCRIPTION_VIEW: 'prescription:view',
  PRESCRIPTION_CREATE: 'prescription:create',
  PRESCRIPTION_EDIT: 'prescription:edit',
  PRESCRIPTION_CANCEL: 'prescription:cancel',
  PRESCRIPTION_RENEW: 'prescription:renew',

  // Medication permissions
  MEDICATION_VIEW: 'medication:view',
  MEDICATION_DISPENSE: 'medication:dispense',
  MEDICATION_ADMINISTER: 'medication:administer',
  MEDICATION_INVENTORY: 'medication:inventory',

  // Lab permissions
  LAB_ORDER_CREATE: 'lab:order:create',
  LAB_ORDER_VIEW: 'lab:order:view',
  LAB_RESULT_VIEW: 'lab:result:view',
  LAB_RESULT_ENTER: 'lab:result:enter',
  LAB_RESULT_VERIFY: 'lab:result:verify',

  // Radiology permissions
  RADIOLOGY_ORDER_CREATE: 'radiology:order:create',
  RADIOLOGY_ORDER_VIEW: 'radiology:order:view',
  RADIOLOGY_RESULT_VIEW: 'radiology:result:view',
  RADIOLOGY_RESULT_ENTER: 'radiology:result:enter',

  // Billing permissions
  BILLING_VIEW: 'billing:view',
  BILLING_CREATE: 'billing:create',
  BILLING_EDIT: 'billing:edit',
  BILLING_PROCESS: 'billing:process',

  // Appointment permissions
  APPOINTMENT_VIEW: 'appointment:view',
  APPOINTMENT_CREATE: 'appointment:create',
  APPOINTMENT_EDIT: 'appointment:edit',
  APPOINTMENT_CANCEL: 'appointment:cancel',

  // Administrative permissions
  USER_MANAGEMENT: 'admin:user:manage',
  ROLE_MANAGEMENT: 'admin:role:manage',
  SYSTEM_CONFIG: 'admin:system:config',
  AUDIT_VIEW: 'admin:audit:view',

  // Emergency permissions
  EMERGENCY_ACCESS: 'emergency:access',
  OVERRIDE_RESTRICTIONS: 'emergency:override',

  // Marketing permissions
  MARKETING_CAMPAIGN_VIEW: 'marketing:campaign:view',
  MARKETING_CAMPAIGN_CREATE: 'marketing:campaign:create',
  MARKETING_CAMPAIGN_EDIT: 'marketing:campaign:edit',
  MARKETING_CAMPAIGN_DELETE: 'marketing:campaign:delete',
  MARKETING_ANALYTICS_VIEW: 'marketing:analytics:view',

  // Support services permissions
  MAINTENANCE_REQUEST: 'support:maintenance:request',
  MAINTENANCE_MANAGE: 'support:maintenance:manage',
  HOUSEKEEPING_REQUEST: 'support:housekeeping:request',
  HOUSEKEEPING_MANAGE: 'support:housekeeping:manage',
  DIETARY_REQUEST: 'support:dietary:request',
  DIETARY_MANAGE: 'support:dietary:manage',
};

// Role-based permission groups
export const ROLE_PERMISSIONS = {
  physician: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.PATIENT_CREATE,
    PERMISSIONS.PATIENT_EDIT,
    PERMISSIONS.PATIENT_SEARCH,
    PERMISSIONS.MEDICAL_RECORD_VIEW,
    PERMISSIONS.MEDICAL_RECORD_CREATE,
    PERMISSIONS.MEDICAL_RECORD_EDIT,
    PERMISSIONS.PRESCRIPTION_VIEW,
    PERMISSIONS.PRESCRIPTION_CREATE,
    PERMISSIONS.PRESCRIPTION_EDIT,
    PERMISSIONS.PRESCRIPTION_CANCEL,
    PERMISSIONS.PRESCRIPTION_RENEW,
    PERMISSIONS.MEDICATION_VIEW,
    PERMISSIONS.LAB_ORDER_CREATE,
    PERMISSIONS.LAB_ORDER_VIEW,
    PERMISSIONS.LAB_RESULT_VIEW,
    PERMISSIONS.RADIOLOGY_ORDER_CREATE,
    PERMISSIONS.RADIOLOGY_ORDER_VIEW,
    PERMISSIONS.RADIOLOGY_RESULT_VIEW,
    PERMISSIONS.APPOINTMENT_VIEW,
    PERMISSIONS.APPOINTMENT_CREATE,
    PERMISSIONS.APPOINTMENT_EDIT,
    PERMISSIONS.EMERGENCY_ACCESS,
  ],

  nurse: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.PATIENT_SEARCH,
    PERMISSIONS.MEDICAL_RECORD_VIEW,
    PERMISSIONS.MEDICAL_RECORD_CREATE,
    PERMISSIONS.PRESCRIPTION_VIEW,
    PERMISSIONS.MEDICATION_VIEW,
    PERMISSIONS.MEDICATION_ADMINISTER,
    PERMISSIONS.LAB_ORDER_VIEW,
    PERMISSIONS.LAB_RESULT_VIEW,
    PERMISSIONS.APPOINTMENT_VIEW,
    PERMISSIONS.EMERGENCY_ACCESS,
  ],

  pharmacist: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.PATIENT_SEARCH,
    PERMISSIONS.PRESCRIPTION_VIEW,
    PERMISSIONS.PRESCRIPTION_EDIT,
    PERMISSIONS.MEDICATION_VIEW,
    PERMISSIONS.MEDICATION_DISPENSE,
    PERMISSIONS.MEDICATION_INVENTORY,
    PERMISSIONS.LAB_RESULT_VIEW,
  ],

  lab_technician: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.LAB_ORDER_VIEW,
    PERMISSIONS.LAB_RESULT_VIEW,
    PERMISSIONS.LAB_RESULT_ENTER,
  ],

  radiologist: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.RADIOLOGY_ORDER_VIEW,
    PERMISSIONS.RADIOLOGY_RESULT_VIEW,
    PERMISSIONS.RADIOLOGY_RESULT_ENTER,
  ],

  billing_staff: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.BILLING_VIEW,
    PERMISSIONS.BILLING_CREATE,
    PERMISSIONS.BILLING_EDIT,
    PERMISSIONS.BILLING_PROCESS,
  ],

  receptionist: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.PATIENT_CREATE,
    PERMISSIONS.PATIENT_EDIT,
    PERMISSIONS.PATIENT_SEARCH,
    PERMISSIONS.APPOINTMENT_VIEW,
    PERMISSIONS.APPOINTMENT_CREATE,
    PERMISSIONS.APPOINTMENT_EDIT,
    PERMISSIONS.APPOINTMENT_CANCEL,
  ],

  admin: Object.values(PERMISSIONS), // Admins get all permissions

  marketing_manager: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.MARKETING_CAMPAIGN_VIEW,
    PERMISSIONS.MARKETING_CAMPAIGN_CREATE,
    PERMISSIONS.MARKETING_CAMPAIGN_EDIT,
    PERMISSIONS.MARKETING_CAMPAIGN_DELETE,
    PERMISSIONS.MARKETING_ANALYTICS_VIEW,
  ],

  maintenance_staff: [
    PERMISSIONS.MAINTENANCE_REQUEST,
    PERMISSIONS.MAINTENANCE_MANAGE,
  ],

  housekeeping_staff: [
    PERMISSIONS.HOUSEKEEPING_REQUEST,
    PERMISSIONS.HOUSEKEEPING_MANAGE,
  ],

  dietary_staff: [
    PERMISSIONS.PATIENT_VIEW,
    PERMISSIONS.DIETARY_REQUEST,
    PERMISSIONS.DIETARY_MANAGE,
  ],
};

/**
 * Check if a user has a specific permission
 */
export async function hasPermission(userId: string, permission: string): Promise<boolean> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        roles: {
          include: {
            permissions: true
          }
        }
      }
    });

    if (!user) {
      logger.warn(`User not found for permission check: ${userId}`);
      return false;
    }

    // Check if user has the permission through any of their roles
    for (const role of user.roles) {
      if (role.permissions.some(p => p.name === permission)) {
        return true;
      }
    }

    return false;

  } catch (error) {
    logger.error('Error checking user permission:', error, { userId, permission });
    return false; // Default to deny on error
  }
}

/**
 * Check if a user has any of the specified permissions
 */
export async function hasAnyPermission(userId: string, permissions: string[]): Promise<boolean> {
  for (const permission of permissions) {
    if (await hasPermission(userId, permission)) {
      return true;
    }
  }
  return false;
}

/**
 * Check if a user has all of the specified permissions
 */
export async function hasAllPermissions(userId: string, permissions: string[]): Promise<boolean> {
  for (const permission of permissions) {
    if (!(await hasPermission(userId, permission))) {
      return false;
    }
  }
  return true;
}

/**
 * Get all permissions for a user
 */
export async function getUserPermissions(userId: string): Promise<string[]> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        roles: {
          include: {
            permissions: true
          }
        }
      }
    });

    if (!user) {
      return [];
    }

    const permissions = new Set<string>();
    for (const role of user.roles) {
      for (const permission of role.permissions) {
        permissions.add(permission.name);
      }
    }

    return Array.from(permissions);

  } catch (error) {
    logger.error('Error getting user permissions:', error, { userId });
    return [];
  }
}

/**
 * Check if a user has a specific role
 */
export async function hasRole(userId: string, roleName: string): Promise<boolean> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        roles: true
      }
    });

    if (!user) {
      return false;
    }

    return user.roles.some(role => role.name === roleName);

  } catch (error) {
    logger.error('Error checking user role:', error, { userId, roleName });
    return false;
  }
}

/**
 * Get all roles for a user
 */
export async function getUserRoles(userId: string): Promise<string[]> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        roles: true
      }
    });

    if (!user) {
      return [];
    }

    return user.roles.map(role => role.name);

  } catch (error) {
    logger.error('Error getting user roles:', error, { userId });
    return [];
  }
}

/**
 * Check if a user can perform a specific action on a resource
 */
export async function canAccess(
  userId: string,
  resource: string,
  action: string,
  resourceId?: string
): Promise<boolean> {
  const permission = `${resource}:${action}`;
  
  // First check basic permission
  const hasBasicPermission = await hasPermission(userId, permission);
  if (!hasBasicPermission) {
    return false;
  }

  // Additional checks can be added here for resource-specific permissions
  // For example, checking if user has access to specific patient records
  if (resourceId && resource === 'patient') {
    return await canAccessPatient(userId, resourceId);
  }

  return true;
}

/**
 * Check if a user can access a specific patient's data
 */
async function canAccessPatient(userId: string, patientId: string): Promise<boolean> {
  try {
    // In a real implementation, you might check:
    // - If user is assigned to the patient
    // - If user is in the same department/unit
    // - If user has emergency access
    // - Patient consent settings
    
    // For now, allow access if user has patient view permission
    return await hasPermission(userId, PERMISSIONS.PATIENT_VIEW);

  } catch (error) {
    logger.error('Error checking patient access:', error, { userId, patientId });
    return false;
  }
}

/**
 * Emergency access override (with proper logging)
 */
export async function requestEmergencyAccess(
  userId: string,
  resource: string,
  resourceId: string,
  justification: string
): Promise<boolean> {
  try {
    // Check if user has emergency access permission
    const hasEmergencyPermission = await hasPermission(userId, PERMISSIONS.EMERGENCY_ACCESS);
    if (!hasEmergencyPermission) {
      return false;
    }

    // Log emergency access
    logger.warn('Emergency access requested', {
      userId,
      resource,
      resourceId,
      justification,
      timestamp: new Date().toISOString()
    });

    // In a real implementation, you might:
    // - Send immediate alerts to supervisors
    // - Require additional authorization
    // - Set time limits on emergency access
    // - Create audit trail entries

    return true;

  } catch (error) {
    logger.error('Error processing emergency access request:', error, {
      userId,
      resource,
      resourceId
    });
    return false;
  }
}

// Export permission checking functions
export {
  hasPermission as checkPermission,
  hasAnyPermission as checkAnyPermission,
  hasAllPermissions as checkAllPermissions,
  canAccess as checkAccess
};
