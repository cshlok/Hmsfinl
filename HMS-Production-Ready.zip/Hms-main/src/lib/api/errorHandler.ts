/**
 * API Error Handler for Hospital Management System
 * Provides centralized error handling with HIPAA compliance and security
 */

import { NextRequest, NextResponse } from 'next/server'
import logger from '@/lib/logger'

// Error types
export enum ErrorType {
  VALIDATION = 'VALIDATION_ERROR',
  AUTHENTICATION = 'AUTHENTICATION_ERROR',
  AUTHORIZATION = 'AUTHORIZATION_ERROR',
  NOT_FOUND = 'NOT_FOUND_ERROR',
  CONFLICT = 'CONFLICT_ERROR',
  RATE_LIMIT = 'RATE_LIMIT_ERROR',
  DATABASE = 'DATABASE_ERROR',
  EXTERNAL_API = 'EXTERNAL_API_ERROR',
  INTERNAL = 'INTERNAL_ERROR',
  FORBIDDEN = 'FORBIDDEN_ERROR',
  BAD_REQUEST = 'BAD_REQUEST_ERROR'
}

// Custom error class
export class ApiError extends Error {
  public readonly type: ErrorType
  public readonly statusCode: number
  public readonly isOperational: boolean
  public readonly context?: Record<string, any>

  constructor(
    message: string,
    type: ErrorType = ErrorType.INTERNAL,
    statusCode: number = 500,
    isOperational: boolean = true,
    context?: Record<string, any>
  ) {
    super(message)
    this.name = 'ApiError'
    this.type = type
    this.statusCode = statusCode
    this.isOperational = isOperational
    this.context = context

    Error.captureStackTrace(this, this.constructor)
  }
}

// Error response interface
interface ErrorResponse {
  error: {
    type: ErrorType
    message: string
    code: string
    timestamp: string
    path?: string
    requestId?: string
    details?: Record<string, any>
  }
}

// Error code mappings
const errorCodeMap: Record<ErrorType, { code: string; defaultStatus: number }> = {
  [ErrorType.VALIDATION]: { code: 'VALIDATION_FAILED', defaultStatus: 400 },
  [ErrorType.AUTHENTICATION]: { code: 'AUTHENTICATION_REQUIRED', defaultStatus: 401 },
  [ErrorType.AUTHORIZATION]: { code: 'INSUFFICIENT_PERMISSIONS', defaultStatus: 403 },
  [ErrorType.NOT_FOUND]: { code: 'RESOURCE_NOT_FOUND', defaultStatus: 404 },
  [ErrorType.CONFLICT]: { code: 'RESOURCE_CONFLICT', defaultStatus: 409 },
  [ErrorType.RATE_LIMIT]: { code: 'RATE_LIMIT_EXCEEDED', defaultStatus: 429 },
  [ErrorType.DATABASE]: { code: 'DATABASE_ERROR', defaultStatus: 500 },
  [ErrorType.EXTERNAL_API]: { code: 'EXTERNAL_SERVICE_ERROR', defaultStatus: 502 },
  [ErrorType.INTERNAL]: { code: 'INTERNAL_SERVER_ERROR', defaultStatus: 500 },
  [ErrorType.FORBIDDEN]: { code: 'ACCESS_FORBIDDEN', defaultStatus: 403 },
  [ErrorType.BAD_REQUEST]: { code: 'BAD_REQUEST', defaultStatus: 400 }
}

/**
 * Generate unique request ID for tracking
 */
const generateRequestId = (): string => {
  return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

/**
 * Sanitize error message to prevent sensitive data leakage
 */
const sanitizeErrorMessage = (message: string, isProduction: boolean): string => {
  if (!isProduction) {
    return message
  }

  // In production, sanitize error messages to prevent information disclosure
  const sensitivePatterns = [
    /password/gi,
    /token/gi,
    /secret/gi,
    /key/gi,
    /ssn/gi,
    /credit card/gi,
    /medical record/gi
  ]

  let sanitized = message
  sensitivePatterns.forEach(pattern => {
    sanitized = sanitized.replace(pattern, '[REDACTED]')
  })

  return sanitized
}

/**
 * Create standardized error response
 */
export const createErrorResponse = (
  error: Error,
  request?: NextRequest,
  requestId?: string
): { response: ErrorResponse; statusCode: number } => {
  const isProduction = process.env.NODE_ENV === 'production'
  const timestamp = new Date().toISOString()
  const reqId = requestId || generateRequestId()

  let apiError: ApiError
  
  if (error instanceof ApiError) {
    apiError = error
  } else {
    // Convert unknown errors to ApiError
    apiError = new ApiError(
      error.message || 'An unexpected error occurred',
      ErrorType.INTERNAL,
      500,
      false,
      { originalError: error.name }
    )
  }

  const errorMapping = errorCodeMap[apiError.type]
  const statusCode = apiError.statusCode || errorMapping.defaultStatus

  const errorResponse: ErrorResponse = {
    error: {
      type: apiError.type,
      message: sanitizeErrorMessage(apiError.message, isProduction),
      code: errorMapping.code,
      timestamp,
      path: request?.nextUrl.pathname,
      requestId: reqId,
      ...(apiError.context && !isProduction && { details: apiError.context })
    }
  }

  return { response: errorResponse, statusCode }
}

/**
 * Log error with appropriate level and context
 */
const logError = (
  error: Error,
  request?: NextRequest,
  userId?: string,
  requestId?: string
): void => {
  const context = {
    userId,
    request: request ? {
      method: request.method,
      url: request.nextUrl.toString(),
      userAgent: request.headers.get('user-agent') || undefined,
      ip: request.headers.get('x-forwarded-for') || 
          request.headers.get('x-real-ip') || 
          'unknown'
    } : undefined,
    metadata: {
      requestId,
      timestamp: new Date().toISOString()
    }
  }

  if (error instanceof ApiError) {
    // Log operational errors at appropriate level
    if (error.isOperational) {
      if (error.statusCode >= 500) {
        logger.error(`API Error: ${error.message}`, error, context)
      } else {
        logger.warn(`API Warning: ${error.message}`, context)
      }
    } else {
      // Non-operational errors are always critical
      logger.fatal(`Critical API Error: ${error.message}`, error, context)
    }
  } else {
    // Unknown errors are always logged as errors
    logger.error(`Unexpected API Error: ${error.message}`, error, context)
  }
}

/**
 * Main error handling middleware
 */
export const errorHandlingMiddleware = async (
  request: NextRequest,
  handler: (req: NextRequest) => Promise<NextResponse>
): Promise<NextResponse> => {
  const requestId = generateRequestId()
  
  try {
    // Add request ID to headers for tracking
    request.headers.set('x-request-id', requestId)
    
    // Log incoming request
    logger.logRequest(
      request.method,
      request.nextUrl.pathname,
      undefined, // userId will be added by auth middleware
      request.headers.get('x-forwarded-for') || 'unknown',
      request.headers.get('user-agent') || undefined
    )

    return await handler(request)
  } catch (error) {
    const userId = request.headers.get('x-user-id') || undefined
    
    // Log the error
    logError(error as Error, request, userId, requestId)
    
    // Create error response
    const { response, statusCode } = createErrorResponse(
      error as Error,
      request,
      requestId
    )
    
    return NextResponse.json(response, { status: statusCode })
  }
}

/**
 * Predefined error creators for common scenarios
 */
export const createValidationError = (message: string, details?: Record<string, any>): ApiError => {
  return new ApiError(message, ErrorType.VALIDATION, 400, true, details)
}

export const createAuthenticationError = (message: string = 'Authentication required'): ApiError => {
  return new ApiError(message, ErrorType.AUTHENTICATION, 401, true)
}

export const createAuthorizationError = (message: string = 'Insufficient permissions'): ApiError => {
  return new ApiError(message, ErrorType.AUTHORIZATION, 403, true)
}

export const createNotFoundError = (resource: string = 'Resource'): ApiError => {
  return new ApiError(`${resource} not found`, ErrorType.NOT_FOUND, 404, true)
}

export const createConflictError = (message: string): ApiError => {
  return new ApiError(message, ErrorType.CONFLICT, 409, true)
}

export const createRateLimitError = (message: string = 'Rate limit exceeded'): ApiError => {
  return new ApiError(message, ErrorType.RATE_LIMIT, 429, true)
}

export const createDatabaseError = (message: string, context?: Record<string, any>): ApiError => {
  return new ApiError(
    'Database operation failed',
    ErrorType.DATABASE,
    500,
    true,
    { originalMessage: message, ...context }
  )
}

export const createExternalApiError = (service: string, message?: string): ApiError => {
  return new ApiError(
    `External service error: ${service}${message ? ` - ${message}` : ''}`,
    ErrorType.EXTERNAL_API,
    502,
    true,
    { service }
  )
}

/**
 * Handle async route errors
 */
export const asyncHandler = (
  fn: (request: NextRequest, context?: any) => Promise<NextResponse>
) => {
  return (request: NextRequest, context?: any): Promise<NextResponse> => {
    return errorHandlingMiddleware(request, () => fn(request, context))
  }
}

/**
 * Validation helper
 */
export const validateRequired = (data: Record<string, any>, requiredFields: string[]): void => {
  const missingFields = requiredFields.filter(field => 
    data[field] === undefined || data[field] === null || data[field] === ''
  )
  
  if (missingFields.length > 0) {
    throw createValidationError(
      `Missing required fields: ${missingFields.join(', ')}`,
      { missingFields }
    )
  }
}

/**
 * HIPAA compliant error response (no PHI in errors)
 */
export const createHipaaCompliantErrorResponse = (
  error: Error,
  request?: NextRequest
): NextResponse => {
  const { response, statusCode } = createErrorResponse(error, request)
  
  // Ensure no PHI is included in error responses
  const sanitizedResponse = {
    ...response,
    error: {
      ...response.error,
      message: response.error.message.includes('patient') ? 
        'An error occurred while processing your request' : 
        response.error.message,
      details: undefined // Never include details in HIPAA compliant responses
    }
  }
  
  return NextResponse.json(sanitizedResponse, { status: statusCode })
}

// Export utilities - ApiError and ErrorType already exported above
export { errorHandlingMiddleware as default }
