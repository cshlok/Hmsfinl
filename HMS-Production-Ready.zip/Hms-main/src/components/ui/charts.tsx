// Re-export chart components for easier importing
export * from './chart'

// Re-export Recharts components for compatibility
import {
  BarChart as RechartsBarChart,
  LineChart as RechartsLineChart,
  PieChart as RechartsPieChart,
  Area,
  AreaChart as RechartsAreaChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  Bar,
  Line,
  Pie,
} from 'recharts'

// Re-export Recharts components
export {
  RechartsBarChart as BarChart,
  RechartsLineChart as LineChart,
  RechartsPieChart as PieChart,
  RechartsAreaChart as AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  Bar,
  Line,
  Pie,
}

// Create DonutChart from PieChart
export const DonutChart = RechartsPieChart

// Additional chart utilities and components
import React from 'react'
import { cn } from '@/lib/utils'

interface ChartContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  title?: string
}

export const ChartContainer = React.forwardRef<HTMLDivElement, ChartContainerProps>(
  ({ className, children, title, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'rounded-lg border bg-card text-card-foreground shadow-sm',
          className
        )}
        {...props}
      >
        {title && (
          <div className="p-6 pb-2">
            <h3 className="text-lg font-semibold">{title}</h3>
          </div>
        )}
        <div className="p-6 pt-0">
          {children}
        </div>
      </div>
    )
  }
)

ChartContainer.displayName = 'ChartContainer'

export interface ChartDataPoint {
  name: string
  value: number
  [key: string]: any
}

export interface ChartConfig {
  [key: string]: {
    label: string
    color?: string
  }
}
