/**
 * Application Configuration
 * Centralized configuration management for the Hospital Management System
 */

// Environment variables with defaults
export const config = {
  // Database configuration
  database: {
    url: process.env.DATABASE_URL || 'postgresql://localhost:5432/hms_db',
    maxConnections: parseInt(process.env.DB_MAX_CONNECTIONS || '10'),
    connectionTimeout: parseInt(process.env.DB_CONNECTION_TIMEOUT || '30000'),
  },

  // Redis configuration
  redis: {
    enabled: process.env.REDIS_ENABLED === 'true',
    url: process.env.REDIS_URL || 'redis://localhost:6379',
    password: process.env.REDIS_PASSWORD,
    db: parseInt(process.env.REDIS_DB || '0'),
    keyPrefix: process.env.REDIS_KEY_PREFIX || 'hms:',
    ttl: parseInt(process.env.REDIS_TTL || '3600'), // 1 hour default
  },

  // Cache configuration
  cache: {
    enabled: process.env.CACHE_ENABLED !== 'false',
    defaultTtl: parseInt(process.env.CACHE_DEFAULT_TTL || '3600'),
    maxSize: parseInt(process.env.CACHE_MAX_SIZE || '1000'),
  },

  // Security configuration
  security: {
    jwtSecret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
    jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
    bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS || '12'),
    sessionSecret: process.env.SESSION_SECRET || 'your-session-secret-change-in-production',
    corsOrigins: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000'],
  },

  // Application configuration
  app: {
    name: process.env.APP_NAME || 'Hospital Management System',
    version: process.env.APP_VERSION || '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    port: parseInt(process.env.PORT || '3000'),
    baseUrl: process.env.BASE_URL || 'http://localhost:3000',
  },

  // Logging configuration
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    format: process.env.LOG_FORMAT || 'json',
    outputPath: process.env.LOG_OUTPUT_PATH,
    enableAuditLog: process.env.ENABLE_AUDIT_LOG !== 'false',
  },

  // Email configuration
  email: {
    enabled: process.env.EMAIL_ENABLED === 'true',
    provider: process.env.EMAIL_PROVIDER || 'smtp',
    smtp: {
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      user: process.env.SMTP_USER,
      password: process.env.SMTP_PASSWORD,
    },
    from: process.env.EMAIL_FROM || 'noreply@hospital.com',
  },

  // SMS configuration
  sms: {
    enabled: process.env.SMS_ENABLED === 'true',
    provider: process.env.SMS_PROVIDER || 'twilio',
    twilio: {
      accountSid: process.env.TWILIO_ACCOUNT_SID,
      authToken: process.env.TWILIO_AUTH_TOKEN,
      fromNumber: process.env.TWILIO_FROM_NUMBER,
    },
  },

  // File upload configuration
  upload: {
    maxFileSize: parseInt(process.env.MAX_FILE_SIZE || '10485760'), // 10MB
    allowedTypes: process.env.ALLOWED_FILE_TYPES?.split(',') || ['image/jpeg', 'image/png', 'application/pdf'],
    uploadPath: process.env.UPLOAD_PATH || '/tmp/uploads',
  },

  // External API configuration
  external: {
    fhirServer: {
      baseUrl: process.env.FHIR_SERVER_URL,
      apiKey: process.env.FHIR_API_KEY,
    },
    drugInteractionApi: {
      baseUrl: process.env.DRUG_INTERACTION_API_URL,
      apiKey: process.env.DRUG_INTERACTION_API_KEY,
    },
    labInterface: {
      baseUrl: process.env.LAB_INTERFACE_URL,
      apiKey: process.env.LAB_INTERFACE_API_KEY,
    },
  },

  // Feature flags
  features: {
    enablePatientPortal: process.env.FEATURE_PATIENT_PORTAL === 'true',
    enableTelemedicine: process.env.FEATURE_TELEMEDICINE === 'true',
    enableAnalytics: process.env.FEATURE_ANALYTICS !== 'false',
    enableNotifications: process.env.FEATURE_NOTIFICATIONS !== 'false',
    enableAuditTrail: process.env.FEATURE_AUDIT_TRAIL !== 'false',
  },

  // Business rules configuration
  business: {
    maxAppointmentsPerDay: parseInt(process.env.MAX_APPOINTMENTS_PER_DAY || '50'),
    appointmentSlotDuration: parseInt(process.env.APPOINTMENT_SLOT_DURATION || '30'), // minutes
    prescriptionValidityDays: parseInt(process.env.PRESCRIPTION_VALIDITY_DAYS || '30'),
    labResultRetentionDays: parseInt(process.env.LAB_RESULT_RETENTION_DAYS || '2555'), // 7 years
  },
};

// Environment-specific configuration
export const isDevelopment = config.app.environment === 'development';
export const isProduction = config.app.environment === 'production';
export const isTest = config.app.environment === 'test';

// Configuration validation
export function validateConfig(): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Validate required production settings
  if (isProduction) {
    if (!process.env.DATABASE_URL) {
      errors.push('DATABASE_URL is required in production');
    }
    if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
      errors.push('JWT_SECRET must be at least 32 characters in production');
    }
    if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
      errors.push('SESSION_SECRET must be at least 32 characters in production');
    }
  }

  // Validate email configuration if enabled
  if (config.email.enabled) {
    if (!config.email.smtp.host) {
      errors.push('SMTP_HOST is required when email is enabled');
    }
    if (!config.email.smtp.user) {
      errors.push('SMTP_USER is required when email is enabled');
    }
    if (!config.email.smtp.password) {
      errors.push('SMTP_PASSWORD is required when email is enabled');
    }
  }

  // Validate SMS configuration if enabled
  if (config.sms.enabled && config.sms.provider === 'twilio') {
    if (!config.sms.twilio.accountSid) {
      errors.push('TWILIO_ACCOUNT_SID is required when SMS is enabled');
    }
    if (!config.sms.twilio.authToken) {
      errors.push('TWILIO_AUTH_TOKEN is required when SMS is enabled');
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

// Export individual config sections for convenience
export const {
  database: databaseConfig,
  redis: redisConfig,
  cache: cacheConfig,
  security: securityConfig,
  app: appConfig,
  logging: loggingConfig,
  email: emailConfig,
  sms: smsConfig,
  upload: uploadConfig,
  external: externalConfig,
  features: featureFlags,
  business: businessConfig,
} = config;

// Default export
export default config;
