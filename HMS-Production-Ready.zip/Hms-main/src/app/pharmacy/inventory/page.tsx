"use client";
export const dynamic = 'force-dynamic';

import React from "react";

// Placeholder component for the Pharmacy Inventory page
const PharmacyInventoryPage = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Pharmacy Inventory</h1>
      <p>
        Pharmacy inventory management content goes here. This section is under
        development.
      </p>
      {/* TODO: Implement Pharmacy Inventory features (Stock, Billing, Expiry, etc.) */}
    </div>
  );
};

export default PharmacyInventoryPage;
