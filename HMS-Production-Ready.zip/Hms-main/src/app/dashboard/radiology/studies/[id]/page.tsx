"use client";
export const dynamic = 'force-dynamic';

import React from "react";
import RadiologyStudyDetail from "@/components/radiology/radiology-study-detail";

export default function StudyDetailPage() {
  return <RadiologyStudyDetail />;
}
