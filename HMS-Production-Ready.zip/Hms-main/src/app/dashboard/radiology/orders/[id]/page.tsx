"use client";
export const dynamic = 'force-dynamic';

import React from "react";
import RadiologyOrderDetail from "@/components/radiology/radiology-order-detail";

export default function OrderDetailPage() {
  return <RadiologyOrderDetail />;
}
