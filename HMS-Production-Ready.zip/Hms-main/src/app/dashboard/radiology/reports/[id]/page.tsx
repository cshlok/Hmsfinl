"use client";
export const dynamic = 'force-dynamic';

import React from "react";
import RadiologyReportDetail from "@/components/radiology/radiology-report-detail";

export default function ReportDetailPage() {
  return <RadiologyReportDetail />;
}
