"use client";
export const dynamic = 'force-dynamic';

import React from "react";

// Placeholder component for the Laboratory page
const LaboratoryPage = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Laboratory Management</h1>
      <p>
        Laboratory module content goes here. This section is under development.
      </p>
      {/* TODO: Implement Laboratory features (Test Booking, Barcode Tracking, Report Uploading) */}
    </div>
  );
};

export default LaboratoryPage;
