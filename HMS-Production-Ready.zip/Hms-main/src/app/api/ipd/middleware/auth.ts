/**
 * IPD (Inpatient Department) Authentication Middleware
 * Provides authentication and authorization for IPD-specific API routes
 */

import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser, checkUserRole } from '@/lib/auth'
import logger from '@/lib/logger'

// IPD-specific roles and permissions
export const IPD_ROLES = {
  IPD_DOCTOR: 'ipd_doctor',
  IPD_NURSE: 'ipd_nurse',
  IPD_ADMIN: 'ipd_admin',
  IPD_PHARMACIST: 'ipd_pharmacist',
  IPD_LAB_TECH: 'ipd_lab_tech',
  WARD_MANAGER: 'ward_manager'
} as const

export const IPD_PERMISSIONS = {
  VIEW_IPD_PATIENTS: 'ipd:patients:view',
  EDIT_IPD_PATIENTS: 'ipd:patients:edit',
  VIEW_MEDICATIONS: 'ipd:medications:view',
  PRESCRIBE_MEDICATIONS: 'ipd:medications:prescribe',
  VIEW_LAB_RESULTS: 'ipd:lab:view',
  ORDER_LAB_TESTS: 'ipd:lab:order',
  DISCHARGE_PATIENTS: 'ipd:patients:discharge',
  MANAGE_WARD: 'ipd:ward:manage'
} as const

// Role-permission mapping
const rolePermissions: Record<string, string[]> = {
  [IPD_ROLES.IPD_DOCTOR]: [
    IPD_PERMISSIONS.VIEW_IPD_PATIENTS,
    IPD_PERMISSIONS.EDIT_IPD_PATIENTS,
    IPD_PERMISSIONS.VIEW_MEDICATIONS,
    IPD_PERMISSIONS.PRESCRIBE_MEDICATIONS,
    IPD_PERMISSIONS.VIEW_LAB_RESULTS,
    IPD_PERMISSIONS.ORDER_LAB_TESTS,
    IPD_PERMISSIONS.DISCHARGE_PATIENTS
  ],
  [IPD_ROLES.IPD_NURSE]: [
    IPD_PERMISSIONS.VIEW_IPD_PATIENTS,
    IPD_PERMISSIONS.EDIT_IPD_PATIENTS,
    IPD_PERMISSIONS.VIEW_MEDICATIONS,
    IPD_PERMISSIONS.VIEW_LAB_RESULTS
  ],
  [IPD_ROLES.IPD_ADMIN]: [
    IPD_PERMISSIONS.VIEW_IPD_PATIENTS,
    IPD_PERMISSIONS.EDIT_IPD_PATIENTS,
    IPD_PERMISSIONS.MANAGE_WARD
  ],
  [IPD_ROLES.IPD_PHARMACIST]: [
    IPD_PERMISSIONS.VIEW_IPD_PATIENTS,
    IPD_PERMISSIONS.VIEW_MEDICATIONS,
    IPD_PERMISSIONS.PRESCRIBE_MEDICATIONS
  ],
  [IPD_ROLES.IPD_LAB_TECH]: [
    IPD_PERMISSIONS.VIEW_LAB_RESULTS,
    IPD_PERMISSIONS.ORDER_LAB_TESTS
  ],
  [IPD_ROLES.WARD_MANAGER]: [
    IPD_PERMISSIONS.VIEW_IPD_PATIENTS,
    IPD_PERMISSIONS.EDIT_IPD_PATIENTS,
    IPD_PERMISSIONS.MANAGE_WARD
  ]
}

/**
 * Check if user has required IPD permissions
 */
const hasIpdPermission = (userRoles: string[], requiredPermissions: string[]): boolean => {
  const userPermissions = userRoles.flatMap(role => rolePermissions[role] || [])
  return requiredPermissions.every(permission => userPermissions.includes(permission))
}

/**
 * IPD Authentication middleware
 */
export const ipdMiddleware = (requiredRoles?: string[], requiredPermissions?: string[]) => {
  return async (request: NextRequest): Promise<NextResponse | null> => {
    try {
      // Get current authenticated user
      const user = await getCurrentUser(request)
      
      if (!user) {
        logger.warn('IPD API access attempt without authentication', {
          request: {
            method: request.method,
            url: request.nextUrl.pathname,
            ip: request.headers.get('x-forwarded-for') || 'unknown'
          }
        })
        
        return NextResponse.json(
          {
            error: {
              code: 'AUTHENTICATION_REQUIRED',
              message: 'Authentication required for IPD services'
            }
          },
          { status: 401 }
        )
      }

      // Check if user has required roles
      if (requiredRoles && requiredRoles.length > 0) {
        const hasRole = await checkUserRole(request, requiredRoles)
        if (!hasRole) {
          logger.warn('IPD API access denied - insufficient role', {
            userId: user.id,
            userRoles: user.roles,
            requiredRoles,
            request: {
              method: request.method,
              url: request.nextUrl.pathname
            }
          })
          
          return NextResponse.json(
            {
              error: {
                code: 'INSUFFICIENT_PERMISSIONS',
                message: 'Insufficient permissions for IPD services'
              }
            },
            { status: 403 }
          )
        }
      }

      // Check if user has required permissions
      if (requiredPermissions && requiredPermissions.length > 0) {
        const hasPermission = hasIpdPermission(user.roles, requiredPermissions)
        if (!hasPermission) {
          logger.warn('IPD API access denied - insufficient permissions', {
            userId: user.id,
            userRoles: user.roles,
            requiredPermissions,
            request: {
              method: request.method,
              url: request.nextUrl.pathname
            }
          })
          
          return NextResponse.json(
            {
              error: {
                code: 'INSUFFICIENT_PERMISSIONS',
                message: 'Insufficient permissions for this IPD operation'
              }
            },
            { status: 403 }
          )
        }
      }

      // Log successful access for audit
      logger.auditPatientAccess(
        user.id,
        'ipd_service',
        'IPD API access',
        {
          endpoint: request.nextUrl.pathname,
          method: request.method
        }
      )

      // Authorization successful - continue
      return null
    } catch (error) {
      logger.error('IPD middleware error', error as Error, {
        request: {
          method: request.method,
          url: request.nextUrl.pathname
        }
      })
      
      return NextResponse.json(
        {
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Authentication service error'
          }
        },
        { status: 500 }
      )
    }
  }
}

/**
 * Specific middleware functions for different IPD operations
 */

// Laboratory integration middleware
export const laboratoryMiddleware = ipdMiddleware(
  [IPD_ROLES.IPD_DOCTOR, IPD_ROLES.IPD_NURSE, IPD_ROLES.IPD_LAB_TECH],
  [IPD_PERMISSIONS.VIEW_LAB_RESULTS]
)

// Pharmacy integration middleware
export const pharmacyMiddleware = ipdMiddleware(
  [IPD_ROLES.IPD_DOCTOR, IPD_ROLES.IPD_NURSE, IPD_ROLES.IPD_PHARMACIST],
  [IPD_PERMISSIONS.VIEW_MEDICATIONS]
)

// Patient management middleware
export const patientManagementMiddleware = ipdMiddleware(
  [IPD_ROLES.IPD_DOCTOR, IPD_ROLES.IPD_NURSE, IPD_ROLES.WARD_MANAGER],
  [IPD_PERMISSIONS.VIEW_IPD_PATIENTS]
)

// Ward management middleware
export const wardManagementMiddleware = ipdMiddleware(
  [IPD_ROLES.WARD_MANAGER, IPD_ROLES.IPD_ADMIN],
  [IPD_PERMISSIONS.MANAGE_WARD]
)

// Prescription middleware
export const prescriptionMiddleware = ipdMiddleware(
  [IPD_ROLES.IPD_DOCTOR, IPD_ROLES.IPD_PHARMACIST],
  [IPD_PERMISSIONS.PRESCRIBE_MEDICATIONS]
)

// Discharge middleware
export const dischargeMiddleware = ipdMiddleware(
  [IPD_ROLES.IPD_DOCTOR],
  [IPD_PERMISSIONS.DISCHARGE_PATIENTS]
)

// Export all middleware functions
export default {
  ipdMiddleware,
  laboratoryMiddleware,
  pharmacyMiddleware,
  patientManagementMiddleware,
  wardManagementMiddleware,
  prescriptionMiddleware,
  dischargeMiddleware,
  IPD_ROLES,
  IPD_PERMISSIONS
}
