/**
 * FHIR Mappers Module
 * Converts internal domain models to/from FHIR R4 format
 * Ensures interoperability with external healthcare systems
 */

import type {
  MedicationAdministration,
  MedicationDispensing,
  DrugInteraction,
  LabOrder,
  LabResult,
  Appointment,
  PatientVitals
} from './domain-models';

// FHIR R4 Resource Types
export interface FHIRResource {
  resourceType: string;
  id?: string;
  meta?: {
    versionId?: string;
    lastUpdated?: string;
    profile?: string[];
  };
  identifier?: Array<{
    use?: string;
    type?: {
      coding?: Array<{
        system?: string;
        code?: string;
        display?: string;
      }>;
    };
    system?: string;
    value?: string;
  }>;
}

export interface FHIRMedicationAdministration extends FHIRResource {
  resourceType: 'MedicationAdministration';
  status: 'in-progress' | 'not-done' | 'on-hold' | 'completed' | 'entered-in-error' | 'stopped' | 'unknown';
  medicationReference?: {
    reference: string;
    display?: string;
  };
  subject: {
    reference: string;
    display?: string;
  };
  performer?: Array<{
    actor: {
      reference: string;
      display?: string;
    };
  }>;
  effectiveDateTime?: string;
  dosage?: {
    text?: string;
    route?: {
      coding?: Array<{
        system?: string;
        code?: string;
        display?: string;
      }>;
    };
    dose?: {
      value?: number;
      unit?: string;
      system?: string;
      code?: string;
    };
  };
  note?: Array<{
    text: string;
    time?: string;
    authorReference?: {
      reference: string;
    };
  }>;
}

export interface FHIRMedicationDispense extends FHIRResource {
  resourceType: 'MedicationDispense';
  status: 'preparation' | 'in-progress' | 'cancelled' | 'on-hold' | 'completed' | 'entered-in-error' | 'stopped' | 'declined' | 'unknown';
  medicationReference?: {
    reference: string;
    display?: string;
  };
  subject: {
    reference: string;
    display?: string;
  };
  performer?: Array<{
    actor: {
      reference: string;
      display?: string;
    };
  }>;
  authorizingPrescription?: Array<{
    reference: string;
  }>;
  quantity?: {
    value: number;
    unit?: string;
    system?: string;
    code?: string;
  };
  whenPrepared?: string;
  whenHandedOver?: string;
  dosageInstruction?: Array<{
    text?: string;
    timing?: {
      repeat?: {
        frequency?: number;
        period?: number;
        periodUnit?: string;
      };
    };
    route?: {
      coding?: Array<{
        system?: string;
        code?: string;
        display?: string;
      }>;
    };
    doseAndRate?: Array<{
      doseQuantity?: {
        value?: number;
        unit?: string;
        system?: string;
        code?: string;
      };
    }>;
  }>;
}

export interface FHIRObservation extends FHIRResource {
  resourceType: 'Observation';
  status: 'registered' | 'preliminary' | 'final' | 'amended' | 'corrected' | 'cancelled' | 'entered-in-error' | 'unknown';
  category?: Array<{
    coding?: Array<{
      system?: string;
      code?: string;
      display?: string;
    }>;
  }>;
  code: {
    coding?: Array<{
      system?: string;
      code?: string;
      display?: string;
    }>;
    text?: string;
  };
  subject: {
    reference: string;
    display?: string;
  };
  effectiveDateTime?: string;
  valueQuantity?: {
    value: number;
    unit?: string;
    system?: string;
    code?: string;
  };
  valueString?: string;
  valueCodeableConcept?: {
    coding?: Array<{
      system?: string;
      code?: string;
      display?: string;
    }>;
    text?: string;
  };
  interpretation?: Array<{
    coding?: Array<{
      system?: string;
      code?: string;
      display?: string;
    }>;
  }>;
  referenceRange?: Array<{
    low?: {
      value?: number;
      unit?: string;
    };
    high?: {
      value?: number;
      unit?: string;
    };
    text?: string;
  }>;
  performer?: Array<{
    reference: string;
    display?: string;
  }>;
}

export interface FHIRServiceRequest extends FHIRResource {
  resourceType: 'ServiceRequest';
  status: 'draft' | 'active' | 'on-hold' | 'revoked' | 'completed' | 'entered-in-error' | 'unknown';
  intent: 'proposal' | 'plan' | 'directive' | 'order' | 'original-order' | 'reflex-order' | 'filler-order' | 'instance-order' | 'option';
  priority?: 'routine' | 'urgent' | 'asap' | 'stat';
  code?: {
    coding?: Array<{
      system?: string;
      code?: string;
      display?: string;
    }>;
    text?: string;
  };
  subject: {
    reference: string;
    display?: string;
  };
  requester?: {
    reference: string;
    display?: string;
  };
  performer?: Array<{
    reference: string;
    display?: string;
  }>;
  authoredOn?: string;
  occurrenceDateTime?: string;
  note?: Array<{
    text: string;
  }>;
}

export interface FHIRAppointment extends FHIRResource {
  resourceType: 'Appointment';
  status: 'proposed' | 'pending' | 'booked' | 'arrived' | 'fulfilled' | 'cancelled' | 'noshow' | 'entered-in-error' | 'checked-in' | 'waitlist';
  serviceCategory?: Array<{
    coding?: Array<{
      system?: string;
      code?: string;
      display?: string;
    }>;
  }>;
  serviceType?: Array<{
    coding?: Array<{
      system?: string;
      code?: string;
      display?: string;
    }>;
  }>;
  priority?: number;
  description?: string;
  start?: string;
  end?: string;
  minutesDuration?: number;
  created?: string;
  comment?: string;
  participant: Array<{
    type?: Array<{
      coding?: Array<{
        system?: string;
        code?: string;
        display?: string;
      }>;
    }>;
    actor?: {
      reference: string;
      display?: string;
    };
    required?: 'required' | 'optional' | 'information-only';
    status: 'accepted' | 'declined' | 'tentative' | 'needs-action';
  }>;
}

// Mapper functions from domain models to FHIR

export function mapMedicationAdministrationToFHIR(admin: MedicationAdministration): FHIRMedicationAdministration {
  const statusMap: Record<string, FHIRMedicationAdministration['status']> = {
    'scheduled': 'in-progress',
    'administered': 'completed',
    'missed': 'not-done',
    'refused': 'not-done',
    'held': 'on-hold'
  };

  return {
    resourceType: 'MedicationAdministration',
    id: admin.id,
    meta: {
      lastUpdated: admin.updatedAt.toISOString(),
      profile: ['http://hl7.org/fhir/StructureDefinition/MedicationAdministration']
    },
    identifier: [{
      use: 'usual',
      system: 'http://hospital.local/medication-administration',
      value: admin.id
    }],
    status: statusMap[admin.status] || 'unknown',
    medicationReference: {
      reference: `Medication/${admin.medicationId}`
    },
    subject: {
      reference: `Patient/${admin.patientId}`
    },
    performer: [{
      actor: {
        reference: `Practitioner/${admin.administeredBy}`
      }
    }],
    effectiveDateTime: admin.administeredAt.toISOString(),
    dosage: {
      text: admin.dosageGiven,
      route: {
        coding: [{
          system: 'http://snomed.info/sct',
          code: getRouteCode(admin.route),
          display: admin.route
        }]
      }
    },
    note: admin.notes ? [{
      text: admin.notes,
      time: admin.updatedAt.toISOString()
    }] : undefined
  };
}

export function mapMedicationDispensingToFHIR(dispensing: MedicationDispensing): FHIRMedicationDispense {
  const statusMap: Record<string, FHIRMedicationDispense['status']> = {
    'pending': 'preparation',
    'dispensed': 'completed',
    'verified': 'completed',
    'cancelled': 'cancelled'
  };

  return {
    resourceType: 'MedicationDispense',
    id: dispensing.id,
    meta: {
      lastUpdated: dispensing.updatedAt.toISOString(),
      profile: ['http://hl7.org/fhir/StructureDefinition/MedicationDispense']
    },
    identifier: [{
      use: 'usual',
      system: 'http://hospital.local/medication-dispense',
      value: dispensing.id
    }],
    status: statusMap[dispensing.status] || 'unknown',
    medicationReference: {
      reference: `Medication/${dispensing.medicationId}`
    },
    subject: {
      reference: `Patient/${dispensing.patientId}`
    },
    performer: [{
      actor: {
        reference: `Practitioner/${dispensing.dispensedBy}`
      }
    }],
    authorizingPrescription: [{
      reference: `MedicationRequest/${dispensing.prescriptionId}`
    }],
    quantity: {
      value: dispensing.quantityDispensed,
      unit: 'tablet',
      system: 'http://unitsofmeasure.org',
      code: '{tablet}'
    },
    whenPrepared: dispensing.dispensedAt.toISOString(),
    whenHandedOver: dispensing.dispensedAt.toISOString()
  };
}

export function mapLabResultToFHIR(result: LabResult): FHIRObservation {
  const statusMap: Record<string, FHIRObservation['status']> = {
    'pending': 'registered',
    'normal': 'final',
    'abnormal': 'final',
    'critical': 'final'
  };

  const interpretationMap: Record<string, string> = {
    'normal': 'N',
    'abnormal': 'A',
    'critical': 'AA'
  };

  return {
    resourceType: 'Observation',
    id: result.id,
    meta: {
      lastUpdated: result.updatedAt.toISOString(),
      profile: ['http://hl7.org/fhir/StructureDefinition/Observation']
    },
    identifier: [{
      use: 'usual',
      system: 'http://hospital.local/lab-result',
      value: result.id
    }],
    status: statusMap[result.status] || 'unknown',
    category: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/observation-category',
        code: 'laboratory',
        display: 'Laboratory'
      }]
    }],
    code: {
      coding: [{
        system: 'http://loinc.org',
        code: result.testCode || 'unknown',
        display: result.testName
      }],
      text: result.testName
    },
    subject: {
      reference: `Patient/${result.patientId}`
    },
    effectiveDateTime: result.collectedAt?.toISOString() || result.orderedAt.toISOString(),
    valueString: result.value,
    interpretation: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation',
        code: interpretationMap[result.status] || 'N'
      }]
    }],
    referenceRange: result.referenceRange ? [{
      text: result.referenceRange
    }] : undefined,
    performer: result.performedBy ? [{
      reference: `Practitioner/${result.performedBy}`
    }] : undefined
  };
}

export function mapLabOrderToFHIR(order: LabOrder): FHIRServiceRequest {
  const statusMap: Record<string, FHIRServiceRequest['status']> = {
    'pending': 'active',
    'collected': 'active',
    'processing': 'active',
    'completed': 'completed',
    'cancelled': 'revoked'
  };

  const priorityMap: Record<string, FHIRServiceRequest['priority']> = {
    'routine': 'routine',
    'urgent': 'urgent',
    'stat': 'stat'
  };

  return {
    resourceType: 'ServiceRequest',
    id: order.id,
    meta: {
      lastUpdated: order.updatedAt.toISOString(),
      profile: ['http://hl7.org/fhir/StructureDefinition/ServiceRequest']
    },
    identifier: [{
      use: 'usual',
      system: 'http://hospital.local/lab-order',
      value: order.id
    }],
    status: statusMap[order.status] || 'unknown',
    intent: 'order',
    priority: priorityMap[order.priority] || 'routine',
    code: {
      coding: [{
        system: 'http://loinc.org',
        code: 'lab-panel',
        display: 'Laboratory Panel'
      }],
      text: `Laboratory tests: ${order.testIds.length} tests`
    },
    subject: {
      reference: `Patient/${order.patientId}`
    },
    requester: {
      reference: `Practitioner/${order.orderedBy}`
    },
    authoredOn: order.orderedAt.toISOString(),
    occurrenceDateTime: order.scheduledAt?.toISOString(),
    note: order.instructions ? [{
      text: order.instructions
    }] : undefined
  };
}

export function mapAppointmentToFHIR(appointment: Appointment): FHIRAppointment {
  const statusMap: Record<string, FHIRAppointment['status']> = {
    'scheduled': 'booked',
    'confirmed': 'booked',
    'in-progress': 'arrived',
    'completed': 'fulfilled',
    'cancelled': 'cancelled',
    'no-show': 'noshow'
  };

  return {
    resourceType: 'Appointment',
    id: appointment.id,
    meta: {
      lastUpdated: appointment.updatedAt.toISOString(),
      profile: ['http://hl7.org/fhir/StructureDefinition/Appointment']
    },
    identifier: [{
      use: 'usual',
      system: 'http://hospital.local/appointment',
      value: appointment.id
    }],
    status: statusMap[appointment.status] || 'booked',
    serviceType: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/service-type',
        code: getServiceTypeCode(appointment.appointmentType),
        display: appointment.appointmentType
      }]
    }],
    priority: getPriorityNumber(appointment.priority),
    description: appointment.reason,
    start: appointment.scheduledAt.toISOString(),
    end: appointment.actualEndTime?.toISOString() || 
          new Date(appointment.scheduledAt.getTime() + appointment.estimatedDuration * 60000).toISOString(),
    minutesDuration: appointment.estimatedDuration,
    created: appointment.createdAt.toISOString(),
    comment: appointment.notes,
    participant: [
      {
        type: [{
          coding: [{
            system: 'http://terminology.hl7.org/CodeSystem/v3-ParticipationType',
            code: 'PPRF',
            display: 'primary performer'
          }]
        }],
        actor: {
          reference: `Practitioner/${appointment.providerId}`
        },
        required: 'required',
        status: 'accepted'
      },
      {
        type: [{
          coding: [{
            system: 'http://terminology.hl7.org/CodeSystem/v3-ParticipationType',
            code: 'SBJ',
            display: 'subject'
          }]
        }],
        actor: {
          reference: `Patient/${appointment.patientId}`
        },
        required: 'required',
        status: statusMap[appointment.status] === 'fulfilled' ? 'accepted' : 'tentative'
      }
    ]
  };
}

export function mapVitalsToFHIR(vitals: PatientVitals): FHIRObservation[] {
  const observations: FHIRObservation[] = [];
  
  const baseObservation = {
    resourceType: 'Observation' as const,
    meta: {
      lastUpdated: vitals.updatedAt.toISOString(),
      profile: ['http://hl7.org/fhir/StructureDefinition/Observation']
    },
    status: 'final' as const,
    category: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/observation-category',
        code: 'vital-signs',
        display: 'Vital Signs'
      }]
    }],
    subject: {
      reference: `Patient/${vitals.patientId}`
    },
    effectiveDateTime: vitals.measuredAt.toISOString(),
    performer: [{
      reference: `Practitioner/${vitals.measuredBy}`
    }]
  };

  // Temperature
  if (vitals.temperature) {
    observations.push({
      ...baseObservation,
      id: `${vitals.id}-temp`,
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '8310-5',
          display: 'Body temperature'
        }]
      },
      valueQuantity: {
        value: vitals.temperature,
        unit: 'Cel',
        system: 'http://unitsofmeasure.org',
        code: 'Cel'
      }
    });
  }

  // Blood Pressure
  if (vitals.bloodPressureSystolic && vitals.bloodPressureDiastolic) {
    observations.push({
      ...baseObservation,
      id: `${vitals.id}-bp`,
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '85354-9',
          display: 'Blood pressure panel with all children optional'
        }]
      },
      component: [
        {
          code: {
            coding: [{
              system: 'http://loinc.org',
              code: '8480-6',
              display: 'Systolic blood pressure'
            }]
          },
          valueQuantity: {
            value: vitals.bloodPressureSystolic,
            unit: 'mmHg',
            system: 'http://unitsofmeasure.org',
            code: 'mm[Hg]'
          }
        },
        {
          code: {
            coding: [{
              system: 'http://loinc.org',
              code: '8462-4',
              display: 'Diastolic blood pressure'
            }]
          },
          valueQuantity: {
            value: vitals.bloodPressureDiastolic,
            unit: 'mmHg',
            system: 'http://unitsofmeasure.org',
            code: 'mm[Hg]'
          }
        }
      ]
    });
  }

  // Heart Rate
  if (vitals.heartRate) {
    observations.push({
      ...baseObservation,
      id: `${vitals.id}-hr`,
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '8867-4',
          display: 'Heart rate'
        }]
      },
      valueQuantity: {
        value: vitals.heartRate,
        unit: '/min',
        system: 'http://unitsofmeasure.org',
        code: '/min'
      }
    });
  }

  return observations;
}

// Helper functions for code mapping

function getRouteCode(route: string): string {
  const routeMap: Record<string, string> = {
    'oral': '26643006',
    'intravenous': '47625008',
    'intramuscular': '78421000',
    'subcutaneous': '34206005',
    'topical': '6064005',
    'inhalation': '447694001'
  };
  return routeMap[route.toLowerCase()] || '26643006'; // Default to oral
}

function getServiceTypeCode(appointmentType: string): string {
  const typeMap: Record<string, string> = {
    'consultation': '11',
    'follow-up': '52',
    'procedure': '165',
    'emergency': '183'
  };
  return typeMap[appointmentType] || '11'; // Default to consultation
}

function getPriorityNumber(priority: string): number {
  const priorityMap: Record<string, number> = {
    'routine': 5,
    'urgent': 3,
    'emergent': 1
  };
  return priorityMap[priority] || 5;
}

// Reverse mappers from FHIR to domain models

export function mapFHIRToMedicationAdministration(fhir: FHIRMedicationAdministration): Partial<MedicationAdministration> {
  const statusMap: Record<string, MedicationAdministration['status']> = {
    'in-progress': 'scheduled',
    'completed': 'administered',
    'not-done': 'missed',
    'on-hold': 'held'
  };

  return {
    id: fhir.id,
    medicationId: fhir.medicationReference?.reference.split('/')[1],
    patientId: fhir.subject.reference.split('/')[1],
    administeredBy: fhir.performer?.[0]?.actor.reference.split('/')[1],
    administeredAt: fhir.effectiveDateTime ? new Date(fhir.effectiveDateTime) : new Date(),
    dosageGiven: fhir.dosage?.text || '',
    route: fhir.dosage?.route?.coding?.[0]?.display || '',
    status: statusMap[fhir.status] || 'administered',
    notes: fhir.note?.[0]?.text
  };
}

export function mapFHIRToLabResult(fhir: FHIRObservation): Partial<LabResult> {
  const statusMap: Record<string, LabResult['status']> = {
    'registered': 'pending',
    'preliminary': 'pending',
    'final': 'normal',
    'amended': 'normal',
    'corrected': 'normal'
  };

  const interpretationMap: Record<string, LabResult['status']> = {
    'N': 'normal',
    'A': 'abnormal',
    'AA': 'critical',
    'H': 'abnormal',
    'L': 'abnormal'
  };

  const interpretation = fhir.interpretation?.[0]?.coding?.[0]?.code;
  const finalStatus = interpretation ? interpretationMap[interpretation] : statusMap[fhir.status];

  return {
    id: fhir.id,
    patientId: fhir.subject.reference.split('/')[1],
    testName: fhir.code.text || fhir.code.coding?.[0]?.display || '',
    testCode: fhir.code.coding?.[0]?.code,
    category: fhir.category?.[0]?.coding?.[0]?.display || 'Laboratory',
    value: fhir.valueString || fhir.valueQuantity?.value?.toString() || '',
    unit: fhir.valueQuantity?.unit,
    referenceRange: fhir.referenceRange?.[0]?.text,
    status: finalStatus || 'pending',
    performedBy: fhir.performer?.[0]?.reference.split('/')[1],
    resultedAt: fhir.effectiveDateTime ? new Date(fhir.effectiveDateTime) : new Date()
  };
}

// Export all mapper functions
export {
  type FHIRResource,
  type FHIRMedicationAdministration,
  type FHIRMedicationDispense,
  type FHIRObservation,
  type FHIRServiceRequest,
  type FHIRAppointment
};
