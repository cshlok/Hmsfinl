/**
 * Domain Models for API Operations
 * Common domain models and types used across API endpoints
 * Includes pharmaceutical, patient, and clinical domain objects
 */

import { z } from 'zod';

// Pharmaceutical Domain Models

export interface MedicationAdministration {
  id: string;
  prescriptionId: string;
  patientId: string;
  medicationId: string;
  administeredBy: string;
  administeredAt: Date;
  dosageGiven: string;
  route: string;
  site?: string;
  status: 'scheduled' | 'administered' | 'missed' | 'refused' | 'held';
  notes?: string;
  verifiedBy?: string;
  verifiedAt?: Date;
  barcodeScanned?: boolean;
  witnessedBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface MedicationDispensing {
  id: string;
  prescriptionId: string;
  medicationId: string;
  patientId: string;
  quantityDispensed: number;
  dispensedBy: string;
  dispensedAt: Date;
  lotNumber?: string;
  expirationDate?: Date;
  verifiedBy?: string;
  verifiedAt?: Date;
  status: 'pending' | 'dispensed' | 'verified' | 'cancelled';
  notes?: string;
  barcodeScanData?: {
    scannedAt: Date;
    scannedBy: string;
    barcodeValue: string;
    verified: boolean;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface DrugInteraction {
  id: string;
  interactionType: 'drug-drug' | 'drug-allergy' | 'drug-condition' | 'drug-lab';
  severity: 'minor' | 'moderate' | 'major' | 'contraindicated';
  medication1Id?: string;
  medication2Id?: string;
  patientId: string;
  description: string;
  recommendation: string;
  source: string;
  isActive: boolean;
  detectedAt: Date;
  overridden?: boolean;
  overriddenBy?: string;
  overriddenAt?: Date;
  overrideReason?: string;
  acknowledgedRisks?: boolean;
}

export interface AdverseReaction {
  id: string;
  patientId: string;
  medicationId: string;
  reactionType: string;
  severity: 'mild' | 'moderate' | 'severe' | 'life-threatening';
  symptoms: string[];
  onsetTime: Date;
  duration?: number; // in hours
  reportedBy: string;
  reportedAt: Date;
  treatmentGiven?: string;
  outcome: 'recovered' | 'recovering' | 'ongoing' | 'fatal' | 'unknown';
  reportNumber?: string;
  fdaReported?: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Patient Domain Models

export interface PatientVitals {
  id: string;
  patientId: string;
  measuredBy: string;
  measuredAt: Date;
  temperature?: number; // Celsius
  bloodPressureSystolic?: number;
  bloodPressureDiastolic?: number;
  heartRate?: number; // bpm
  respiratoryRate?: number; // per minute
  oxygenSaturation?: number; // percentage
  weight?: number; // kg
  height?: number; // cm
  painScale?: number; // 0-10 scale
  glucoseLevel?: number; // mg/dL
  notes?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ClinicalNote {
  id: string;
  patientId: string;
  authorId: string;
  noteType: 'progress' | 'admission' | 'discharge' | 'consultation' | 'nursing' | 'medication';
  title: string;
  content: string;
  isConfidential: boolean;
  status: 'draft' | 'final' | 'amended' | 'corrected';
  createdAt: Date;
  updatedAt: Date;
  amendedBy?: string;
  amendedAt?: Date;
  amendmentReason?: string;
}

// Laboratory Domain Models

export interface LabOrder {
  id: string;
  patientId: string;
  orderedBy: string;
  testIds: string[];
  priority: 'routine' | 'urgent' | 'stat';
  status: 'pending' | 'collected' | 'processing' | 'completed' | 'cancelled';
  orderedAt: Date;
  scheduledAt?: Date;
  collectedAt?: Date;
  completedAt?: Date;
  instructions?: string;
  clinicalInfo?: string;
  fastingRequired?: boolean;
  specimenType: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface LabResult {
  id: string;
  orderId: string;
  patientId: string;
  testId: string;
  testName: string;
  testCode?: string;
  category: string;
  value: string;
  numericValue?: number;
  unit?: string;
  referenceRange?: string;
  status: 'normal' | 'abnormal' | 'critical' | 'pending';
  flags?: string[];
  orderedBy?: string;
  performedBy?: string;
  verifiedBy?: string;
  orderedAt: Date;
  collectedAt?: Date;
  resultedAt?: Date;
  verifiedAt?: Date;
  notes?: string;
  criticalValue?: boolean;
  deltaCheck?: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Billing Domain Models

export interface BillingItem {
  id: string;
  code: string;
  description: string;
  category: 'medication' | 'procedure' | 'consultation' | 'test' | 'room' | 'supply';
  unitPrice: number;
  unit: string;
  taxable: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  patientId: string;
  visitId?: string;
  billingDate: Date;
  dueDate: Date;
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  totalAmount: number;
  paidAmount: number;
  balanceAmount: number;
  paymentTerms?: string;
  notes?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Appointment Domain Models

export interface Appointment {
  id: string;
  patientId: string;
  providerId: string;
  appointmentType: 'consultation' | 'follow-up' | 'procedure' | 'emergency';
  status: 'scheduled' | 'confirmed' | 'in-progress' | 'completed' | 'cancelled' | 'no-show';
  scheduledAt: Date;
  estimatedDuration: number; // in minutes
  actualStartTime?: Date;
  actualEndTime?: Date;
  locationId: string;
  reason: string;
  notes?: string;
  priority: 'routine' | 'urgent' | 'emergent';
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Inventory Domain Models

export interface InventoryAdjustment {
  id: string;
  medicationId: string;
  locationId: string;
  adjustmentType: 'increase' | 'decrease' | 'correction' | 'transfer' | 'waste' | 'return';
  adjustmentQuantity: number;
  reason: string;
  adjustedBy: string;
  adjustedAt: Date;
  referenceNumber?: string;
  previousStock: number;
  newStock: number;
  cost?: number;
  notes?: string;
  approvedBy?: string;
  approvedAt?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface StockAlert {
  id: string;
  medicationId: string;
  locationId: string;
  alertType: 'low_stock' | 'out_of_stock' | 'expired' | 'near_expiry';
  currentStock: number;
  minimumStock: number;
  alertLevel: 'info' | 'warning' | 'critical';
  alertedAt: Date;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: Date;
  resolved: boolean;
  resolvedAt?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Validation Schemas using Zod

export const medicationAdministrationSchema = z.object({
  prescriptionId: z.string().min(1),
  patientId: z.string().min(1),
  medicationId: z.string().min(1),
  administeredBy: z.string().min(1),
  administeredAt: z.date().default(() => new Date()),
  dosageGiven: z.string().min(1),
  route: z.string().min(1),
  site: z.string().optional(),
  status: z.enum(['scheduled', 'administered', 'missed', 'refused', 'held']).default('administered'),
  notes: z.string().optional(),
  barcodeScanned: z.boolean().default(false),
  witnessedBy: z.string().optional()
});

export const drugInteractionSchema = z.object({
  interactionType: z.enum(['drug-drug', 'drug-allergy', 'drug-condition', 'drug-lab']),
  severity: z.enum(['minor', 'moderate', 'major', 'contraindicated']),
  medication1Id: z.string().optional(),
  medication2Id: z.string().optional(),
  patientId: z.string().min(1),
  description: z.string().min(1),
  recommendation: z.string().min(1),
  source: z.string().min(1)
});

export const adverseReactionSchema = z.object({
  patientId: z.string().min(1),
  medicationId: z.string().min(1),
  reactionType: z.string().min(1),
  severity: z.enum(['mild', 'moderate', 'severe', 'life-threatening']),
  symptoms: z.array(z.string()).min(1),
  onsetTime: z.date(),
  duration: z.number().positive().optional(),
  reportedBy: z.string().min(1),
  treatmentGiven: z.string().optional(),
  outcome: z.enum(['recovered', 'recovering', 'ongoing', 'fatal', 'unknown']).default('ongoing')
});

export const labOrderSchema = z.object({
  patientId: z.string().min(1),
  orderedBy: z.string().min(1),
  testIds: z.array(z.string()).min(1),
  priority: z.enum(['routine', 'urgent', 'stat']).default('routine'),
  scheduledAt: z.date().optional(),
  instructions: z.string().optional(),
  clinicalInfo: z.string().optional(),
  fastingRequired: z.boolean().default(false),
  specimenType: z.string().min(1)
});

export const appointmentSchema = z.object({
  patientId: z.string().min(1),
  providerId: z.string().min(1),
  appointmentType: z.enum(['consultation', 'follow-up', 'procedure', 'emergency']),
  scheduledAt: z.date(),
  estimatedDuration: z.number().positive(),
  locationId: z.string().min(1),
  reason: z.string().min(1),
  notes: z.string().optional(),
  priority: z.enum(['routine', 'urgent', 'emergent']).default('routine')
});

// Helper functions for domain operations

export function createMedicationAdministration(data: z.infer<typeof medicationAdministrationSchema>): MedicationAdministration {
  const validated = medicationAdministrationSchema.parse(data);
  
  return {
    id: `med_admin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    ...validated,
    verifiedBy: undefined,
    verifiedAt: undefined,
    createdAt: new Date(),
    updatedAt: new Date()
  };
}

export function createDrugInteraction(data: z.infer<typeof drugInteractionSchema>): DrugInteraction {
  const validated = drugInteractionSchema.parse(data);
  
  return {
    id: `interaction_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    ...validated,
    isActive: true,
    detectedAt: new Date(),
    overridden: false
  };
}

export function createLabOrder(data: z.infer<typeof labOrderSchema>): LabOrder {
  const validated = labOrderSchema.parse(data);
  
  return {
    id: `lab_order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    ...validated,
    status: 'pending',
    orderedAt: new Date(),
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date()
  };
}

// Status validation functions

export function isValidMedicationStatus(status: string): status is MedicationAdministration['status'] {
  return ['scheduled', 'administered', 'missed', 'refused', 'held'].includes(status);
}

export function isValidInteractionSeverity(severity: string): severity is DrugInteraction['severity'] {
  return ['minor', 'moderate', 'major', 'contraindicated'].includes(severity);
}

export function isValidLabStatus(status: string): status is LabResult['status'] {
  return ['normal', 'abnormal', 'critical', 'pending'].includes(status);
}

export function isValidAppointmentStatus(status: string): status is Appointment['status'] {
  return ['scheduled', 'confirmed', 'in-progress', 'completed', 'cancelled', 'no-show'].includes(status);
}

// Schemas are already exported above, no need to re-export
