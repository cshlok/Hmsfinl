/**
 * Drug Interaction Service
 * Comprehensive service for detecting, managing, and reporting drug interactions
 * Includes clinical decision support and safety alerts
 */

import { prisma } from '@/lib/prisma';
import { auditLog } from '@/lib/audit';
import { logger } from '@/lib/logger';
import { getMedicationById, checkDrugInteractions } from '@/lib/services/pharmacy/pharmacy.service';
import { getPatientById, getPatientAllergies, getPatientConditions } from '@/lib/services/patient/patient.service';

// Types for drug interaction operations
export interface DrugInteractionDetails {
  id: string;
  interactionType: 'drug-drug' | 'drug-allergy' | 'drug-condition' | 'drug-lab' | 'drug-food';
  severity: 'minor' | 'moderate' | 'major' | 'contraindicated';
  medication1Id?: string;
  medication2Id?: string;
  patientId: string;
  description: string;
  clinicalConsequence: string;
  mechanism: string;
  recommendation: string;
  alternatives?: string[];
  monitoring?: string;
  source: string;
  evidenceLevel: 'A' | 'B' | 'C' | 'D'; // Clinical evidence grading
  isActive: boolean;
  detectedAt: Date;
  overridden?: boolean;
  overriddenBy?: string;
  overriddenAt?: Date;
  overrideReason?: string;
  acknowledgedRisks?: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface InteractionCheckResult {
  hasInteractions: boolean;
  interactions: DrugInteractionDetails[];
  riskLevel: 'low' | 'moderate' | 'high' | 'critical';
  requiresIntervention: boolean;
  criticalAlerts: string[];
  warnings: string[];
  recommendations: string[];
  checkId: string;
  checkedAt: Date;
  checkedBy?: string;
}

export interface BatchInteractionCheck {
  patientId: string;
  medications: string[];
  newMedication?: string;
  results: InteractionCheckResult;
  summary: {
    totalInteractions: number;
    criticalCount: number;
    majorCount: number;
    moderateCount: number;
    minorCount: number;
  };
}

/**
 * Drug Interaction Service Class
 */
export class DrugInteractionService {

  /**
   * Check interactions for a single medication against patient's current medications
   */
  static async checkSingleMedication(
    patientId: string,
    newMedicationId: string,
    userId?: string
  ): Promise<InteractionCheckResult> {
    try {
      logger.info(`Checking single medication interactions`, { patientId, newMedicationId, userId });

      const checkId = `single_check_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Get patient's current active medications
      const currentPrescriptions = await prisma.prescription.findMany({
        where: {
          patientId,
          isActive: true,
          status: 'active'
        },
        include: {
          medication: true
        }
      });

      const currentMedicationIds = currentPrescriptions.map(p => p.medicationId);
      
      // Check drug-drug interactions
      const drugDrugInteractions = await this.checkDrugDrugInteractions(
        newMedicationId,
        currentMedicationIds,
        patientId,
        userId
      );

      // Check drug-allergy interactions
      const drugAllergyInteractions = await this.checkDrugAllergyInteractions(
        newMedicationId,
        patientId,
        userId
      );

      // Check drug-condition interactions
      const drugConditionInteractions = await this.checkDrugConditionInteractions(
        newMedicationId,
        patientId,
        userId
      );

      // Combine all interactions
      const allInteractions = [
        ...drugDrugInteractions,
        ...drugAllergyInteractions,
        ...drugConditionInteractions
      ];

      // Analyze risk level and recommendations
      const analysis = this.analyzeInteractionRisk(allInteractions);

      const result: InteractionCheckResult = {
        hasInteractions: allInteractions.length > 0,
        interactions: allInteractions,
        riskLevel: analysis.riskLevel,
        requiresIntervention: analysis.requiresIntervention,
        criticalAlerts: analysis.criticalAlerts,
        warnings: analysis.warnings,
        recommendations: analysis.recommendations,
        checkId,
        checkedAt: new Date(),
        checkedBy: userId
      };

      // Store interaction check result
      await this.storeInteractionCheck(checkId, patientId, [newMedicationId], result, userId);

      // Audit log
      await auditLog({
        userId: userId || 'system',
        action: 'CHECK_SINGLE_MEDICATION_INTERACTIONS',
        resourceType: 'DrugInteraction',
        resourceId: checkId,
        details: {
          patientId,
          newMedicationId,
          interactionCount: allInteractions.length,
          riskLevel: analysis.riskLevel,
          requiresIntervention: analysis.requiresIntervention
        }
      });

      return result;

    } catch (error) {
      logger.error('Error checking single medication interactions:', error, { patientId, newMedicationId, userId });
      throw new Error('Failed to check medication interactions');
    }
  }

  /**
   * Check interactions for multiple medications (batch check)
   */
  static async checkBatchMedications(
    patientId: string,
    medicationIds: string[],
    newMedicationId?: string,
    userId?: string
  ): Promise<BatchInteractionCheck> {
    try {
      logger.info(`Checking batch medication interactions`, { 
        patientId, 
        medicationCount: medicationIds.length, 
        newMedicationId, 
        userId 
      });

      const allMedications = newMedicationId ? [...medicationIds, newMedicationId] : medicationIds;
      const interactions: DrugInteractionDetails[] = [];

      // Check all possible drug-drug combinations
      for (let i = 0; i < allMedications.length; i++) {
        for (let j = i + 1; j < allMedications.length; j++) {
          const pairInteractions = await this.checkDrugDrugInteractions(
            allMedications[i],
            [allMedications[j]],
            patientId,
            userId
          );
          interactions.push(...pairInteractions);
        }
      }

      // Check drug-allergy interactions for all medications
      for (const medicationId of allMedications) {
        const allergyInteractions = await this.checkDrugAllergyInteractions(
          medicationId,
          patientId,
          userId
        );
        interactions.push(...allergyInteractions);
      }

      // Check drug-condition interactions for all medications
      for (const medicationId of allMedications) {
        const conditionInteractions = await this.checkDrugConditionInteractions(
          medicationId,
          patientId,
          userId
        );
        interactions.push(...conditionInteractions);
      }

      // Analyze combined risk
      const analysis = this.analyzeInteractionRisk(interactions);

      const results: InteractionCheckResult = {
        hasInteractions: interactions.length > 0,
        interactions,
        riskLevel: analysis.riskLevel,
        requiresIntervention: analysis.requiresIntervention,
        criticalAlerts: analysis.criticalAlerts,
        warnings: analysis.warnings,
        recommendations: analysis.recommendations,
        checkId: `batch_check_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        checkedAt: new Date(),
        checkedBy: userId
      };

      // Calculate summary
      const summary = {
        totalInteractions: interactions.length,
        criticalCount: interactions.filter(i => i.severity === 'contraindicated').length,
        majorCount: interactions.filter(i => i.severity === 'major').length,
        moderateCount: interactions.filter(i => i.severity === 'moderate').length,
        minorCount: interactions.filter(i => i.severity === 'minor').length
      };

      const batchResult: BatchInteractionCheck = {
        patientId,
        medications: allMedications,
        newMedication: newMedicationId,
        results,
        summary
      };

      // Store batch check result
      await this.storeInteractionCheck(results.checkId, patientId, allMedications, results, userId);

      // Audit log
      await auditLog({
        userId: userId || 'system',
        action: 'CHECK_BATCH_MEDICATION_INTERACTIONS',
        resourceType: 'DrugInteraction',
        resourceId: results.checkId,
        details: {
          patientId,
          medicationCount: allMedications.length,
          interactionCount: interactions.length,
          summary,
          riskLevel: analysis.riskLevel
        }
      });

      return batchResult;

    } catch (error) {
      logger.error('Error checking batch medication interactions:', error, { patientId, medicationIds, userId });
      throw new Error('Failed to check batch medication interactions');
    }
  }

  /**
   * Override an interaction with justification
   */
  static async overrideInteraction(
    interactionId: string,
    overrideData: {
      overriddenBy: string;
      overrideReason: string;
      acknowledgedRisks: boolean;
      alternativeConsidered?: boolean;
      monitoringPlan?: string;
    },
    userId: string
  ): Promise<DrugInteractionDetails> {
    try {
      logger.info(`Overriding drug interaction`, { interactionId, overrideData, userId });

      // Validate override authority
      const canOverride = await this.validateOverrideAuthority(overrideData.overriddenBy, userId);
      if (!canOverride) {
        throw new Error('Insufficient authority to override interaction');
      }

      // Update interaction with override information
      const updatedInteraction = await prisma.drugInteraction.update({
        where: { id: interactionId },
        data: {
          overridden: true,
          overriddenBy: overrideData.overriddenBy,
          overriddenAt: new Date(),
          overrideReason: overrideData.overrideReason,
          acknowledgedRisks: overrideData.acknowledgedRisks,
          monitoringPlan: overrideData.monitoringPlan,
          updatedAt: new Date()
        }
      });

      // Create override audit record
      await prisma.interactionOverride.create({
        data: {
          interactionId,
          overriddenBy: overrideData.overriddenBy,
          overrideReason: overrideData.overrideReason,
          acknowledgedRisks: overrideData.acknowledgedRisks,
          alternativeConsidered: overrideData.alternativeConsidered || false,
          monitoringPlan: overrideData.monitoringPlan,
          overriddenAt: new Date()
        }
      });

      // Audit log
      await auditLog({
        userId,
        action: 'OVERRIDE_DRUG_INTERACTION',
        resourceType: 'DrugInteraction',
        resourceId: interactionId,
        details: {
          overriddenBy: overrideData.overriddenBy,
          overrideReason: overrideData.overrideReason,
          acknowledgedRisks: overrideData.acknowledgedRisks,
          severity: updatedInteraction.severity
        }
      });

      return this.mapToDrugInteractionDetails(updatedInteraction);

    } catch (error) {
      logger.error('Error overriding drug interaction:', error, { interactionId, overrideData, userId });
      throw new Error('Failed to override drug interaction');
    }
  }

  /**
   * Get interaction history for a patient
   */
  static async getPatientInteractionHistory(
    patientId: string,
    options?: {
      limit?: number;
      includeOverridden?: boolean;
      severityFilter?: string[];
    },
    userId?: string
  ): Promise<DrugInteractionDetails[]> {
    try {
      logger.info(`Getting patient interaction history`, { patientId, options, userId });

      const whereClause: any = {
        patientId,
        isActive: true
      };

      if (!options?.includeOverridden) {
        whereClause.overridden = false;
      }

      if (options?.severityFilter && options.severityFilter.length > 0) {
        whereClause.severity = { in: options.severityFilter };
      }

      const interactions = await prisma.drugInteraction.findMany({
        where: whereClause,
        orderBy: { detectedAt: 'desc' },
        take: options?.limit || 100
      });

      // Audit log
      await auditLog({
        userId: userId || 'system',
        action: 'VIEW_PATIENT_INTERACTION_HISTORY',
        resourceType: 'DrugInteraction',
        resourceId: patientId,
        details: {
          patientId,
          interactionCount: interactions.length,
          filters: options
        }
      });

      return interactions.map(this.mapToDrugInteractionDetails);

    } catch (error) {
      logger.error('Error getting patient interaction history:', error, { patientId, options, userId });
      throw new Error('Failed to get patient interaction history');
    }
  }

  // Private helper methods

  private static async checkDrugDrugInteractions(
    medicationId: string,
    otherMedicationIds: string[],
    patientId: string,
    userId?: string
  ): Promise<DrugInteractionDetails[]> {
    const interactions: DrugInteractionDetails[] = [];

    // Check against known interaction database
    for (const otherMedId of otherMedicationIds) {
      const interaction = await prisma.knownDrugInteraction.findFirst({
        where: {
          OR: [
            { medication1Id: medicationId, medication2Id: otherMedId },
            { medication1Id: otherMedId, medication2Id: medicationId }
          ],
          isActive: true
        }
      });

      if (interaction) {
        const detectedInteraction: DrugInteractionDetails = {
          id: `detected_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          interactionType: 'drug-drug',
          severity: interaction.severity as 'minor' | 'moderate' | 'major' | 'contraindicated',
          medication1Id: medicationId,
          medication2Id: otherMedId,
          patientId,
          description: interaction.description,
          clinicalConsequence: interaction.clinicalConsequence || '',
          mechanism: interaction.mechanism || '',
          recommendation: interaction.recommendation,
          alternatives: interaction.alternatives || [],
          monitoring: interaction.monitoring,
          source: interaction.source || 'Internal Database',
          evidenceLevel: interaction.evidenceLevel as 'A' | 'B' | 'C' | 'D',
          isActive: true,
          detectedAt: new Date(),
          createdAt: new Date(),
          updatedAt: new Date()
        };

        interactions.push(detectedInteraction);
      }
    }

    return interactions;
  }

  private static async checkDrugAllergyInteractions(
    medicationId: string,
    patientId: string,
    userId?: string
  ): Promise<DrugInteractionDetails[]> {
    const interactions: DrugInteractionDetails[] = [];

    // Get medication details
    const medication = await getMedicationById(medicationId, userId);
    if (!medication) return interactions;

    // Get patient allergies
    const allergies = await getPatientAllergies(patientId, userId);

    // Check for allergy matches
    for (const allergy of allergies) {
      const hasMatch = 
        medication.name.toLowerCase().includes(allergy.allergen.toLowerCase()) ||
        medication.genericName.toLowerCase().includes(allergy.allergen.toLowerCase()) ||
        medication.activeIngredients?.some(ingredient => 
          ingredient.toLowerCase().includes(allergy.allergen.toLowerCase())
        );

      if (hasMatch) {
        const interaction: DrugInteractionDetails = {
          id: `allergy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          interactionType: 'drug-allergy',
          severity: this.mapAllergySeverityToInteractionSeverity(allergy.severity),
          medication1Id: medicationId,
          patientId,
          description: `Patient has documented allergy to ${allergy.allergen}`,
          clinicalConsequence: `Potential allergic reaction: ${allergy.reactions.join(', ')}`,
          mechanism: 'Allergic reaction',
          recommendation: 'Consider alternative medication',
          source: 'Patient Allergy Record',
          evidenceLevel: 'A',
          isActive: true,
          detectedAt: new Date(),
          createdAt: new Date(),
          updatedAt: new Date()
        };

        interactions.push(interaction);
      }
    }

    return interactions;
  }

  private static async checkDrugConditionInteractions(
    medicationId: string,
    patientId: string,
    userId?: string
  ): Promise<DrugInteractionDetails[]> {
    const interactions: DrugInteractionDetails[] = [];

    // Get patient conditions
    const conditions = await getPatientConditions(patientId, userId);

    // Check against contraindication database
    for (const condition of conditions) {
      const contraindication = await prisma.drugConditionContraindication.findFirst({
        where: {
          medicationId,
          conditionName: { contains: condition.condition, mode: 'insensitive' },
          isActive: true
        }
      });

      if (contraindication) {
        const interaction: DrugInteractionDetails = {
          id: `condition_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          interactionType: 'drug-condition',
          severity: contraindication.severity as 'minor' | 'moderate' | 'major' | 'contraindicated',
          medication1Id: medicationId,
          patientId,
          description: contraindication.description,
          clinicalConsequence: contraindication.clinicalConsequence || '',
          mechanism: contraindication.mechanism || '',
          recommendation: contraindication.recommendation,
          source: 'Contraindication Database',
          evidenceLevel: contraindication.evidenceLevel as 'A' | 'B' | 'C' | 'D',
          isActive: true,
          detectedAt: new Date(),
          createdAt: new Date(),
          updatedAt: new Date()
        };

        interactions.push(interaction);
      }
    }

    return interactions;
  }

  private static analyzeInteractionRisk(interactions: DrugInteractionDetails[]): {
    riskLevel: 'low' | 'moderate' | 'high' | 'critical';
    requiresIntervention: boolean;
    criticalAlerts: string[];
    warnings: string[];
    recommendations: string[];
  } {
    const criticalAlerts: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    const contraindicated = interactions.filter(i => i.severity === 'contraindicated');
    const major = interactions.filter(i => i.severity === 'major');
    const moderate = interactions.filter(i => i.severity === 'moderate');

    // Determine risk level
    let riskLevel: 'low' | 'moderate' | 'high' | 'critical';
    let requiresIntervention = false;

    if (contraindicated.length > 0) {
      riskLevel = 'critical';
      requiresIntervention = true;
      criticalAlerts.push(`${contraindicated.length} contraindicated interaction(s) detected`);
    } else if (major.length > 0) {
      riskLevel = 'high';
      requiresIntervention = true;
      warnings.push(`${major.length} major interaction(s) detected`);
    } else if (moderate.length > 0) {
      riskLevel = 'moderate';
      requiresIntervention = moderate.length > 2; // Intervention needed if multiple moderate
      warnings.push(`${moderate.length} moderate interaction(s) detected`);
    } else {
      riskLevel = 'low';
    }

    // Generate recommendations
    interactions.forEach(interaction => {
      if (interaction.recommendation) {
        recommendations.push(interaction.recommendation);
      }
      if (interaction.alternatives && interaction.alternatives.length > 0) {
        recommendations.push(`Consider alternatives: ${interaction.alternatives.join(', ')}`);
      }
      if (interaction.monitoring) {
        recommendations.push(`Monitoring: ${interaction.monitoring}`);
      }
    });

    return {
      riskLevel,
      requiresIntervention,
      criticalAlerts,
      warnings,
      recommendations: [...new Set(recommendations)] // Remove duplicates
    };
  }

  private static async storeInteractionCheck(
    checkId: string,
    patientId: string,
    medicationIds: string[],
    result: InteractionCheckResult,
    userId?: string
  ): Promise<void> {
    await prisma.interactionCheck.create({
      data: {
        id: checkId,
        patientId,
        medicationIds,
        checkedBy: userId || 'system',
        hasInteractions: result.hasInteractions,
        riskLevel: result.riskLevel,
        requiresIntervention: result.requiresIntervention,
        interactionCount: result.interactions.length,
        checkData: JSON.stringify(result),
        checkedAt: result.checkedAt
      }
    });
  }

  private static async validateOverrideAuthority(overriddenBy: string, userId: string): Promise<boolean> {
    // In a real system, check user roles and permissions
    // For now, allow if the user is overriding their own action or has admin role
    return overriddenBy === userId || await this.hasAdminRole(userId);
  }

  private static async hasAdminRole(userId: string): Promise<boolean> {
    // Mock implementation - check user roles
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { roles: true }
    });

    return user?.roles.some(role => 
      role.name === 'admin' || 
      role.name === 'pharmacist' || 
      role.name === 'physician'
    ) || false;
  }

  private static mapAllergySeverityToInteractionSeverity(
    allergySeverity: 'mild' | 'moderate' | 'severe' | 'life-threatening'
  ): 'minor' | 'moderate' | 'major' | 'contraindicated' {
    switch (allergySeverity) {
      case 'mild': return 'minor';
      case 'moderate': return 'moderate';
      case 'severe': return 'major';
      case 'life-threatening': return 'contraindicated';
      default: return 'moderate';
    }
  }

  private static mapToDrugInteractionDetails(interaction: any): DrugInteractionDetails {
    return {
      id: interaction.id,
      interactionType: interaction.interactionType,
      severity: interaction.severity,
      medication1Id: interaction.medication1Id,
      medication2Id: interaction.medication2Id,
      patientId: interaction.patientId,
      description: interaction.description,
      clinicalConsequence: interaction.clinicalConsequence || '',
      mechanism: interaction.mechanism || '',
      recommendation: interaction.recommendation,
      alternatives: interaction.alternatives || [],
      monitoring: interaction.monitoring,
      source: interaction.source,
      evidenceLevel: interaction.evidenceLevel,
      isActive: interaction.isActive,
      detectedAt: interaction.detectedAt,
      overridden: interaction.overridden,
      overriddenBy: interaction.overriddenBy,
      overriddenAt: interaction.overriddenAt,
      overrideReason: interaction.overrideReason,
      acknowledgedRisks: interaction.acknowledgedRisks,
      createdAt: interaction.createdAt,
      updatedAt: interaction.updatedAt
    };
  }
}

// Export types and service
export {
  type DrugInteractionDetails,
  type InteractionCheckResult,
  type BatchInteractionCheck
};
