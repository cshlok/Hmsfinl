/**
 * Barcode Administration Service
 * Handles barcode scanning and verification for medication administration
 * Provides safety checks and audit logging for medication verification
 */

import { prisma } from '@/lib/prisma';
import { auditLog } from '@/lib/audit';
import { logger } from '@/lib/logger';
import { getMedicationById } from '@/lib/services/pharmacy/pharmacy.service';
import { getPatientById } from '@/lib/services/patient/patient.service';

// Types for barcode operations
export interface BarcodeVerificationResult {
  success: boolean;
  medicationId?: string;
  patientId?: string;
  verificationId: string;
  verifiedAt: Date;
  verifiedBy: string;
  verificationContext: 'administration' | 'dispensing' | 'inventory';
  scannedBarcode: string;
  expectedData?: {
    medicationId?: string;
    patientId?: string;
    prescriptionId?: string;
  };
  warnings?: string[];
  errors?: string[];
  confidence: 'high' | 'medium' | 'low';
  metadata?: Record<string, any>;
}

export interface BarcodeAdministrationCheck {
  id: string;
  prescriptionId: string;
  patientId: string;
  medicationId: string;
  scheduledTime: Date;
  administrationWindow: {
    earliest: Date;
    latest: Date;
  };
  barcodeVerifications: Array<{
    type: 'patient' | 'medication' | 'nurse';
    barcode: string;
    verified: boolean;
    scannedAt: Date;
    scannedBy: string;
  }>;
  allVerified: boolean;
  safetyChecks: {
    patientIdentityVerified: boolean;
    medicationVerified: boolean;
    doseVerified: boolean;
    routeVerified: boolean;
    timingVerified: boolean;
    allergyChecked: boolean;
    interactionChecked: boolean;
  };
  administrationReady: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface MedicationBarcodeData {
  ndc: string;
  lotNumber?: string;
  expirationDate?: Date;
  medicationId: string;
  medicationName: string;
  strength: string;
  dosageForm: string;
  manufacturer: string;
}

export interface PatientBarcodeData {
  patientId: string;
  mrn: string;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  wristbandId?: string;
}

/**
 * Verify medication barcode for administration
 */
export async function verifyMedicationBarcode(
  barcode: string,
  expectedMedicationId: string,
  verificationContext: 'administration' | 'dispensing' | 'inventory' = 'administration',
  userId: string
): Promise<BarcodeVerificationResult> {
  try {
    logger.info(`Verifying medication barcode`, { barcode, expectedMedicationId, verificationContext, userId });

    const verificationId = `med_verify_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const warnings: string[] = [];
    const errors: string[] = [];

    // Parse barcode to extract medication information
    const barcodeData = await parseMedicationBarcode(barcode);
    
    if (!barcodeData) {
      return {
        success: false,
        verificationId,
        verifiedAt: new Date(),
        verifiedBy: userId,
        verificationContext,
        scannedBarcode: barcode,
        errors: ['Invalid or unrecognizable medication barcode format'],
        confidence: 'low'
      };
    }

    // Verify against expected medication
    const expectedMedication = await getMedicationById(expectedMedicationId, userId);
    
    if (!expectedMedication) {
      return {
        success: false,
        verificationId,
        verifiedAt: new Date(),
        verifiedBy: userId,
        verificationContext,
        scannedBarcode: barcode,
        errors: ['Expected medication not found in system'],
        confidence: 'low'
      };
    }

    // Check if scanned medication matches expected
    const medicationMatch = barcodeData.medicationId === expectedMedicationId || 
                           barcodeData.ndc === expectedMedication.ndc;

    if (!medicationMatch) {
      errors.push(`Medication mismatch: Expected ${expectedMedication.name}, scanned ${barcodeData.medicationName}`);
    }

    // Check expiration date
    if (barcodeData.expirationDate && barcodeData.expirationDate < new Date()) {
      errors.push('Medication has expired');
    } else if (barcodeData.expirationDate && 
               barcodeData.expirationDate < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)) {
      warnings.push('Medication expires within 30 days');
    }

    // Check lot number for recalls (simplified check)
    if (barcodeData.lotNumber) {
      const isRecalled = await checkMedicationRecall(barcodeData.ndc, barcodeData.lotNumber);
      if (isRecalled) {
        errors.push('Medication lot number is subject to recall');
      }
    }

    const success = errors.length === 0 && medicationMatch;
    const confidence: 'high' | 'medium' | 'low' = 
      success && warnings.length === 0 ? 'high' :
      success && warnings.length > 0 ? 'medium' : 'low';

    // Log the verification
    await auditLog({
      userId,
      action: 'VERIFY_MEDICATION_BARCODE',
      resourceType: 'MedicationVerification',
      resourceId: verificationId,
      details: {
        barcode,
        expectedMedicationId,
        scannedMedicationId: barcodeData.medicationId,
        success,
        confidence,
        warningCount: warnings.length,
        errorCount: errors.length
      }
    });

    return {
      success,
      medicationId: barcodeData.medicationId,
      verificationId,
      verifiedAt: new Date(),
      verifiedBy: userId,
      verificationContext,
      scannedBarcode: barcode,
      expectedData: { medicationId: expectedMedicationId },
      warnings: warnings.length > 0 ? warnings : undefined,
      errors: errors.length > 0 ? errors : undefined,
      confidence,
      metadata: {
        barcodeData,
        expectedMedication: {
          id: expectedMedication.id,
          name: expectedMedication.name,
          ndc: expectedMedication.ndc
        }
      }
    };

  } catch (error) {
    logger.error('Error verifying medication barcode:', error, { barcode, expectedMedicationId, userId });
    throw new Error('Failed to verify medication barcode');
  }
}

/**
 * Verify patient barcode/wristband
 */
export async function verifyPatientBarcode(
  barcode: string,
  expectedPatientId: string,
  userId: string
): Promise<BarcodeVerificationResult> {
  try {
    logger.info(`Verifying patient barcode`, { barcode, expectedPatientId, userId });

    const verificationId = `pat_verify_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const warnings: string[] = [];
    const errors: string[] = [];

    // Parse patient barcode
    const barcodeData = await parsePatientBarcode(barcode);
    
    if (!barcodeData) {
      return {
        success: false,
        verificationId,
        verifiedAt: new Date(),
        verifiedBy: userId,
        verificationContext: 'administration',
        scannedBarcode: barcode,
        errors: ['Invalid or unrecognizable patient barcode format'],
        confidence: 'low'
      };
    }

    // Verify against expected patient
    const expectedPatient = await getPatientById(expectedPatientId, userId);
    
    if (!expectedPatient) {
      return {
        success: false,
        verificationId,
        verifiedAt: new Date(),
        verifiedBy: userId,
        verificationContext: 'administration',
        scannedBarcode: barcode,
        errors: ['Expected patient not found in system'],
        confidence: 'low'
      };
    }

    // Check if scanned patient matches expected
    const patientMatch = barcodeData.patientId === expectedPatientId || 
                        barcodeData.mrn === expectedPatient.mrn;

    if (!patientMatch) {
      errors.push(`Patient mismatch: Expected ${expectedPatient.firstName} ${expectedPatient.lastName} (${expectedPatient.mrn}), scanned ${barcodeData.firstName} ${barcodeData.lastName} (${barcodeData.mrn})`);
    }

    // Additional safety checks
    if (barcodeData.dateOfBirth.getTime() !== expectedPatient.dateOfBirth.getTime()) {
      warnings.push('Date of birth mismatch detected');
    }

    const success = errors.length === 0 && patientMatch;
    const confidence: 'high' | 'medium' | 'low' = 
      success && warnings.length === 0 ? 'high' :
      success && warnings.length > 0 ? 'medium' : 'low';

    // Log the verification
    await auditLog({
      userId,
      action: 'VERIFY_PATIENT_BARCODE',
      resourceType: 'PatientVerification',
      resourceId: verificationId,
      details: {
        barcode,
        expectedPatientId,
        scannedPatientId: barcodeData.patientId,
        success,
        confidence,
        warningCount: warnings.length,
        errorCount: errors.length
      }
    });

    return {
      success,
      patientId: barcodeData.patientId,
      verificationId,
      verifiedAt: new Date(),
      verifiedBy: userId,
      verificationContext: 'administration',
      scannedBarcode: barcode,
      expectedData: { patientId: expectedPatientId },
      warnings: warnings.length > 0 ? warnings : undefined,
      errors: errors.length > 0 ? errors : undefined,
      confidence,
      metadata: {
        barcodeData,
        expectedPatient: {
          id: expectedPatient.id,
          mrn: expectedPatient.mrn,
          firstName: expectedPatient.firstName,
          lastName: expectedPatient.lastName
        }
      }
    };

  } catch (error) {
    logger.error('Error verifying patient barcode:', error, { barcode, expectedPatientId, userId });
    throw new Error('Failed to verify patient barcode');
  }
}

/**
 * Perform complete administration verification workflow
 */
export async function performAdministrationVerification(
  prescriptionId: string,
  patientBarcode: string,
  medicationBarcode: string,
  nurseId: string
): Promise<BarcodeAdministrationCheck> {
  try {
    logger.info(`Performing complete administration verification`, { 
      prescriptionId, 
      patientBarcode, 
      medicationBarcode, 
      nurseId 
    });

    // Get prescription details
    const prescription = await prisma.prescription.findUnique({
      where: { id: prescriptionId },
      include: {
        patient: true,
        medication: true
      }
    });

    if (!prescription) {
      throw new Error('Prescription not found');
    }

    const checkId = `admin_check_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Verify patient barcode
    const patientVerification = await verifyPatientBarcode(
      patientBarcode,
      prescription.patientId,
      nurseId
    );

    // Verify medication barcode
    const medicationVerification = await verifyMedicationBarcode(
      medicationBarcode,
      prescription.medicationId,
      'administration',
      nurseId
    );

    // Check administration timing
    const now = new Date();
    const scheduledTime = prescription.scheduledTime || now;
    const timingWindow = getAdministrationWindow(scheduledTime);
    const timingVerified = now >= timingWindow.earliest && now <= timingWindow.latest;

    // Perform additional safety checks
    const safetyChecks = {
      patientIdentityVerified: patientVerification.success,
      medicationVerified: medicationVerification.success,
      doseVerified: true, // Would check against prescription dose
      routeVerified: true, // Would check against prescription route
      timingVerified,
      allergyChecked: await checkPatientAllergies(prescription.patientId, prescription.medicationId, nurseId),
      interactionChecked: await checkDrugInteractions(prescription.patientId, prescription.medicationId, nurseId)
    };

    const allVerified = patientVerification.success && medicationVerification.success;
    const administrationReady = allVerified && 
                              safetyChecks.timingVerified && 
                              safetyChecks.allergyChecked && 
                              safetyChecks.interactionChecked;

    const administrationCheck: BarcodeAdministrationCheck = {
      id: checkId,
      prescriptionId,
      patientId: prescription.patientId,
      medicationId: prescription.medicationId,
      scheduledTime,
      administrationWindow: timingWindow,
      barcodeVerifications: [
        {
          type: 'patient',
          barcode: patientBarcode,
          verified: patientVerification.success,
          scannedAt: patientVerification.verifiedAt,
          scannedBy: nurseId
        },
        {
          type: 'medication',
          barcode: medicationBarcode,
          verified: medicationVerification.success,
          scannedAt: medicationVerification.verifiedAt,
          scannedBy: nurseId
        }
      ],
      allVerified,
      safetyChecks,
      administrationReady,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    // Store verification result
    await prisma.medicationAdministrationCheck.create({
      data: {
        id: checkId,
        prescriptionId,
        patientId: prescription.patientId,
        medicationId: prescription.medicationId,
        nurseId,
        patientBarcodeVerified: patientVerification.success,
        medicationBarcodeVerified: medicationVerification.success,
        allSafetyChecksPassed: administrationReady,
        verificationData: JSON.stringify({
          patientVerification,
          medicationVerification,
          safetyChecks
        }),
        createdAt: new Date()
      }
    });

    // Audit log for complete verification
    await auditLog({
      userId: nurseId,
      action: 'COMPLETE_ADMINISTRATION_VERIFICATION',
      resourceType: 'MedicationAdministration',
      resourceId: checkId,
      details: {
        prescriptionId,
        patientId: prescription.patientId,
        medicationId: prescription.medicationId,
        allVerified,
        administrationReady,
        safetyChecks
      }
    });

    return administrationCheck;

  } catch (error) {
    logger.error('Error performing administration verification:', error, { 
      prescriptionId, 
      patientBarcode, 
      medicationBarcode, 
      nurseId 
    });
    throw new Error('Failed to perform administration verification');
  }
}

// Helper functions

/**
 * Parse medication barcode to extract information
 */
async function parseMedicationBarcode(barcode: string): Promise<MedicationBarcodeData | null> {
  try {
    // This is a simplified parser - in reality, you'd support multiple barcode formats
    // GS1 DataMatrix, Code 128, etc.
    
    // Example format: NDC|LOT|EXP|MEDID
    if (barcode.includes('|')) {
      const parts = barcode.split('|');
      if (parts.length >= 4) {
        const medication = await prisma.medication.findFirst({
          where: { 
            OR: [
              { ndc: parts[0] },
              { id: parts[3] }
            ]
          }
        });

        if (medication) {
          return {
            ndc: parts[0],
            lotNumber: parts[1] || undefined,
            expirationDate: parts[2] ? new Date(parts[2]) : undefined,
            medicationId: medication.id,
            medicationName: medication.name,
            strength: medication.strength,
            dosageForm: medication.dosageForm,
            manufacturer: medication.manufacturer
          };
        }
      }
    }

    // Try to find by NDC if simple format
    const medication = await prisma.medication.findFirst({
      where: { ndc: barcode }
    });

    if (medication) {
      return {
        ndc: barcode,
        medicationId: medication.id,
        medicationName: medication.name,
        strength: medication.strength,
        dosageForm: medication.dosageForm,
        manufacturer: medication.manufacturer
      };
    }

    return null;

  } catch (error) {
    logger.error('Error parsing medication barcode:', error, { barcode });
    return null;
  }
}

/**
 * Parse patient barcode to extract information
 */
async function parsePatientBarcode(barcode: string): Promise<PatientBarcodeData | null> {
  try {
    // Example format: MRN|PATID|WRISTBAND
    if (barcode.includes('|')) {
      const parts = barcode.split('|');
      if (parts.length >= 2) {
        const patient = await prisma.patient.findFirst({
          where: { 
            OR: [
              { mrn: parts[0] },
              { id: parts[1] }
            ]
          }
        });

        if (patient) {
          return {
            patientId: patient.id,
            mrn: patient.mrn,
            firstName: patient.firstName,
            lastName: patient.lastName,
            dateOfBirth: patient.dateOfBirth,
            wristbandId: parts[2] || undefined
          };
        }
      }
    }

    // Try to find by MRN if simple format
    const patient = await prisma.patient.findFirst({
      where: { mrn: barcode }
    });

    if (patient) {
      return {
        patientId: patient.id,
        mrn: patient.mrn,
        firstName: patient.firstName,
        lastName: patient.lastName,
        dateOfBirth: patient.dateOfBirth
      };
    }

    return null;

  } catch (error) {
    logger.error('Error parsing patient barcode:', error, { barcode });
    return null;
  }
}

/**
 * Check if medication is subject to recall
 */
async function checkMedicationRecall(ndc: string, lotNumber: string): Promise<boolean> {
  try {
    // In a real system, this would check against FDA recall database
    // For now, simulate with a simple check
    const recall = await prisma.medicationRecall.findFirst({
      where: {
        ndc,
        lotNumber,
        isActive: true
      }
    });

    return !!recall;

  } catch (error) {
    logger.error('Error checking medication recall:', error, { ndc, lotNumber });
    return false; // Default to safe side
  }
}

/**
 * Get administration time window
 */
function getAdministrationWindow(scheduledTime: Date): { earliest: Date; latest: Date } {
  // Standard 1-hour window (30 minutes before/after)
  const windowMinutes = 30;
  
  return {
    earliest: new Date(scheduledTime.getTime() - windowMinutes * 60 * 1000),
    latest: new Date(scheduledTime.getTime() + windowMinutes * 60 * 1000)
  };
}

/**
 * Check patient allergies against medication
 */
async function checkPatientAllergies(patientId: string, medicationId: string, userId: string): Promise<boolean> {
  try {
    const medication = await getMedicationById(medicationId, userId);
    if (!medication) return false;

    const allergies = await prisma.patientAllergy.findMany({
      where: {
        patientId,
        isActive: true
      }
    });

    // Check for direct medication allergies
    const hasDirectAllergy = allergies.some(allergy => 
      allergy.allergen.toLowerCase().includes(medication.name.toLowerCase()) ||
      allergy.allergen.toLowerCase().includes(medication.genericName.toLowerCase())
    );

    // Check for ingredient allergies
    const hasIngredientAllergy = medication.activeIngredients?.some(ingredient =>
      allergies.some(allergy => 
        allergy.allergen.toLowerCase().includes(ingredient.toLowerCase())
      )
    ) || false;

    return !hasDirectAllergy && !hasIngredientAllergy;

  } catch (error) {
    logger.error('Error checking patient allergies:', error, { patientId, medicationId });
    return false; // Default to safe side
  }
}

/**
 * Check drug interactions
 */
async function checkDrugInteractions(patientId: string, medicationId: string, userId: string): Promise<boolean> {
  try {
    // Get patient's current medications
    const currentPrescriptions = await prisma.prescription.findMany({
      where: {
        patientId,
        isActive: true,
        status: 'active'
      }
    });

    const currentMedicationIds = currentPrescriptions.map(p => p.medicationId);
    
    // Check for interactions
    const interactions = await prisma.drugInteraction.findMany({
      where: {
        OR: [
          {
            medication1Id: medicationId,
            medication2Id: { in: currentMedicationIds }
          },
          {
            medication1Id: { in: currentMedicationIds },
            medication2Id: medicationId
          }
        ],
        isActive: true,
        severity: { in: ['major', 'contraindicated'] }
      }
    });

    return interactions.length === 0;

  } catch (error) {
    logger.error('Error checking drug interactions:', error, { patientId, medicationId });
    return false; // Default to safe side
  }
}

// Export types and functions
export {
  type BarcodeVerificationResult,
  type BarcodeAdministrationCheck,
  type MedicationBarcodeData,
  type PatientBarcodeData
};
