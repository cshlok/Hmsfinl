import { NextRequest, NextResponse } from 'next/server';
import { errorHandlingMiddleware } from '@/lib/api/errorHandler';

/**
 * Integration API for Support Services
 * 
 * This API provides endpoints for integrating support services with core HMS systems.
 */

/**
 * GET /api/integration/support-services
 * General support services integration endpoint
 */
export async function GET(request: NextRequest) {
  return errorHandlingMiddleware(request, async (req) => {
    // Extract query parameters to determine what information to retrieve
    const { searchParams } = new URL(req.url);
    const action = searchParams.get('action');
    const id = searchParams.get('id');
    
    // Mock response for now - in production, this would integrate with actual services
    const mockResponse = {
      patient: {
        id: id || 'patient_123',
        name: 'John Doe',
        mrn: 'MRN123456',
        room: '101A'
      },
      location: {
        id: id || 'loc_123',
        name: 'Room 101A',
        department: 'ICU',
        floor: 1
      }
    };
    
    const responseData = action === 'patient' ? mockResponse.patient : 
                        action === 'location' ? mockResponse.location :
                        { message: 'Support services integration active' };
    
    return NextResponse.json({
      success: true,
      data: responseData
    });
  });
}

/**
 * POST /api/integration/support-services
 * General support services integration POST endpoint
 */
export async function POST(request: NextRequest) {
  return errorHandlingMiddleware(request, async (req) => {
    // Parse request body
    const body = await req.json();
    const { action, ...data } = body;
    
    // Mock response based on action type
    const responses = {
      notification: {
        id: 'notif_123',
        status: 'sent',
        message: 'Notification sent successfully'
      },
      report: {
        id: 'report_123',
        status: 'submitted',
        message: 'Report submitted successfully'
      },
      link: {
        id: 'link_123',
        status: 'linked',
        message: 'Resources linked successfully'
      }
    };
    
    const responseData = responses[action as keyof typeof responses] || {
      status: 'processed',
      message: 'Request processed successfully'
    };
    
    return NextResponse.json({
      success: true,
      data: responseData
    });
  });
}
